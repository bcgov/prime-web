export declare class PrimeCoreModule {
}
