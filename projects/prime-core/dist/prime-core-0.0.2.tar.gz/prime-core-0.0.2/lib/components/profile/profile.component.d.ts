import { OnInit, EventEmitter, OnDestroy } from '@angular/core';
import { ControlContainer } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Base } from 'moh-common-lib/models';
import { PrimePerson } from '../../../models/prime-person.model';
import { CountryList, ProvinceList } from '../address/address.component';
export declare class ProfileComponent extends Base implements OnInit, OnDestroy {
    private cntrlContainer;
    data: PrimePerson;
    countryList: CountryList[];
    provinceList: ProvinceList[];
    editIdentityInfo: boolean;
    pageTitle: string;
    dataChange: EventEmitter<PrimePerson>;
    defaultCountry: string;
    defaultProvince: string;
    /**
     * Date of birth error messages
     */
    dateLabel: string;
    private form;
    private _firstNameCtrl;
    private _preferredFirstNameCtrl;
    private _preferredLastNameCtrl;
    private _requiredError;
    subscriptions: Subscription[];
    constructor(cntrlContainer: ControlContainer);
    emitChanges(itm: PrimePerson): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleCheckBox(): void;
    onBlur(event: any): void;
    private setCntrolError;
}
