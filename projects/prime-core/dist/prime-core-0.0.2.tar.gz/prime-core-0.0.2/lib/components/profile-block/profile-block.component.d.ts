import { OnInit } from '@angular/core';
import { SimpleDate } from 'moh-common-lib';
export declare class ProfileBlockComponent implements OnInit {
    name: string;
    preferredName: string;
    dateOfBirth: SimpleDate;
    private _dob;
    readonly dob: string;
    constructor();
    ngOnInit(): void;
}
