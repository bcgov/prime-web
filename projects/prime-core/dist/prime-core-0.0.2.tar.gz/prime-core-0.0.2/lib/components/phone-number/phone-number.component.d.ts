import { OnInit } from '@angular/core';
import { MaskModel } from 'moh-common-lib/models';
export declare class PhoneNumberComponent extends MaskModel implements OnInit {
    displayMask: boolean;
    label: string;
    objectID: string;
    maxlen: string;
    constructor();
    ngOnInit(): void;
}
