import { OnInit, EventEmitter, ElementRef, OnChanges } from '@angular/core';
import { Base, Address } from 'moh-common-lib/models';
import { GeocoderService } from 'moh-common-lib/services';
import { Observable } from 'rxjs';
import { GeoAddressResult } from 'moh-common-lib/services/geocoder.service';
import { TypeaheadMatch } from 'ngx-bootstrap';
/** Interface for countries */
export interface CountryList {
    countryCode: string;
    description: string;
}
export interface ProvinceList {
    country: string;
    provinceCode: string;
    description: string;
}
export declare class AddressComponent extends Base implements OnInit, OnChanges {
    private geocoderService;
    CITY_MAXLEN: string;
    PROV_MAXLEN: string;
    STREET_RURAL_MAXLEN: string;
    provRef: ElementRef;
    streetRef: ElementRef;
    cityRef: ElementRef;
    postalRef: ElementRef;
    disabled: boolean;
    isRequired: boolean;
    address: Address;
    countryList: CountryList[];
    defaultCountry: string;
    provinceList: ProvinceList[];
    defaultProvince: string;
    addressChange: EventEmitter<Address>;
    /** Search string to store result from GeoCoder request */
    search: string;
    /**
     * The list of results, from API, that is passed to the typeahead list
     * Result from GeoCoderService address lookup
     */
    typeaheadList$: Observable<GeoAddressResult[]>;
    /** The subject that triggers on user text input and gets typeaheadList$ to update.  */
    private searchText$;
    provList: ProvinceList[];
    constructor(geocoderService: GeocoderService);
    ngOnInit(): void;
    /**
     * Set country province blank
     * @param value
     */
    setCountry(value: string): void;
    setProvince(value: string): void;
    setStreetAddress(value: string): void;
    setCity(value: string): void;
    /**
    * Sets string after converted upper case
    * @param text
    */
    postalCode: string;
    isCanada(): boolean;
    isCanadaUSA(): boolean;
    ngOnChanges(changes: any): void;
    /**
     * Updates the provList variable. Values must be stored in a variable and not
     * accessed via function invocation for performance.
     */
    private updateProvList;
    /**
     * Sets the default province option value
     */
    private setDefaultProvinceAsOption;
    /**
     * Set country to default
     * Search uses country code or country name to find item is list.
     */
    private setDefaultCountryAsOption;
    /**
     * GeoCoder only is applicable when address is BC, Canada.
     */
    useGeoCoder(): boolean;
    onKeyUp(event: KeyboardEvent): void;
    onError(err: any): Observable<GeoAddressResult[]>;
    onSelect(event: TypeaheadMatch): void;
}
