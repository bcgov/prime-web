import { OnInit } from '@angular/core';
export declare class ReviewListItemComponent implements OnInit {
    label: string;
    value: string;
    constructor();
    ngOnInit(): void;
}
