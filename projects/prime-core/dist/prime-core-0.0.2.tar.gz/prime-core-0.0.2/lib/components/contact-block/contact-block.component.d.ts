import { OnInit } from '@angular/core';
export declare class ContactBlockComponent implements OnInit {
    phone: string;
    email: string;
    voicePhone: string;
    preferredContact: string;
    ext: string;
    constructor();
    ngOnInit(): void;
}
