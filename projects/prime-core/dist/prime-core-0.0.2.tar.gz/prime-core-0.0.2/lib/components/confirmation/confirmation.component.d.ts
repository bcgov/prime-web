import { OnInit, EventEmitter } from '@angular/core';
import { ApiStatusCodes } from '../../../models/api-base.model';
export declare class ConfirmationComponent implements OnInit {
    displayIcon: ApiStatusCodes;
    hasQrCode: boolean;
    btnLabel: string;
    btnClick: EventEmitter<any>;
    constructor();
    ngOnInit(): void;
    readonly successCode: ApiStatusCodes;
    readonly errorCode: ApiStatusCodes;
    readonly warningCode: ApiStatusCodes;
    onClick($event: any): boolean;
}
