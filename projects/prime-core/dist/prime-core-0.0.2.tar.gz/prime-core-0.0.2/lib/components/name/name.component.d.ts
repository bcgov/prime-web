import { OnInit, EventEmitter } from '@angular/core';
import { Base } from 'moh-common-lib/models';
/**
 * TODO: Determine whether this component should be in the moh-common-lib
 */
export declare class NameComponent extends Base implements OnInit {
    disabled: boolean;
    required: boolean;
    nameStr: string;
    label: string;
    maxLen: string;
    objectID: string;
    nameStrChange: EventEmitter<string>;
    blurEvent: EventEmitter<{}>;
    /**
     * Valid characters for name
     */
    nameCriteria: RegExp;
    constructor();
    ngOnInit(): void;
    /**
     * Passes the value entered back to the calling component
     * @param name value the was entered by
     */
    setName(value: string): void;
    onInputBlur($event: any): void;
}
