import { OnInit } from '@angular/core';
import { CommonImage } from 'moh-common-lib/images/src/images';
import { Observable } from 'rxjs';
export declare class SelfDeclarationQuestionBlockComponent implements OnInit {
    question: string;
    answer: boolean;
    details: string;
    documents: Array<CommonImage>;
    documents$: Observable<string>;
    yesNo: string;
    constructor();
    ngOnInit(): void;
}
