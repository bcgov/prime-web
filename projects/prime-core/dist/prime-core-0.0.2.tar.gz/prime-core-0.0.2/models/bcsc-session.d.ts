export interface BCSCSessionInterface {
    authTrxId: string;
    authPartyId: string;
    authPartyName: string;
    userIdType: string;
    userType: string;
}
/**
 * Class to store the BCSC session information
 */
export declare class BcscSession {
    authTrxId: string;
    authPartyId: string;
    authPartyName: string;
    userIdType: string;
    userType: string;
    /**
     * Note: Once object type is know set the parameter to be as such
     * @param obj
     */
    setSessionData(obj: BCSCSessionInterface): void;
    isEmpty(): boolean;
}
