import { OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { Base } from 'moh-common-lib/models';
import { CommonLogger } from 'moh-common-lib/services';
/**
 * PrimeAppBase is a class containing shared functionality for the
 * various "AppComponent"s for each individual prime application. The important
 * functionality is in the constructor and ngOnInit().  Unfortunately this does
 * not come bundled with a template and instead templates must be updated for
 * each project manually.
 *
 * **Note** - you MUST call super.ngOnInit() you have an ngOnInit() method in
 * your subclass. Otherwise, the title and accessability functions concerns
 * won't update.
 */
export declare class PrimeAppBase extends Base implements OnInit {
    protected pRouter: Router;
    protected pActivatedRoute: ActivatedRoute;
    protected pTitleService: Title;
    protected logger: CommonLogger;
    title: string;
    skipLinkPath: any;
    private SKIP_CONTENT_HASH;
    constructor(pRouter: Router, pActivatedRoute: ActivatedRoute, pTitleService: Title, logger: CommonLogger, version: any);
    ngOnInit(): void;
    /**
     * Listen to every route change, and update the page title based on the
     * 'title' property in the route's data.
     */
    protected updateTitleOnRouteChange(): void;
    /** Set the page title. Includes basic formatting and fallback */
    protected setTitle(title?: string): void;
    routeIsActive(url: string): boolean;
    /**
     * Updates the skipToContent link which is an a11y concern.  Importantly the
     * skipToContent link must include the relevant routes / subpages that the
     * user is currently on.
     */
    updateSkipContentLink(): void;
    protected generateSkipToContentLink(): string;
}
