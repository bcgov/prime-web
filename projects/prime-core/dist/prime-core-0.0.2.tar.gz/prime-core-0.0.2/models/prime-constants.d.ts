/** Common to all PRIME applications */
export declare class PrimeConstants {
    static EMAIL_MAXLEN: string;
    static CANADA: string;
    static BRITISH_COLUMBIA: string;
}
/**
 * Identity provider
 */
export declare enum ProviderCode {
    MOH = "MOH",
    BCSC = "BCSC"
}
/**
 * Security assurance level for the person.
 */
export declare enum AssuranceLevel {
    LEVEL_1 = "1",
    LEVEL_2 = "2",
    LEVEL_3 = "3"
}
