import { SimpleDate } from 'moh-common-lib';
import { CommonImage } from 'moh-common-lib/images/images';
export interface DocumentType {
    docType: string;
    description: string;
}
export declare class Document {
    type: DocumentType;
    registrantUUID: string;
    expiry?: SimpleDate;
    images: CommonImage[];
    constructor(input: any);
    isValid(): boolean;
}
