import { ServerPayload, PayloadInterface, StatusMsgInterface } from './api-base.model';
import { DocumentType } from './documents.interface';
import { CountryList, ProvinceList } from '../lib/components/address/address.component';
export interface SysParamInterface {
    name: string;
    value: string;
}
/**
 * Get Cache
 */
export interface CacheInterface extends PayloadInterface {
    country?: CountryList[];
    province?: ProvinceList[];
    messages?: StatusMsgInterface[];
    secQues?: string[];
    documentType?: DocumentType[];
    sysParam?: SysParamInterface[];
}
export declare class CachePayLoad extends ServerPayload {
    country: CountryList[];
    province: ProvinceList[];
    messages: StatusMsgInterface[];
    secQues: string[];
    documentType: DocumentType[];
    sysParam: SysParamInterface[];
    constructor(payload: CacheInterface);
}
