import { Person, Address } from 'moh-common-lib/models';
export declare class PrimePerson extends Person {
    /** Parts of a person's name */
    preferredFirstName: string;
    preferredMiddleName: string;
    preferredLastName: string;
    /** Identify and mailing addresses */
    address: Address;
    mailAddress: Address;
    identityIsMailingAddress: boolean;
    copy(object: PrimePerson): void;
}
