/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @enum {string} */
var ApiStatusCodes = {
    SUCCESS: '0',
    ERROR: '1',
    WARNING: '2',
};
export { ApiStatusCodes };
/** @enum {string} */
var ScreenAreaID = {
    CONFIRMATION: 'CONFIRMATION',
    QRCODE: 'QR',
    NEXT_STEPS: 'NEXT STEPS',
    INTERIM: 'INTERIM',
    FINAL: 'FINAL',
};
export { ScreenAreaID };
/**
 *  Structure for confirmation page to display messages in correct
 *  screen area
 * @record
 */
export function StatusMsgInterface() { }
if (false) {
    /** @type {?} */
    StatusMsgInterface.prototype.msgID;
    /** @type {?} */
    StatusMsgInterface.prototype.msgText;
    /** @type {?} */
    StatusMsgInterface.prototype.msgType;
    /** @type {?} */
    StatusMsgInterface.prototype.scrArea;
    /** @type {?} */
    StatusMsgInterface.prototype.appLayer;
}
/**
 * @record
 */
export function PayloadInterface() { }
if (false) {
    /**
     * Default application name
     * @type {?}
     */
    PayloadInterface.prototype.clientName;
    /**
     * Date the JSON message was created. Date format dictated by value in DB System
     * Parameter table for DATE_FORMAT (i.e. YYYYMMDD) parameter
     * @type {?}
     */
    PayloadInterface.prototype.processDate;
    /**
     * Returned status code values: 0 = success, continue, 1 = error,
     * do not continue, 2 = warning.
     * @type {?}
     */
    PayloadInterface.prototype.statusCode;
    /**
     * Contains the list of Enhanced Message related to the process execution
     * @type {?}
     */
    PayloadInterface.prototype.statusMsgs;
}
var ServerPayload = /** @class */ (function () {
    function ServerPayload(payload) {
        this.clientName = payload.clientName;
        this.processDate = payload.processDate;
        this.statusCode = payload.statusCode;
        this.statusMsgs = payload.statusMsgs;
    }
    Object.defineProperty(ServerPayload.prototype, "success", {
        get: /**
         * @return {?}
         */
        function () {
            return this.statusCode === ApiStatusCodes.SUCCESS;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ServerPayload.prototype, "error", {
        get: /**
         * @return {?}
         */
        function () {
            return this.statusCode === ApiStatusCodes.ERROR;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ServerPayload.prototype, "warning", {
        get: /**
         * @return {?}
         */
        function () {
            return this.statusCode === ApiStatusCodes.WARNING;
        },
        enumerable: true,
        configurable: true
    });
    return ServerPayload;
}());
export { ServerPayload };
if (false) {
    /** @type {?} */
    ServerPayload.prototype.clientName;
    /** @type {?} */
    ServerPayload.prototype.processDate;
    /** @type {?} */
    ServerPayload.prototype.statusCode;
    /** @type {?} */
    ServerPayload.prototype.statusMsgs;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLWJhc2UubW9kZWwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9wcmltZS1jb3JlLyIsInNvdXJjZXMiOlsibW9kZWxzL2FwaS1iYXNlLm1vZGVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztJQUNFLFNBQVUsR0FBRztJQUNiLE9BQVEsR0FBRztJQUNYLFNBQVUsR0FBRzs7Ozs7SUFLYixjQUFlLGNBQWM7SUFDN0IsUUFBUyxJQUFJO0lBQ2IsWUFBYSxZQUFZO0lBQ3pCLFNBQVUsU0FBUztJQUNuQixPQUFRLE9BQU87Ozs7Ozs7O0FBT2pCLHdDQU1DOzs7SUFMQyxtQ0FBYzs7SUFDZCxxQ0FBZ0I7O0lBQ2hCLHFDQUFnQjs7SUFDaEIscUNBQXNCOztJQUN0QixzQ0FBaUI7Ozs7O0FBRW5CLHNDQXVCQzs7Ozs7O0lBbEJDLHNDQUFtQjs7Ozs7O0lBTW5CLHVDQUFvQjs7Ozs7O0lBTXBCLHNDQUFtQjs7Ozs7SUFLbkIsc0NBQXFEOztBQUd2RDtJQU9FLHVCQUFZLE9BQXlCO1FBQ25DLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQztRQUNyQyxJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQztJQUN2QyxDQUFDO0lBRUQsc0JBQUksa0NBQU87Ozs7UUFBWDtZQUNFLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxjQUFjLENBQUMsT0FBTyxDQUFDO1FBQ3BELENBQUM7OztPQUFBO0lBRUQsc0JBQUksZ0NBQUs7Ozs7UUFBVDtZQUNFLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxjQUFjLENBQUMsS0FBSyxDQUFDO1FBQ2xELENBQUM7OztPQUFBO0lBRUQsc0JBQUksa0NBQU87Ozs7UUFBWDtZQUNFLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxjQUFjLENBQUMsT0FBTyxDQUFDO1FBQ3BELENBQUM7OztPQUFBO0lBQ0gsb0JBQUM7QUFBRCxDQUFDLEFBekJELElBeUJDOzs7O0lBeEJDLG1DQUFtQjs7SUFDbkIsb0NBQW9COztJQUNwQixtQ0FBbUI7O0lBQ25CLG1DQUFxRCIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBlbnVtIEFwaVN0YXR1c0NvZGVzIHtcbiAgU1VDQ0VTUyA9ICcwJyxcbiAgRVJST1IgPSAnMScsXG4gIFdBUk5JTkcgPSAnMidcbn1cblxuLyoqIFNjcmVlbiBzZWN0aW9uIGlkZW50aWZpZXJzICovXG5leHBvcnQgZW51bSBTY3JlZW5BcmVhSUQge1xuICBDT05GSVJNQVRJT04gPSAnQ09ORklSTUFUSU9OJyxcbiAgUVJDT0RFID0gJ1FSJyxcbiAgTkVYVF9TVEVQUyA9ICdORVhUIFNURVBTJyxcbiAgSU5URVJJTSA9ICdJTlRFUklNJyxcbiAgRklOQUwgPSAnRklOQUwnXG59XG5cbi8qKlxuICogIFN0cnVjdHVyZSBmb3IgY29uZmlybWF0aW9uIHBhZ2UgdG8gZGlzcGxheSBtZXNzYWdlcyBpbiBjb3JyZWN0XG4gKiAgc2NyZWVuIGFyZWFcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBTdGF0dXNNc2dJbnRlcmZhY2Uge1xuICBtc2dJRDogc3RyaW5nO1xuICBtc2dUZXh0OiBzdHJpbmc7XG4gIG1zZ1R5cGU6IHN0cmluZztcbiAgc2NyQXJlYTogU2NyZWVuQXJlYUlEO1xuICBhcHBMYXllcjogc3RyaW5nO1xufVxuZXhwb3J0IGludGVyZmFjZSBQYXlsb2FkSW50ZXJmYWNlIHtcblxuICAvKipcbiAgICogRGVmYXVsdCBhcHBsaWNhdGlvbiBuYW1lXG4gICAqL1xuICBjbGllbnROYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIERhdGUgdGhlIEpTT04gbWVzc2FnZSB3YXMgY3JlYXRlZC4gRGF0ZSBmb3JtYXQgZGljdGF0ZWQgYnkgdmFsdWUgaW4gREIgU3lzdGVtXG4gICAqIFBhcmFtZXRlciB0YWJsZSBmb3IgREFURV9GT1JNQVQgKGkuZS4gWVlZWU1NREQpIHBhcmFtZXRlclxuICAgKi9cbiAgcHJvY2Vzc0RhdGU6IHN0cmluZztcblxuICAvKipcbiAgICogUmV0dXJuZWQgc3RhdHVzIGNvZGUgdmFsdWVzOiAwID0gc3VjY2VzcywgY29udGludWUsIDEgPSBlcnJvcixcbiAgICogZG8gbm90IGNvbnRpbnVlLCAyID0gd2FybmluZy5cbiAgICovXG4gIHN0YXR1c0NvZGU6IHN0cmluZztcblxuICAvKipcbiAgICogQ29udGFpbnMgdGhlIGxpc3Qgb2YgRW5oYW5jZWQgTWVzc2FnZSByZWxhdGVkIHRvIHRoZSBwcm9jZXNzIGV4ZWN1dGlvblxuICAgKi9cbiAgc3RhdHVzTXNnczogU3RhdHVzTXNnSW50ZXJmYWNlW10gfCBzdHJpbmcgfCBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGNsYXNzIFNlcnZlclBheWxvYWQgaW1wbGVtZW50cyBQYXlsb2FkSW50ZXJmYWNlIHtcbiAgY2xpZW50TmFtZTogc3RyaW5nO1xuICBwcm9jZXNzRGF0ZTogc3RyaW5nO1xuICBzdGF0dXNDb2RlOiBzdHJpbmc7XG4gIHN0YXR1c01zZ3M6IFN0YXR1c01zZ0ludGVyZmFjZVtdIHwgc3RyaW5nIHwgc3RyaW5nW107XG5cblxuICBjb25zdHJ1Y3RvcihwYXlsb2FkOiBQYXlsb2FkSW50ZXJmYWNlKSB7XG4gICAgdGhpcy5jbGllbnROYW1lID0gcGF5bG9hZC5jbGllbnROYW1lO1xuICAgIHRoaXMucHJvY2Vzc0RhdGUgPSBwYXlsb2FkLnByb2Nlc3NEYXRlO1xuICAgIHRoaXMuc3RhdHVzQ29kZSA9IHBheWxvYWQuc3RhdHVzQ29kZTtcbiAgICB0aGlzLnN0YXR1c01zZ3MgPSBwYXlsb2FkLnN0YXR1c01zZ3M7XG4gIH1cblxuICBnZXQgc3VjY2VzcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0dXNDb2RlID09PSBBcGlTdGF0dXNDb2Rlcy5TVUNDRVNTO1xuICB9XG5cbiAgZ2V0IGVycm9yKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnN0YXR1c0NvZGUgPT09IEFwaVN0YXR1c0NvZGVzLkVSUk9SO1xuICB9XG5cbiAgZ2V0IHdhcm5pbmcoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdHVzQ29kZSA9PT0gQXBpU3RhdHVzQ29kZXMuV0FSTklORztcbiAgfVxufVxuXG5cbiJdfQ==