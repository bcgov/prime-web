/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function BCSCSessionInterface() { }
if (false) {
    /** @type {?} */
    BCSCSessionInterface.prototype.authTrxId;
    /** @type {?} */
    BCSCSessionInterface.prototype.authPartyId;
    /** @type {?} */
    BCSCSessionInterface.prototype.authPartyName;
    /** @type {?} */
    BCSCSessionInterface.prototype.userIdType;
    /** @type {?} */
    BCSCSessionInterface.prototype.userType;
}
/**
 * Class to store the BCSC session information
 */
var /**
 * Class to store the BCSC session information
 */
BcscSession = /** @class */ (function () {
    function BcscSession() {
    }
    /**
     * Note: Once object type is know set the parameter to be as such
     * @param obj
     */
    /**
     * Note: Once object type is know set the parameter to be as such
     * @param {?} obj
     * @return {?}
     */
    BcscSession.prototype.setSessionData = /**
     * Note: Once object type is know set the parameter to be as such
     * @param {?} obj
     * @return {?}
     */
    function (obj) {
        this.authTrxId = obj.authTrxId;
        this.authPartyId = obj.authPartyId;
        this.authPartyName = obj.authPartyName;
        this.userIdType = obj.userIdType;
        this.userType = obj.userType;
    };
    /**
     * @return {?}
     */
    BcscSession.prototype.isEmpty = /**
     * @return {?}
     */
    function () {
        return !(this.authPartyId && this.authPartyName &&
            this.userIdType && this.userType && this.authTrxId);
    };
    return BcscSession;
}());
/**
 * Class to store the BCSC session information
 */
export { BcscSession };
if (false) {
    /** @type {?} */
    BcscSession.prototype.authTrxId;
    /** @type {?} */
    BcscSession.prototype.authPartyId;
    /** @type {?} */
    BcscSession.prototype.authPartyName;
    /** @type {?} */
    BcscSession.prototype.userIdType;
    /** @type {?} */
    BcscSession.prototype.userType;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmNzYy1zZXNzaW9uLmpzIiwic291cmNlUm9vdCI6Im5nOi8vcHJpbWUtY29yZS8iLCJzb3VyY2VzIjpbIm1vZGVscy9iY3NjLXNlc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUVBLDBDQU1DOzs7SUFMQyx5Q0FBa0I7O0lBQ2xCLDJDQUFvQjs7SUFDcEIsNkNBQXNCOztJQUN0QiwwQ0FBbUI7O0lBQ25CLHdDQUFpQjs7Ozs7QUFNbkI7Ozs7SUFBQTtJQXlCQSxDQUFDO0lBakJDOzs7T0FHRzs7Ozs7O0lBQ0gsb0NBQWM7Ozs7O0lBQWQsVUFBZ0IsR0FBeUI7UUFFdkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQy9CLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQztJQUMvQixDQUFDOzs7O0lBRUQsNkJBQU87OztJQUFQO1FBQ0UsT0FBTyxDQUFDLENBQUUsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsYUFBYTtZQUN0QyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBRSxDQUFDO0lBQ2pFLENBQUM7SUFDSCxrQkFBQztBQUFELENBQUMsQUF6QkQsSUF5QkM7Ozs7Ozs7SUF2QkMsZ0NBQXlCOztJQUN6QixrQ0FBMkI7O0lBQzNCLG9DQUE2Qjs7SUFDN0IsaUNBQTBCOztJQUMxQiwrQkFBd0IiLCJzb3VyY2VzQ29udGVudCI6WyJcblxuZXhwb3J0IGludGVyZmFjZSBCQ1NDU2Vzc2lvbkludGVyZmFjZSB7XG4gIGF1dGhUcnhJZDogc3RyaW5nOyAgICAgIC8vIEJDU0MgQXV0aGVudGljYXRpb24gVHJhbnNhY3Rpb24gSWRlbnRpZmllciByZWxhdGVkIHRvIGxvZ2luIHNlc3Npb24gaWRlbnRpZmllclxuICBhdXRoUGFydHlJZDogc3RyaW5nOyAgICAvLyBCQ1NDIEF1dGhvcml0YXRpdmUgUGFydHkgSWRlbnRpZmllciByZWxhdGVkIHRvIGxvZ2luIHNlc3Npb25cbiAgYXV0aFBhcnR5TmFtZTogc3RyaW5nOyAgLy8gQkNTQyBBdXRob3JpdGF0aXZlIFBhcnR5IE5hbWUgcmVsYXRlZCB0byBsb2dpbiBzZXNzaW9uXG4gIHVzZXJJZFR5cGU6IHN0cmluZzsgICAgIC8vIEJDU0MgVXNlciBJZGVudGlmaWVyIFR5cGUgcmVsYXRlZCB0byBsb2dpbiBzZXNzaW9uXG4gIHVzZXJUeXBlOiBzdHJpbmc7ICAgICAgIC8vIEJDU0MgVXNlciBJZGVudGlmaWVyIFR5cGUgcmVsYXRlZCB0byBsb2dpbiBzZXNzaW9uXG59XG5cbi8qKlxuICogQ2xhc3MgdG8gc3RvcmUgdGhlIEJDU0Mgc2Vzc2lvbiBpbmZvcm1hdGlvblxuICovXG5leHBvcnQgY2xhc3MgQmNzY1Nlc3Npb24ge1xuXG4gIHB1YmxpYyBhdXRoVHJ4SWQ6IHN0cmluZztcbiAgcHVibGljIGF1dGhQYXJ0eUlkOiBzdHJpbmc7XG4gIHB1YmxpYyBhdXRoUGFydHlOYW1lOiBzdHJpbmc7XG4gIHB1YmxpYyB1c2VySWRUeXBlOiBzdHJpbmc7XG4gIHB1YmxpYyB1c2VyVHlwZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOb3RlOiBPbmNlIG9iamVjdCB0eXBlIGlzIGtub3cgc2V0IHRoZSBwYXJhbWV0ZXIgdG8gYmUgYXMgc3VjaFxuICAgKiBAcGFyYW0gb2JqXG4gICAqL1xuICBzZXRTZXNzaW9uRGF0YSggb2JqOiBCQ1NDU2Vzc2lvbkludGVyZmFjZSApIHtcblxuICAgIHRoaXMuYXV0aFRyeElkID0gb2JqLmF1dGhUcnhJZDtcbiAgICB0aGlzLmF1dGhQYXJ0eUlkID0gb2JqLmF1dGhQYXJ0eUlkO1xuICAgIHRoaXMuYXV0aFBhcnR5TmFtZSA9IG9iai5hdXRoUGFydHlOYW1lO1xuICAgIHRoaXMudXNlcklkVHlwZSA9IG9iai51c2VySWRUeXBlO1xuICAgIHRoaXMudXNlclR5cGUgPSBvYmoudXNlclR5cGU7XG4gIH1cblxuICBpc0VtcHR5KCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAhKCB0aGlzLmF1dGhQYXJ0eUlkICYmIHRoaXMuYXV0aFBhcnR5TmFtZSAmJlxuICAgICAgICAgICAgICB0aGlzLnVzZXJJZFR5cGUgJiYgdGhpcy51c2VyVHlwZSAmJiB0aGlzLmF1dGhUcnhJZCApO1xuICB9XG59XG4iXX0=