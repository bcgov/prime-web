/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import * as tslib_1 from "tslib";
import { ServerPayload } from './api-base.model';
/**
 * @record
 */
export function SysParamInterface() { }
if (false) {
    /** @type {?} */
    SysParamInterface.prototype.name;
    /** @type {?} */
    SysParamInterface.prototype.value;
}
/**
 * Get Cache
 * @record
 */
export function CacheInterface() { }
if (false) {
    /** @type {?|undefined} */
    CacheInterface.prototype.country;
    /** @type {?|undefined} */
    CacheInterface.prototype.province;
    /** @type {?|undefined} */
    CacheInterface.prototype.messages;
    /** @type {?|undefined} */
    CacheInterface.prototype.secQues;
    /** @type {?|undefined} */
    CacheInterface.prototype.documentType;
    /** @type {?|undefined} */
    CacheInterface.prototype.sysParam;
}
var CachePayLoad = /** @class */ (function (_super) {
    tslib_1.__extends(CachePayLoad, _super);
    function CachePayLoad(payload) {
        var _this = _super.call(this, payload) || this;
        _this.country = payload.country ? payload.country : undefined;
        _this.province = payload.province ? payload.province : undefined;
        _this.messages = payload.messages ? payload.messages : undefined;
        _this.secQues = payload.secQues ? payload.secQues : undefined;
        _this.documentType = payload.documentType ? payload.documentType : undefined;
        _this.sysParam = payload.sysParam ? payload.sysParam : undefined;
        return _this;
    }
    return CachePayLoad;
}(ServerPayload));
export { CachePayLoad };
if (false) {
    /** @type {?} */
    CachePayLoad.prototype.country;
    /** @type {?} */
    CachePayLoad.prototype.province;
    /** @type {?} */
    CachePayLoad.prototype.messages;
    /** @type {?} */
    CachePayLoad.prototype.secQues;
    /** @type {?} */
    CachePayLoad.prototype.documentType;
    /** @type {?} */
    CachePayLoad.prototype.sysParam;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUtYXBpLm1vZGVsLmpzIiwic291cmNlUm9vdCI6Im5nOi8vcHJpbWUtY29yZS8iLCJzb3VyY2VzIjpbIm1vZGVscy9jYWNoZS1hcGkubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxPQUFPLEVBQUUsYUFBYSxFQUF3QyxNQUFNLGtCQUFrQixDQUFDOzs7O0FBSXZGLHVDQUdDOzs7SUFGQyxpQ0FBYTs7SUFDYixrQ0FBYzs7Ozs7O0FBTWhCLG9DQU9DOzs7SUFOQyxpQ0FBd0I7O0lBQ3hCLGtDQUEwQjs7SUFDMUIsa0NBQWdDOztJQUNoQyxpQ0FBbUI7O0lBQ25CLHNDQUE4Qjs7SUFDOUIsa0NBQStCOztBQUdqQztJQUFrQyx3Q0FBYTtJQVE3QyxzQkFBYSxPQUF1QjtRQUFwQyxZQUNFLGtCQUFPLE9BQU8sQ0FBRSxTQU9qQjtRQU5DLEtBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQzdELEtBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQ2hFLEtBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQ2hFLEtBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQzdELEtBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQzVFLEtBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDOztJQUNsRSxDQUFDO0lBQ0gsbUJBQUM7QUFBRCxDQUFDLEFBakJELENBQWtDLGFBQWEsR0FpQjlDOzs7O0lBaEJDLCtCQUF1Qjs7SUFDdkIsZ0NBQXlCOztJQUN6QixnQ0FBK0I7O0lBQy9CLCtCQUFrQjs7SUFDbEIsb0NBQTZCOztJQUM3QixnQ0FBOEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTZXJ2ZXJQYXlsb2FkLCBQYXlsb2FkSW50ZXJmYWNlLCBTdGF0dXNNc2dJbnRlcmZhY2UgfSBmcm9tICcuL2FwaS1iYXNlLm1vZGVsJztcbmltcG9ydCB7IERvY3VtZW50VHlwZSB9IGZyb20gJy4vZG9jdW1lbnRzLmludGVyZmFjZSc7XG5pbXBvcnQgeyBDb3VudHJ5TGlzdCwgUHJvdmluY2VMaXN0IH0gZnJvbSAnLi4vbGliL2NvbXBvbmVudHMvYWRkcmVzcy9hZGRyZXNzLmNvbXBvbmVudCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3lzUGFyYW1JbnRlcmZhY2Uge1xuICBuYW1lOiBzdHJpbmc7XG4gIHZhbHVlOiBzdHJpbmc7XG59XG5cbi8qKlxuICogR2V0IENhY2hlXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2FjaGVJbnRlcmZhY2UgZXh0ZW5kcyBQYXlsb2FkSW50ZXJmYWNlIHtcbiAgY291bnRyeT86IENvdW50cnlMaXN0W107XG4gIHByb3ZpbmNlPzogUHJvdmluY2VMaXN0W107XG4gIG1lc3NhZ2VzPzogU3RhdHVzTXNnSW50ZXJmYWNlW107XG4gIHNlY1F1ZXM/OiBzdHJpbmdbXTtcbiAgZG9jdW1lbnRUeXBlPzogRG9jdW1lbnRUeXBlW107XG4gIHN5c1BhcmFtPzogU3lzUGFyYW1JbnRlcmZhY2VbXTtcbn1cblxuZXhwb3J0IGNsYXNzIENhY2hlUGF5TG9hZCBleHRlbmRzIFNlcnZlclBheWxvYWQge1xuICBjb3VudHJ5OiBDb3VudHJ5TGlzdFtdO1xuICBwcm92aW5jZTogUHJvdmluY2VMaXN0W107XG4gIG1lc3NhZ2VzOiBTdGF0dXNNc2dJbnRlcmZhY2VbXTtcbiAgc2VjUXVlczogc3RyaW5nW107XG4gIGRvY3VtZW50VHlwZTogRG9jdW1lbnRUeXBlW107XG4gIHN5c1BhcmFtOiBTeXNQYXJhbUludGVyZmFjZVtdO1xuXG4gIGNvbnN0cnVjdG9yKCBwYXlsb2FkOiBDYWNoZUludGVyZmFjZSApIHtcbiAgICBzdXBlciggcGF5bG9hZCApO1xuICAgIHRoaXMuY291bnRyeSA9IHBheWxvYWQuY291bnRyeSA/IHBheWxvYWQuY291bnRyeSA6IHVuZGVmaW5lZDtcbiAgICB0aGlzLnByb3ZpbmNlID0gcGF5bG9hZC5wcm92aW5jZSA/IHBheWxvYWQucHJvdmluY2UgOiB1bmRlZmluZWQ7XG4gICAgdGhpcy5tZXNzYWdlcyA9IHBheWxvYWQubWVzc2FnZXMgPyBwYXlsb2FkLm1lc3NhZ2VzIDogdW5kZWZpbmVkO1xuICAgIHRoaXMuc2VjUXVlcyA9IHBheWxvYWQuc2VjUXVlcyA/IHBheWxvYWQuc2VjUXVlcyA6IHVuZGVmaW5lZDtcbiAgICB0aGlzLmRvY3VtZW50VHlwZSA9IHBheWxvYWQuZG9jdW1lbnRUeXBlID8gcGF5bG9hZC5kb2N1bWVudFR5cGUgOiB1bmRlZmluZWQ7XG4gICAgdGhpcy5zeXNQYXJhbSA9IHBheWxvYWQuc3lzUGFyYW0gPyBwYXlsb2FkLnN5c1BhcmFtIDogdW5kZWZpbmVkO1xuICB9XG59XG5cbiJdfQ==