/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import * as tslib_1 from "tslib";
import { Inject } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { filter, map, mergeMap } from 'rxjs/operators';
import { Base } from 'moh-common-lib/models';
import { CommonLogger } from 'moh-common-lib/services';
/**
 * PrimeAppBase is a class containing shared functionality for the
 * various "AppComponent"s for each individual prime application. The important
 * functionality is in the constructor and ngOnInit().  Unfortunately this does
 * not come bundled with a template and instead templates must be updated for
 * each project manually.
 *
 * **Note** - you MUST call super.ngOnInit() you have an ngOnInit() method in
 * your subclass. Otherwise, the title and accessability functions concerns
 * won't update.
 */
var PrimeAppBase = /** @class */ (function (_super) {
    tslib_1.__extends(PrimeAppBase, _super);
    function PrimeAppBase(pRouter, pActivatedRoute, pTitleService, logger, version) {
        var _this = _super.call(this) || this;
        _this.pRouter = pRouter;
        _this.pActivatedRoute = pActivatedRoute;
        _this.pTitleService = pTitleService;
        _this.logger = logger;
        _this.title = 'Prime';
        _this.SKIP_CONTENT_HASH = '#content';
        version.success
            ? console.log('%c' + version.message, 'color: #036; font-size: 20px;')
            : console.error(version.message);
        return _this;
    }
    /**
     * @return {?}
     */
    PrimeAppBase.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.updateTitleOnRouteChange();
        this.pRouter.events.pipe(filter((/**
         * @param {?} ev
         * @return {?}
         */
        function (ev) { return ev instanceof NavigationEnd; }))).subscribe(this.updateSkipContentLink.bind(this));
        this.updateSkipContentLink();
    };
    /**
     * Listen to every route change, and update the page title based on the
     * 'title' property in the route's data.
     */
    /**
     * Listen to every route change, and update the page title based on the
     * 'title' property in the route's data.
     * @protected
     * @return {?}
     */
    PrimeAppBase.prototype.updateTitleOnRouteChange = /**
     * Listen to every route change, and update the page title based on the
     * 'title' property in the route's data.
     * @protected
     * @return {?}
     */
    function () {
        var _this = this;
        this.pRouter.events
            .pipe(filter((/**
         * @param {?} event
         * @return {?}
         */
        function (event) { return event instanceof NavigationEnd; })), map((/**
         * @return {?}
         */
        function () { return _this.pActivatedRoute; })), map((/**
         * @param {?} route
         * @return {?}
         */
        function (route) {
            while (route.firstChild) {
                route = route.firstChild;
            }
            return route;
        })), filter((/**
         * @param {?} route
         * @return {?}
         */
        function (route) { return route.outlet === 'primary'; })), mergeMap((/**
         * @param {?} route
         * @return {?}
         */
        function (route) { return route.data; })))
            .subscribe((/**
         * @param {?} data
         * @return {?}
         */
        function (data) {
            _this.setTitle(data.title);
            _this.logger.log({
                event: 'navigation',
                title: data.title ? data.title : _this.title,
                url: _this.pRouter.url
            });
        }));
    };
    /** Set the page title. Includes basic formatting and fallback */
    /**
     * Set the page title. Includes basic formatting and fallback
     * @protected
     * @param {?=} title
     * @return {?}
     */
    PrimeAppBase.prototype.setTitle = /**
     * Set the page title. Includes basic formatting and fallback
     * @protected
     * @param {?=} title
     * @return {?}
     */
    function (title) {
        if (title) {
            this.pTitleService.setTitle("Prime | " + title);
        }
        else {
            // Default title
            this.pTitleService.setTitle(this.title);
        }
    };
    /**
     * @param {?} url
     * @return {?}
     */
    PrimeAppBase.prototype.routeIsActive = /**
     * @param {?} url
     * @return {?}
     */
    function (url) {
        return this.pRouter.url.includes(url);
    };
    /**
     * Updates the skipToContent link which is an a11y concern.  Importantly the
     * skipToContent link must include the relevant routes / subpages that the
     * user is currently on.
     */
    /**
     * Updates the skipToContent link which is an a11y concern.  Importantly the
     * skipToContent link must include the relevant routes / subpages that the
     * user is currently on.
     * @return {?}
     */
    PrimeAppBase.prototype.updateSkipContentLink = /**
     * Updates the skipToContent link which is an a11y concern.  Importantly the
     * skipToContent link must include the relevant routes / subpages that the
     * user is currently on.
     * @return {?}
     */
    function () {
        this.skipLinkPath = this.generateSkipToContentLink();
    };
    // Slightly complicated because we have to include the deployUrl in manually.
    // If deployUrl changes this code must too.
    // Slightly complicated because we have to include the deployUrl in manually.
    // If deployUrl changes this code must too.
    /**
     * @protected
     * @return {?}
     */
    PrimeAppBase.prototype.generateSkipToContentLink = 
    // Slightly complicated because we have to include the deployUrl in manually.
    // If deployUrl changes this code must too.
    /**
     * @protected
     * @return {?}
     */
    function () {
        // don't add duplicate #contents
        if (window.location.href.indexOf(this.SKIP_CONTENT_HASH) !== -1) {
            return window.location.href;
        }
        return "" + window.location.origin + this.pRouter.url + "#content";
    };
    /** @nocollapse */
    PrimeAppBase.ctorParameters = function () { return [
        { type: Router },
        { type: ActivatedRoute },
        { type: Title },
        { type: CommonLogger },
        { type: undefined, decorators: [{ type: Inject, args: ['APP_VERSION',] }] }
    ]; };
    return PrimeAppBase;
}(Base));
export { PrimeAppBase };
if (false) {
    /** @type {?} */
    PrimeAppBase.prototype.title;
    /** @type {?} */
    PrimeAppBase.prototype.skipLinkPath;
    /**
     * @type {?}
     * @private
     */
    PrimeAppBase.prototype.SKIP_CONTENT_HASH;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.pRouter;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.pActivatedRoute;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.pTitleService;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.logger;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLWJhc2UuY2xhc3MuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9wcmltZS1jb3JlLyIsInNvdXJjZXMiOlsibW9kZWxzL2FwcC1iYXNlLmNsYXNzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsT0FBTyxFQUFVLE1BQU0sRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMvQyxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDbEQsT0FBTyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsY0FBYyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDeEUsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzdDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQzs7Ozs7Ozs7Ozs7O0FBYXZEO0lBQWtDLHdDQUFJO0lBS3BDLHNCQUF1QixPQUFlLEVBQ2YsZUFBK0IsRUFDL0IsYUFBb0IsRUFDcEIsTUFBb0IsRUFDUCxPQUFPO1FBSjNDLFlBS0UsaUJBQU8sU0FJUjtRQVRzQixhQUFPLEdBQVAsT0FBTyxDQUFRO1FBQ2YscUJBQWUsR0FBZixlQUFlLENBQWdCO1FBQy9CLG1CQUFhLEdBQWIsYUFBYSxDQUFPO1FBQ3BCLFlBQU0sR0FBTixNQUFNLENBQWM7UUFQM0MsV0FBSyxHQUFHLE9BQU8sQ0FBQztRQUVSLHVCQUFpQixHQUFHLFVBQVUsQ0FBQztRQVFyQyxPQUFPLENBQUMsT0FBTztZQUNiLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxFQUFFLCtCQUErQixDQUFDO1lBQ3RFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQzs7SUFDckMsQ0FBQzs7OztJQUVELCtCQUFROzs7SUFBUjtRQUNFLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FDdEIsTUFBTTs7OztRQUFDLFVBQUEsRUFBRSxJQUFJLE9BQUEsRUFBRSxZQUFZLGFBQWEsRUFBM0IsQ0FBMkIsRUFBQyxDQUMxQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFbkQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7T0FHRzs7Ozs7OztJQUNPLCtDQUF3Qjs7Ozs7O0lBQWxDO1FBQUEsaUJBc0JDO1FBckJDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTTthQUNoQixJQUFJLENBQ0gsTUFBTTs7OztRQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxZQUFZLGFBQWEsRUFBOUIsQ0FBOEIsRUFBQyxFQUMvQyxHQUFHOzs7UUFBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLGVBQWUsRUFBcEIsQ0FBb0IsRUFBQyxFQUMvQixHQUFHOzs7O1FBQUMsVUFBQSxLQUFLO1lBQ1AsT0FBTyxLQUFLLENBQUMsVUFBVSxFQUFFO2dCQUN2QixLQUFLLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQzthQUMxQjtZQUNELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQyxFQUFDLEVBQ0YsTUFBTTs7OztRQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQTFCLENBQTBCLEVBQUMsRUFDM0MsUUFBUTs7OztRQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxDQUFDLElBQUksRUFBVixDQUFVLEVBQUMsQ0FDOUI7YUFDQSxTQUFTOzs7O1FBQUMsVUFBQyxJQUF3QjtZQUNsQyxLQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMxQixLQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxLQUFLLEVBQUUsWUFBWTtnQkFDbkIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxLQUFLO2dCQUMzQyxHQUFHLEVBQUUsS0FBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHO2FBQ3RCLENBQUMsQ0FBQztRQUNMLENBQUMsRUFBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELGlFQUFpRTs7Ozs7OztJQUN2RCwrQkFBUTs7Ozs7O0lBQWxCLFVBQW1CLEtBQWM7UUFDL0IsSUFBSSxLQUFLLEVBQUU7WUFDVCxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxhQUFXLEtBQU8sQ0FBQyxDQUFDO1NBQ2pEO2FBQU07WUFDTCxnQkFBZ0I7WUFDaEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3pDO0lBQ0gsQ0FBQzs7Ozs7SUFFRCxvQ0FBYTs7OztJQUFiLFVBQWMsR0FBVztRQUN2QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQ7Ozs7T0FJRzs7Ozs7OztJQUNILDRDQUFxQjs7Ozs7O0lBQXJCO1FBQ0UsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztJQUN2RCxDQUFDO0lBRUQsNkVBQTZFO0lBQzdFLDJDQUEyQzs7Ozs7OztJQUVqQyxnREFBeUI7Ozs7Ozs7SUFBbkM7UUFDRSxnQ0FBZ0M7UUFDaEMsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDL0QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztTQUM3QjtRQUNELE9BQU8sS0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsYUFBVSxDQUFDO0lBQ2hFLENBQUM7OztnQkFyR00sTUFBTTtnQkFBaUIsY0FBYztnQkFEckMsS0FBSztnQkFJTCxZQUFZO2dEQXNCTCxNQUFNLFNBQUMsYUFBYTs7SUE2RXBDLG1CQUFDO0NBQUEsQUF0RkQsQ0FBa0MsSUFBSSxHQXNGckM7U0F0RlksWUFBWTs7O0lBQ3ZCLDZCQUFnQjs7SUFDaEIsb0NBQW9COzs7OztJQUNwQix5Q0FBdUM7Ozs7O0lBRTFCLCtCQUF5Qjs7Ozs7SUFDekIsdUNBQXlDOzs7OztJQUN6QyxxQ0FBOEI7Ozs7O0lBQzlCLDhCQUE4QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE9uSW5pdCwgSW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBUaXRsZSB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kLCBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQgeyBmaWx0ZXIsIG1hcCwgbWVyZ2VNYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBCYXNlIH0gZnJvbSAnbW9oLWNvbW1vbi1saWIvbW9kZWxzJztcbmltcG9ydCB7IENvbW1vbkxvZ2dlciB9IGZyb20gJ21vaC1jb21tb24tbGliL3NlcnZpY2VzJztcblxuLyoqXG4gKiBQcmltZUFwcEJhc2UgaXMgYSBjbGFzcyBjb250YWluaW5nIHNoYXJlZCBmdW5jdGlvbmFsaXR5IGZvciB0aGVcbiAqIHZhcmlvdXMgXCJBcHBDb21wb25lbnRcInMgZm9yIGVhY2ggaW5kaXZpZHVhbCBwcmltZSBhcHBsaWNhdGlvbi4gVGhlIGltcG9ydGFudFxuICogZnVuY3Rpb25hbGl0eSBpcyBpbiB0aGUgY29uc3RydWN0b3IgYW5kIG5nT25Jbml0KCkuICBVbmZvcnR1bmF0ZWx5IHRoaXMgZG9lc1xuICogbm90IGNvbWUgYnVuZGxlZCB3aXRoIGEgdGVtcGxhdGUgYW5kIGluc3RlYWQgdGVtcGxhdGVzIG11c3QgYmUgdXBkYXRlZCBmb3JcbiAqIGVhY2ggcHJvamVjdCBtYW51YWxseS5cbiAqXG4gKiAqKk5vdGUqKiAtIHlvdSBNVVNUIGNhbGwgc3VwZXIubmdPbkluaXQoKSB5b3UgaGF2ZSBhbiBuZ09uSW5pdCgpIG1ldGhvZCBpblxuICogeW91ciBzdWJjbGFzcy4gT3RoZXJ3aXNlLCB0aGUgdGl0bGUgYW5kIGFjY2Vzc2FiaWxpdHkgZnVuY3Rpb25zIGNvbmNlcm5zXG4gKiB3b24ndCB1cGRhdGUuXG4gKi9cbmV4cG9ydCBjbGFzcyBQcmltZUFwcEJhc2UgZXh0ZW5kcyBCYXNlIGltcGxlbWVudHMgT25Jbml0IHtcbiAgdGl0bGUgPSAnUHJpbWUnO1xuICBwdWJsaWMgc2tpcExpbmtQYXRoO1xuICBwcml2YXRlIFNLSVBfQ09OVEVOVF9IQVNIID0gJyNjb250ZW50JztcblxuICBjb25zdHJ1Y3RvciggcHJvdGVjdGVkIHBSb3V0ZXI6IFJvdXRlcixcbiAgICAgICAgICAgICAgIHByb3RlY3RlZCBwQWN0aXZhdGVkUm91dGU6IEFjdGl2YXRlZFJvdXRlLFxuICAgICAgICAgICAgICAgcHJvdGVjdGVkIHBUaXRsZVNlcnZpY2U6IFRpdGxlLFxuICAgICAgICAgICAgICAgcHJvdGVjdGVkIGxvZ2dlcjogQ29tbW9uTG9nZ2VyLFxuICAgICAgICAgICAgICAgQEluamVjdCgnQVBQX1ZFUlNJT04nKSB2ZXJzaW9uICkge1xuICAgIHN1cGVyKCk7XG4gICAgdmVyc2lvbi5zdWNjZXNzXG4gICAgICA/IGNvbnNvbGUubG9nKCclYycgKyB2ZXJzaW9uLm1lc3NhZ2UsICdjb2xvcjogIzAzNjsgZm9udC1zaXplOiAyMHB4OycpXG4gICAgICA6IGNvbnNvbGUuZXJyb3IodmVyc2lvbi5tZXNzYWdlKTtcbiAgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMudXBkYXRlVGl0bGVPblJvdXRlQ2hhbmdlKCk7XG4gICAgdGhpcy5wUm91dGVyLmV2ZW50cy5waXBlKFxuICAgICAgZmlsdGVyKGV2ID0+IGV2IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCksXG4gICAgKS5zdWJzY3JpYmUodGhpcy51cGRhdGVTa2lwQ29udGVudExpbmsuYmluZCh0aGlzKSk7XG5cbiAgICB0aGlzLnVwZGF0ZVNraXBDb250ZW50TGluaygpO1xuICB9XG5cbiAgLyoqXG4gICAqIExpc3RlbiB0byBldmVyeSByb3V0ZSBjaGFuZ2UsIGFuZCB1cGRhdGUgdGhlIHBhZ2UgdGl0bGUgYmFzZWQgb24gdGhlXG4gICAqICd0aXRsZScgcHJvcGVydHkgaW4gdGhlIHJvdXRlJ3MgZGF0YS5cbiAgICovXG4gIHByb3RlY3RlZCB1cGRhdGVUaXRsZU9uUm91dGVDaGFuZ2UoKSB7XG4gICAgdGhpcy5wUm91dGVyLmV2ZW50c1xuICAgICAgLnBpcGUoXG4gICAgICAgIGZpbHRlcihldmVudCA9PiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpLFxuICAgICAgICBtYXAoKCkgPT4gdGhpcy5wQWN0aXZhdGVkUm91dGUpLFxuICAgICAgICBtYXAocm91dGUgPT4ge1xuICAgICAgICAgIHdoaWxlIChyb3V0ZS5maXJzdENoaWxkKSB7XG4gICAgICAgICAgICByb3V0ZSA9IHJvdXRlLmZpcnN0Q2hpbGQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiByb3V0ZTtcbiAgICAgICAgfSksXG4gICAgICAgIGZpbHRlcihyb3V0ZSA9PiByb3V0ZS5vdXRsZXQgPT09ICdwcmltYXJ5JyksXG4gICAgICAgIG1lcmdlTWFwKHJvdXRlID0+IHJvdXRlLmRhdGEpXG4gICAgICApXG4gICAgICAuc3Vic2NyaWJlKChkYXRhOiB7IHRpdGxlPzogc3RyaW5nIH0pID0+IHtcbiAgICAgICAgdGhpcy5zZXRUaXRsZShkYXRhLnRpdGxlKTtcbiAgICAgICAgdGhpcy5sb2dnZXIubG9nKHtcbiAgICAgICAgICBldmVudDogJ25hdmlnYXRpb24nLFxuICAgICAgICAgIHRpdGxlOiBkYXRhLnRpdGxlID8gZGF0YS50aXRsZSA6IHRoaXMudGl0bGUsXG4gICAgICAgICAgdXJsOiB0aGlzLnBSb3V0ZXIudXJsXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH1cblxuICAvKiogU2V0IHRoZSBwYWdlIHRpdGxlLiBJbmNsdWRlcyBiYXNpYyBmb3JtYXR0aW5nIGFuZCBmYWxsYmFjayAqL1xuICBwcm90ZWN0ZWQgc2V0VGl0bGUodGl0bGU/OiBzdHJpbmcpIHtcbiAgICBpZiAodGl0bGUpIHtcbiAgICAgIHRoaXMucFRpdGxlU2VydmljZS5zZXRUaXRsZShgUHJpbWUgfCAke3RpdGxlfWApO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBEZWZhdWx0IHRpdGxlXG4gICAgICB0aGlzLnBUaXRsZVNlcnZpY2Uuc2V0VGl0bGUodGhpcy50aXRsZSk7XG4gICAgfVxuICB9XG5cbiAgcm91dGVJc0FjdGl2ZSh1cmw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnBSb3V0ZXIudXJsLmluY2x1ZGVzKHVybCk7XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlcyB0aGUgc2tpcFRvQ29udGVudCBsaW5rIHdoaWNoIGlzIGFuIGExMXkgY29uY2Vybi4gIEltcG9ydGFudGx5IHRoZVxuICAgKiBza2lwVG9Db250ZW50IGxpbmsgbXVzdCBpbmNsdWRlIHRoZSByZWxldmFudCByb3V0ZXMgLyBzdWJwYWdlcyB0aGF0IHRoZVxuICAgKiB1c2VyIGlzIGN1cnJlbnRseSBvbi5cbiAgICovXG4gIHVwZGF0ZVNraXBDb250ZW50TGluaygpIHtcbiAgICB0aGlzLnNraXBMaW5rUGF0aCA9IHRoaXMuZ2VuZXJhdGVTa2lwVG9Db250ZW50TGluaygpO1xuICB9XG5cbiAgLy8gU2xpZ2h0bHkgY29tcGxpY2F0ZWQgYmVjYXVzZSB3ZSBoYXZlIHRvIGluY2x1ZGUgdGhlIGRlcGxveVVybCBpbiBtYW51YWxseS5cbiAgLy8gSWYgZGVwbG95VXJsIGNoYW5nZXMgdGhpcyBjb2RlIG11c3QgdG9vLlxuXG4gIHByb3RlY3RlZCBnZW5lcmF0ZVNraXBUb0NvbnRlbnRMaW5rKCk6IHN0cmluZyB7XG4gICAgLy8gZG9uJ3QgYWRkIGR1cGxpY2F0ZSAjY29udGVudHNcbiAgICBpZiAod2luZG93LmxvY2F0aW9uLmhyZWYuaW5kZXhPZih0aGlzLlNLSVBfQ09OVEVOVF9IQVNIKSAhPT0gLTEpIHtcbiAgICAgIHJldHVybiB3aW5kb3cubG9jYXRpb24uaHJlZjtcbiAgICB9XG4gICAgcmV0dXJuIGAke3dpbmRvdy5sb2NhdGlvbi5vcmlnaW59JHt0aGlzLnBSb3V0ZXIudXJsfSNjb250ZW50YDtcbiAgfVxufVxuIl19