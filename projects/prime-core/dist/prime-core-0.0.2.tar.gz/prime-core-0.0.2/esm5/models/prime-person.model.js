/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import * as tslib_1 from "tslib";
import { Person, Address } from 'moh-common-lib/models';
var PrimePerson = /** @class */ (function (_super) {
    tslib_1.__extends(PrimePerson, _super);
    function PrimePerson() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**
         * Identify and mailing addresses
         */
        _this.address = new Address();
        _this.mailAddress = new Address();
        _this.identityIsMailingAddress = true;
        return _this;
    }
    /* Copy function */
    /* Copy function */
    /**
     * @param {?} object
     * @return {?}
     */
    PrimePerson.prototype.copy = /* Copy function */
    /**
     * @param {?} object
     * @return {?}
     */
    function (object) {
        _super.prototype.copy.call(this, object);
        this.preferredFirstName = object.preferredFirstName;
        this.preferredMiddleName = object.preferredMiddleName;
        this.preferredLastName = object.preferredLastName;
        this.address.copy(object.address);
        this.mailAddress.copy(object.mailAddress);
    };
    return PrimePerson;
}(Person));
export { PrimePerson };
if (false) {
    /**
     * Parts of a person's name
     * @type {?}
     */
    PrimePerson.prototype.preferredFirstName;
    /** @type {?} */
    PrimePerson.prototype.preferredMiddleName;
    /** @type {?} */
    PrimePerson.prototype.preferredLastName;
    /**
     * Identify and mailing addresses
     * @type {?}
     */
    PrimePerson.prototype.address;
    /** @type {?} */
    PrimePerson.prototype.mailAddress;
    /** @type {?} */
    PrimePerson.prototype.identityIsMailingAddress;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpbWUtcGVyc29uLm1vZGVsLmpzIiwic291cmNlUm9vdCI6Im5nOi8vcHJpbWUtY29yZS8iLCJzb3VyY2VzIjpbIm1vZGVscy9wcmltZS1wZXJzb24ubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBRXhEO0lBQWlDLHVDQUFNO0lBQXZDO1FBQUEscUVBc0JDOzs7O1FBZlEsYUFBTyxHQUFZLElBQUksT0FBTyxFQUFFLENBQUM7UUFDakMsaUJBQVcsR0FBWSxJQUFJLE9BQU8sRUFBRSxDQUFDO1FBQ3JDLDhCQUF3QixHQUFHLElBQUksQ0FBQzs7SUFhekMsQ0FBQztJQVZDLG1CQUFtQjs7Ozs7O0lBQ25CLDBCQUFJOzs7OztJQUFKLFVBQUssTUFBbUI7UUFDdEIsaUJBQU0sSUFBSSxZQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsa0JBQWtCLENBQUM7UUFDcEQsSUFBSSxDQUFDLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQztRQUN0RCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBRWxELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNILGtCQUFDO0FBQUQsQ0FBQyxBQXRCRCxDQUFpQyxNQUFNLEdBc0J0Qzs7Ozs7OztJQXBCQyx5Q0FBa0M7O0lBQ2xDLDBDQUFtQzs7SUFDbkMsd0NBQWlDOzs7OztJQUdqQyw4QkFBd0M7O0lBQ3hDLGtDQUE0Qzs7SUFDNUMsK0NBQXVDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGVyc29uLCBBZGRyZXNzIH0gZnJvbSAnbW9oLWNvbW1vbi1saWIvbW9kZWxzJztcblxuZXhwb3J0IGNsYXNzIFByaW1lUGVyc29uIGV4dGVuZHMgUGVyc29uIHtcbiAgLyoqIFBhcnRzIG9mIGEgcGVyc29uJ3MgbmFtZSAqL1xuICBwdWJsaWMgcHJlZmVycmVkRmlyc3ROYW1lOiBzdHJpbmc7XG4gIHB1YmxpYyBwcmVmZXJyZWRNaWRkbGVOYW1lOiBzdHJpbmc7XG4gIHB1YmxpYyBwcmVmZXJyZWRMYXN0TmFtZTogc3RyaW5nO1xuXG4gIC8qKiBJZGVudGlmeSBhbmQgbWFpbGluZyBhZGRyZXNzZXMgKi9cbiAgcHVibGljIGFkZHJlc3M6IEFkZHJlc3MgPSBuZXcgQWRkcmVzcygpO1xuICBwdWJsaWMgbWFpbEFkZHJlc3M6IEFkZHJlc3MgPSBuZXcgQWRkcmVzcygpO1xuICBwdWJsaWMgaWRlbnRpdHlJc01haWxpbmdBZGRyZXNzID0gdHJ1ZTtcblxuXG4gIC8qIENvcHkgZnVuY3Rpb24gKi9cbiAgY29weShvYmplY3Q6IFByaW1lUGVyc29uKSB7XG4gICAgc3VwZXIuY29weShvYmplY3QpO1xuICAgIHRoaXMucHJlZmVycmVkRmlyc3ROYW1lID0gb2JqZWN0LnByZWZlcnJlZEZpcnN0TmFtZTtcbiAgICB0aGlzLnByZWZlcnJlZE1pZGRsZU5hbWUgPSBvYmplY3QucHJlZmVycmVkTWlkZGxlTmFtZTtcbiAgICB0aGlzLnByZWZlcnJlZExhc3ROYW1lID0gb2JqZWN0LnByZWZlcnJlZExhc3ROYW1lO1xuXG4gICAgdGhpcy5hZGRyZXNzLmNvcHkob2JqZWN0LmFkZHJlc3MpO1xuICAgIHRoaXMubWFpbEFkZHJlc3MuY29weShvYmplY3QubWFpbEFkZHJlc3MpO1xuICB9XG59XG4iXX0=