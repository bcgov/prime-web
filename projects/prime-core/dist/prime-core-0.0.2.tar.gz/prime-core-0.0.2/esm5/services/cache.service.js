/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CacheApiService } from './cache-api.service';
import { map } from 'rxjs/operators';
import * as i0 from "@angular/core";
import * as i1 from "./cache-api.service";
/**
 * TODO: Set up service to store data returned from the cache service once
 *       determined how it will be configured/setup
 */
var CacheService = /** @class */ (function () {
    function CacheService(cacheApiService) {
        this.cacheApiService = cacheApiService;
        // We use private BehaviorSubjects to cache results instead of having repeat
        // HTTP requests. This way the response is cached for the lifetime of the
        // session.
        this.$provinceListSubject = new BehaviorSubject([]);
        this.$countrylistSubject = new BehaviorSubject([]);
        this.$enhancedMessagesSubject = new BehaviorSubject([]);
        this.$sysParamListSubject = new BehaviorSubject([]);
        /**
         * Message List
         * Populated via call to reg/rest/getCache?param=messages
         */
        this.$enhancedMsgList = this.$enhancedMessagesSubject.asObservable();
        /**
         * Country List
         * Populated via call to reg/rest/getCache?param=countries
         */
        this.$countryList = this.$countrylistSubject.asObservable();
        /**
         * Province List
         * Populated via call to reg/rest/getCache?param=provinces
         */
        this.$provinceList = this.$provinceListSubject.asObservable();
        /**
         * System Parameter List
         * Populated via call to reg/rest/getCache?param=sysParam
         */
        this.$sysParamList = this.$sysParamListSubject.asObservable();
        this.setupBehaviorSubject('provinces', 'province', this.$provinceListSubject);
        this.setupBehaviorSubject('countries', 'country', this.$countrylistSubject);
        this.setupBehaviorSubject('messages', 'messages', this.$enhancedMessagesSubject);
        this.setupBehaviorSubject('sysParams', 'sysParam', this.$sysParamListSubject);
    }
    /**
     * A simple helper to setup BehaviorSubjects and Observables with API data.
     * HTTP requests will be sent out immediately at application load.
     *
     * We use BehaviorSubjects to cache values to stop repeat responses. This
     * requires that the properties are already setup on the class, including the
     * Observable and BehaviorSubject.
     *
     * @param cacheName the name of the parameter to pass to getCache()
     * @param propertyName the name of the property on the response we want
     * @param $subject the BehaviorSubject to emit the value found at propertyName
     */
    /**
     * A simple helper to setup BehaviorSubjects and Observables with API data.
     * HTTP requests will be sent out immediately at application load.
     *
     * We use BehaviorSubjects to cache values to stop repeat responses. This
     * requires that the properties are already setup on the class, including the
     * Observable and BehaviorSubject.
     *
     * @protected
     * @template T
     * @param {?} cacheName the name of the parameter to pass to getCache()
     * @param {?} propertyName the name of the property on the response we want
     * @param {?} $subject the BehaviorSubject to emit the value found at propertyName
     * @return {?}
     */
    CacheService.prototype.setupBehaviorSubject = /**
     * A simple helper to setup BehaviorSubjects and Observables with API data.
     * HTTP requests will be sent out immediately at application load.
     *
     * We use BehaviorSubjects to cache values to stop repeat responses. This
     * requires that the properties are already setup on the class, including the
     * Observable and BehaviorSubject.
     *
     * @protected
     * @template T
     * @param {?} cacheName the name of the parameter to pass to getCache()
     * @param {?} propertyName the name of the property on the response we want
     * @param {?} $subject the BehaviorSubject to emit the value found at propertyName
     * @return {?}
     */
    function (cacheName, propertyName, $subject) {
        this.cacheApiService
            .getCache(cacheName)
            .pipe(map((/**
         * @param {?} x
         * @return {?}
         */
        function (x) { return x[propertyName]; })))
            .subscribe((/**
         * @param {?} val
         * @return {?}
         */
        function (val) { return $subject.next(val); }));
    };
    CacheService.decorators = [
        { type: Injectable, args: [{ providedIn: 'root' },] }
    ];
    /** @nocollapse */
    CacheService.ctorParameters = function () { return [
        { type: CacheApiService }
    ]; };
    /** @nocollapse */ CacheService.ngInjectableDef = i0.defineInjectable({ factory: function CacheService_Factory() { return new CacheService(i0.inject(i1.CacheApiService)); }, token: CacheService, providedIn: "root" });
    return CacheService;
}());
export { CacheService };
if (false) {
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$provinceListSubject;
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$countrylistSubject;
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$enhancedMessagesSubject;
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$sysParamListSubject;
    /**
     * Message List
     * Populated via call to reg/rest/getCache?param=messages
     * @type {?}
     */
    CacheService.prototype.$enhancedMsgList;
    /**
     * Country List
     * Populated via call to reg/rest/getCache?param=countries
     * @type {?}
     */
    CacheService.prototype.$countryList;
    /**
     * Province List
     * Populated via call to reg/rest/getCache?param=provinces
     * @type {?}
     */
    CacheService.prototype.$provinceList;
    /**
     * System Parameter List
     * Populated via call to reg/rest/getCache?param=sysParam
     * @type {?}
     */
    CacheService.prototype.$sysParamList;
    /**
     * @type {?}
     * @protected
     */
    CacheService.prototype.cacheApiService;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL3ByaW1lLWNvcmUvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jYWNoZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBYyxlQUFlLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDbkQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7Ozs7OztBQVFyQztJQWlERSxzQkFBc0IsZUFBZ0M7UUFBaEMsb0JBQWUsR0FBZixlQUFlLENBQWlCOzs7O1FBNUM5Qyx5QkFBb0IsR0FFeEIsSUFBSSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEIsd0JBQW1CLEdBRXZCLElBQUksZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3BCLDZCQUF3QixHQUU1QixJQUFJLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwQix5QkFBb0IsR0FFeEIsSUFBSSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7Ozs7O1FBT3JCLHFCQUFnQixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFNaEUsaUJBQVksR0FFZixJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLENBQUM7Ozs7O1FBTXJDLGtCQUFhLEdBRWhCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFNdEMsa0JBQWEsR0FFaEIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxDQUFDO1FBRzNDLElBQUksQ0FBQyxvQkFBb0IsQ0FDdkIsV0FBVyxFQUNYLFVBQVUsRUFDVixJQUFJLENBQUMsb0JBQW9CLENBQzFCLENBQUM7UUFDRixJQUFJLENBQUMsb0JBQW9CLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsb0JBQW9CLENBQ3ZCLFVBQVUsRUFDVixVQUFVLEVBQ1YsSUFBSSxDQUFDLHdCQUF3QixDQUM5QixDQUFDO1FBQ0YsSUFBSSxDQUFDLG9CQUFvQixDQUN2QixXQUFXLEVBQ1gsVUFBVSxFQUNWLElBQUksQ0FBQyxvQkFBb0IsQ0FDMUIsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRzs7Ozs7Ozs7Ozs7Ozs7OztJQUNPLDJDQUFvQjs7Ozs7Ozs7Ozs7Ozs7O0lBQTlCLFVBQ0UsU0FBaUIsRUFDakIsWUFBb0IsRUFDcEIsUUFBNEI7UUFFNUIsSUFBSSxDQUFDLGVBQWU7YUFDakIsUUFBUSxDQUFDLFNBQVMsQ0FBQzthQUNuQixJQUFJLENBQUMsR0FBRzs7OztRQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFmLENBQWUsRUFBQyxDQUFDO2FBQy9CLFNBQVM7Ozs7UUFBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQWxCLENBQWtCLEVBQUMsQ0FBQztJQUMxQyxDQUFDOztnQkF6RkYsVUFBVSxTQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRTs7OztnQkFUekIsZUFBZTs7O3VCQUZ4QjtDQXFHQyxBQTFGRCxJQTBGQztTQXpGWSxZQUFZOzs7Ozs7SUFJdkIsNENBRTRCOzs7OztJQUM1QiwyQ0FFNEI7Ozs7O0lBQzVCLGdEQUU0Qjs7Ozs7SUFDNUIsNENBRTRCOzs7Ozs7SUFPNUIsd0NBQXVFOzs7Ozs7SUFNdkUsb0NBRTRDOzs7Ozs7SUFNNUMscUNBRTZDOzs7Ozs7SUFNN0MscUNBRTZDOzs7OztJQUVqQyx1Q0FBMEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IENhY2hlQXBpU2VydmljZSB9IGZyb20gJy4vY2FjaGUtYXBpLnNlcnZpY2UnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgU3RhdHVzTXNnSW50ZXJmYWNlIH0gZnJvbSAnLi4vbW9kZWxzL2FwaS1iYXNlLm1vZGVsJztcbmltcG9ydCB7IFN5c1BhcmFtSW50ZXJmYWNlIH0gZnJvbSAnLi4vbW9kZWxzL2NhY2hlLWFwaS5tb2RlbCc7XG5pbXBvcnQgeyBQcm92aW5jZUxpc3QsIENvdW50cnlMaXN0IH0gZnJvbSAnLi4vbGliL2NvbXBvbmVudHMvYWRkcmVzcy9hZGRyZXNzLmNvbXBvbmVudCc7XG4vKipcbiAqIFRPRE86IFNldCB1cCBzZXJ2aWNlIHRvIHN0b3JlIGRhdGEgcmV0dXJuZWQgZnJvbSB0aGUgY2FjaGUgc2VydmljZSBvbmNlXG4gKiAgICAgICBkZXRlcm1pbmVkIGhvdyBpdCB3aWxsIGJlIGNvbmZpZ3VyZWQvc2V0dXBcbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBDYWNoZVNlcnZpY2Uge1xuICAvLyBXZSB1c2UgcHJpdmF0ZSBCZWhhdmlvclN1YmplY3RzIHRvIGNhY2hlIHJlc3VsdHMgaW5zdGVhZCBvZiBoYXZpbmcgcmVwZWF0XG4gIC8vIEhUVFAgcmVxdWVzdHMuIFRoaXMgd2F5IHRoZSByZXNwb25zZSBpcyBjYWNoZWQgZm9yIHRoZSBsaWZldGltZSBvZiB0aGVcbiAgLy8gc2Vzc2lvbi5cbiAgcHJpdmF0ZSAkcHJvdmluY2VMaXN0U3ViamVjdDogQmVoYXZpb3JTdWJqZWN0PFxuICAgIFByb3ZpbmNlTGlzdFtdXG4gID4gPSBuZXcgQmVoYXZpb3JTdWJqZWN0KFtdKTtcbiAgcHJpdmF0ZSAkY291bnRyeWxpc3RTdWJqZWN0OiBCZWhhdmlvclN1YmplY3Q8XG4gICAgQ291bnRyeUxpc3RbXVxuICA+ID0gbmV3IEJlaGF2aW9yU3ViamVjdChbXSk7XG4gIHByaXZhdGUgJGVuaGFuY2VkTWVzc2FnZXNTdWJqZWN0OiBCZWhhdmlvclN1YmplY3Q8XG4gICAgU3RhdHVzTXNnSW50ZXJmYWNlW11cbiAgPiA9IG5ldyBCZWhhdmlvclN1YmplY3QoW10pO1xuICBwcml2YXRlICRzeXNQYXJhbUxpc3RTdWJqZWN0OiBCZWhhdmlvclN1YmplY3Q8XG4gICAgU3lzUGFyYW1JbnRlcmZhY2VbXVxuICA+ID0gbmV3IEJlaGF2aW9yU3ViamVjdChbXSk7XG5cblxuICAvKipcbiAgICogTWVzc2FnZSBMaXN0XG4gICAqIFBvcHVsYXRlZCB2aWEgY2FsbCB0byByZWcvcmVzdC9nZXRDYWNoZT9wYXJhbT1tZXNzYWdlc1xuICAgKi9cbiAgcHVibGljICRlbmhhbmNlZE1zZ0xpc3QgPSB0aGlzLiRlbmhhbmNlZE1lc3NhZ2VzU3ViamVjdC5hc09ic2VydmFibGUoKTtcblxuICAvKipcbiAgICogQ291bnRyeSBMaXN0XG4gICAqIFBvcHVsYXRlZCB2aWEgY2FsbCB0byByZWcvcmVzdC9nZXRDYWNoZT9wYXJhbT1jb3VudHJpZXNcbiAgICovXG4gIHB1YmxpYyAkY291bnRyeUxpc3Q6IE9ic2VydmFibGU8XG4gICAgQ291bnRyeUxpc3RbXVxuICA+ID0gdGhpcy4kY291bnRyeWxpc3RTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuXG4gIC8qKlxuICAgKiBQcm92aW5jZSBMaXN0XG4gICAqIFBvcHVsYXRlZCB2aWEgY2FsbCB0byByZWcvcmVzdC9nZXRDYWNoZT9wYXJhbT1wcm92aW5jZXNcbiAgICovXG4gIHB1YmxpYyAkcHJvdmluY2VMaXN0OiBPYnNlcnZhYmxlPFxuICAgIFByb3ZpbmNlTGlzdFtdXG4gID4gPSB0aGlzLiRwcm92aW5jZUxpc3RTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuXG4gIC8qKlxuICAgKiBTeXN0ZW0gUGFyYW1ldGVyIExpc3RcbiAgICogUG9wdWxhdGVkIHZpYSBjYWxsIHRvIHJlZy9yZXN0L2dldENhY2hlP3BhcmFtPXN5c1BhcmFtXG4gICAqL1xuICBwdWJsaWMgJHN5c1BhcmFtTGlzdDogT2JzZXJ2YWJsZTxcbiAgICBTeXNQYXJhbUludGVyZmFjZVtdXG4gID4gPSB0aGlzLiRzeXNQYXJhbUxpc3RTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuXG4gIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBjYWNoZUFwaVNlcnZpY2U6IENhY2hlQXBpU2VydmljZSkge1xuICAgIHRoaXMuc2V0dXBCZWhhdmlvclN1YmplY3QoXG4gICAgICAncHJvdmluY2VzJyxcbiAgICAgICdwcm92aW5jZScsXG4gICAgICB0aGlzLiRwcm92aW5jZUxpc3RTdWJqZWN0XG4gICAgKTtcbiAgICB0aGlzLnNldHVwQmVoYXZpb3JTdWJqZWN0KCdjb3VudHJpZXMnLCAnY291bnRyeScsIHRoaXMuJGNvdW50cnlsaXN0U3ViamVjdCk7XG4gICAgdGhpcy5zZXR1cEJlaGF2aW9yU3ViamVjdChcbiAgICAgICdtZXNzYWdlcycsXG4gICAgICAnbWVzc2FnZXMnLFxuICAgICAgdGhpcy4kZW5oYW5jZWRNZXNzYWdlc1N1YmplY3RcbiAgICApO1xuICAgIHRoaXMuc2V0dXBCZWhhdmlvclN1YmplY3QoXG4gICAgICAnc3lzUGFyYW1zJyxcbiAgICAgICdzeXNQYXJhbScsXG4gICAgICB0aGlzLiRzeXNQYXJhbUxpc3RTdWJqZWN0XG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBIHNpbXBsZSBoZWxwZXIgdG8gc2V0dXAgQmVoYXZpb3JTdWJqZWN0cyBhbmQgT2JzZXJ2YWJsZXMgd2l0aCBBUEkgZGF0YS5cbiAgICogSFRUUCByZXF1ZXN0cyB3aWxsIGJlIHNlbnQgb3V0IGltbWVkaWF0ZWx5IGF0IGFwcGxpY2F0aW9uIGxvYWQuXG4gICAqXG4gICAqIFdlIHVzZSBCZWhhdmlvclN1YmplY3RzIHRvIGNhY2hlIHZhbHVlcyB0byBzdG9wIHJlcGVhdCByZXNwb25zZXMuIFRoaXNcbiAgICogcmVxdWlyZXMgdGhhdCB0aGUgcHJvcGVydGllcyBhcmUgYWxyZWFkeSBzZXR1cCBvbiB0aGUgY2xhc3MsIGluY2x1ZGluZyB0aGVcbiAgICogT2JzZXJ2YWJsZSBhbmQgQmVoYXZpb3JTdWJqZWN0LlxuICAgKlxuICAgKiBAcGFyYW0gY2FjaGVOYW1lIHRoZSBuYW1lIG9mIHRoZSBwYXJhbWV0ZXIgdG8gcGFzcyB0byBnZXRDYWNoZSgpXG4gICAqIEBwYXJhbSBwcm9wZXJ0eU5hbWUgdGhlIG5hbWUgb2YgdGhlIHByb3BlcnR5IG9uIHRoZSByZXNwb25zZSB3ZSB3YW50XG4gICAqIEBwYXJhbSAkc3ViamVjdCB0aGUgQmVoYXZpb3JTdWJqZWN0IHRvIGVtaXQgdGhlIHZhbHVlIGZvdW5kIGF0IHByb3BlcnR5TmFtZVxuICAgKi9cbiAgcHJvdGVjdGVkIHNldHVwQmVoYXZpb3JTdWJqZWN0PFQ+KFxuICAgIGNhY2hlTmFtZTogc3RyaW5nLFxuICAgIHByb3BlcnR5TmFtZTogc3RyaW5nLFxuICAgICRzdWJqZWN0OiBCZWhhdmlvclN1YmplY3Q8VD5cbiAgKSB7XG4gICAgdGhpcy5jYWNoZUFwaVNlcnZpY2VcbiAgICAgIC5nZXRDYWNoZShjYWNoZU5hbWUpXG4gICAgICAucGlwZShtYXAoeCA9PiB4W3Byb3BlcnR5TmFtZV0pKVxuICAgICAgLnN1YnNjcmliZSh2YWwgPT4gJHN1YmplY3QubmV4dCh2YWwpKTtcbiAgfVxufVxuIl19