/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of prime-core
 */
export { PrimeCoreModule } from './lib/prime-core.module';
// Models
export { PrimeConstants, ProviderCode, AssuranceLevel } from './models/prime-constants';
export { PrimePerson } from './models/prime-person.model';
export { ApiStatusCodes, ScreenAreaID, ServerPayload } from './models/api-base.model';
export { CachePayLoad } from './models/cache-api.model';
export { Document } from './models/documents.interface';
export { BcscSession } from './models/bcsc-session';
export { PrimeAppBase } from './models/app-base.class';
// Services
export { BASE_URL, CacheApiService } from './services/cache-api.service';
export { CacheService } from './services/cache.service';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL3ByaW1lLWNvcmUvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFHQSxnQ0FBYyx5QkFBeUIsQ0FBQzs7QUFHeEMsNkRBQWMsMEJBQTBCLENBQUM7QUFDekMsNEJBQWMsNkJBQTZCLENBQUM7QUFDNUMsNERBQWMseUJBQXlCLENBQUM7QUFDeEMsNkJBQWMsMEJBQTBCLENBQUM7QUFDekMseUJBQWMsOEJBQThCLENBQUM7QUFDN0MsNEJBQWMsdUJBQXVCLENBQUM7QUFDdEMsNkJBQWMseUJBQXlCLENBQUM7O0FBSXhDLDBDQUFjLDhCQUE4QixDQUFDO0FBQzdDLDZCQUFjLDBCQUEwQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBwcmltZS1jb3JlXG4gKi9cbmV4cG9ydCAqIGZyb20gJy4vbGliL3ByaW1lLWNvcmUubW9kdWxlJztcblxuLy8gTW9kZWxzXG5leHBvcnQgKiBmcm9tICcuL21vZGVscy9wcmltZS1jb25zdGFudHMnO1xuZXhwb3J0ICogZnJvbSAnLi9tb2RlbHMvcHJpbWUtcGVyc29uLm1vZGVsJztcbmV4cG9ydCAqIGZyb20gJy4vbW9kZWxzL2FwaS1iYXNlLm1vZGVsJztcbmV4cG9ydCAqIGZyb20gJy4vbW9kZWxzL2NhY2hlLWFwaS5tb2RlbCc7XG5leHBvcnQgKiBmcm9tICcuL21vZGVscy9kb2N1bWVudHMuaW50ZXJmYWNlJztcbmV4cG9ydCAqIGZyb20gJy4vbW9kZWxzL2Jjc2Mtc2Vzc2lvbic7XG5leHBvcnQgKiBmcm9tICcuL21vZGVscy9hcHAtYmFzZS5jbGFzcyc7XG5cblxuLy8gU2VydmljZXNcbmV4cG9ydCAqIGZyb20gJy4vc2VydmljZXMvY2FjaGUtYXBpLnNlcnZpY2UnO1xuZXhwb3J0ICogZnJvbSAnLi9zZXJ2aWNlcy9jYWNoZS5zZXJ2aWNlJztcblxuIl19