/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { AddressComponent as ɵa } from './lib/components/address/address.component';
export { ConfirmationComponent as ɵe } from './lib/components/confirmation/confirmation.component';
export { ContactBlockComponent as ɵg } from './lib/components/contact-block/contact-block.component';
export { NameComponent as ɵb } from './lib/components/name/name.component';
export { PhoneNumberComponent as ɵd } from './lib/components/phone-number/phone-number.component';
export { ProfileBlockComponent as ɵf } from './lib/components/profile-block/profile-block.component';
export { ProfileComponent as ɵc } from './lib/components/profile/profile.component';
export { ReviewListItemComponent as ɵi } from './lib/components/review-list-item/review-list-item.component';
export { SelfDeclarationQuestionBlockComponent as ɵh } from './lib/components/self-declaration-question-block/self-declaration-question-block.component';
