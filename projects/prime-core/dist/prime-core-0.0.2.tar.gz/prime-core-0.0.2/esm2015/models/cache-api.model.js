/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { ServerPayload } from './api-base.model';
/**
 * @record
 */
export function SysParamInterface() { }
if (false) {
    /** @type {?} */
    SysParamInterface.prototype.name;
    /** @type {?} */
    SysParamInterface.prototype.value;
}
/**
 * Get Cache
 * @record
 */
export function CacheInterface() { }
if (false) {
    /** @type {?|undefined} */
    CacheInterface.prototype.country;
    /** @type {?|undefined} */
    CacheInterface.prototype.province;
    /** @type {?|undefined} */
    CacheInterface.prototype.messages;
    /** @type {?|undefined} */
    CacheInterface.prototype.secQues;
    /** @type {?|undefined} */
    CacheInterface.prototype.documentType;
    /** @type {?|undefined} */
    CacheInterface.prototype.sysParam;
}
export class CachePayLoad extends ServerPayload {
    /**
     * @param {?} payload
     */
    constructor(payload) {
        super(payload);
        this.country = payload.country ? payload.country : undefined;
        this.province = payload.province ? payload.province : undefined;
        this.messages = payload.messages ? payload.messages : undefined;
        this.secQues = payload.secQues ? payload.secQues : undefined;
        this.documentType = payload.documentType ? payload.documentType : undefined;
        this.sysParam = payload.sysParam ? payload.sysParam : undefined;
    }
}
if (false) {
    /** @type {?} */
    CachePayLoad.prototype.country;
    /** @type {?} */
    CachePayLoad.prototype.province;
    /** @type {?} */
    CachePayLoad.prototype.messages;
    /** @type {?} */
    CachePayLoad.prototype.secQues;
    /** @type {?} */
    CachePayLoad.prototype.documentType;
    /** @type {?} */
    CachePayLoad.prototype.sysParam;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUtYXBpLm1vZGVsLmpzIiwic291cmNlUm9vdCI6Im5nOi8vcHJpbWUtY29yZS8iLCJzb3VyY2VzIjpbIm1vZGVscy9jYWNoZS1hcGkubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxhQUFhLEVBQXdDLE1BQU0sa0JBQWtCLENBQUM7Ozs7QUFJdkYsdUNBR0M7OztJQUZDLGlDQUFhOztJQUNiLGtDQUFjOzs7Ozs7QUFNaEIsb0NBT0M7OztJQU5DLGlDQUF3Qjs7SUFDeEIsa0NBQTBCOztJQUMxQixrQ0FBZ0M7O0lBQ2hDLGlDQUFtQjs7SUFDbkIsc0NBQThCOztJQUM5QixrQ0FBK0I7O0FBR2pDLE1BQU0sT0FBTyxZQUFhLFNBQVEsYUFBYTs7OztJQVE3QyxZQUFhLE9BQXVCO1FBQ2xDLEtBQUssQ0FBRSxPQUFPLENBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUM3RCxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUNoRSxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUNoRSxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUM3RCxJQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUM1RSxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztJQUNsRSxDQUFDO0NBQ0Y7OztJQWhCQywrQkFBdUI7O0lBQ3ZCLGdDQUF5Qjs7SUFDekIsZ0NBQStCOztJQUMvQiwrQkFBa0I7O0lBQ2xCLG9DQUE2Qjs7SUFDN0IsZ0NBQThCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2VydmVyUGF5bG9hZCwgUGF5bG9hZEludGVyZmFjZSwgU3RhdHVzTXNnSW50ZXJmYWNlIH0gZnJvbSAnLi9hcGktYmFzZS5tb2RlbCc7XG5pbXBvcnQgeyBEb2N1bWVudFR5cGUgfSBmcm9tICcuL2RvY3VtZW50cy5pbnRlcmZhY2UnO1xuaW1wb3J0IHsgQ291bnRyeUxpc3QsIFByb3ZpbmNlTGlzdCB9IGZyb20gJy4uL2xpYi9jb21wb25lbnRzL2FkZHJlc3MvYWRkcmVzcy5jb21wb25lbnQnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFN5c1BhcmFtSW50ZXJmYWNlIHtcbiAgbmFtZTogc3RyaW5nO1xuICB2YWx1ZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIEdldCBDYWNoZVxuICovXG5leHBvcnQgaW50ZXJmYWNlIENhY2hlSW50ZXJmYWNlIGV4dGVuZHMgUGF5bG9hZEludGVyZmFjZSB7XG4gIGNvdW50cnk/OiBDb3VudHJ5TGlzdFtdO1xuICBwcm92aW5jZT86IFByb3ZpbmNlTGlzdFtdO1xuICBtZXNzYWdlcz86IFN0YXR1c01zZ0ludGVyZmFjZVtdO1xuICBzZWNRdWVzPzogc3RyaW5nW107XG4gIGRvY3VtZW50VHlwZT86IERvY3VtZW50VHlwZVtdO1xuICBzeXNQYXJhbT86IFN5c1BhcmFtSW50ZXJmYWNlW107XG59XG5cbmV4cG9ydCBjbGFzcyBDYWNoZVBheUxvYWQgZXh0ZW5kcyBTZXJ2ZXJQYXlsb2FkIHtcbiAgY291bnRyeTogQ291bnRyeUxpc3RbXTtcbiAgcHJvdmluY2U6IFByb3ZpbmNlTGlzdFtdO1xuICBtZXNzYWdlczogU3RhdHVzTXNnSW50ZXJmYWNlW107XG4gIHNlY1F1ZXM6IHN0cmluZ1tdO1xuICBkb2N1bWVudFR5cGU6IERvY3VtZW50VHlwZVtdO1xuICBzeXNQYXJhbTogU3lzUGFyYW1JbnRlcmZhY2VbXTtcblxuICBjb25zdHJ1Y3RvciggcGF5bG9hZDogQ2FjaGVJbnRlcmZhY2UgKSB7XG4gICAgc3VwZXIoIHBheWxvYWQgKTtcbiAgICB0aGlzLmNvdW50cnkgPSBwYXlsb2FkLmNvdW50cnkgPyBwYXlsb2FkLmNvdW50cnkgOiB1bmRlZmluZWQ7XG4gICAgdGhpcy5wcm92aW5jZSA9IHBheWxvYWQucHJvdmluY2UgPyBwYXlsb2FkLnByb3ZpbmNlIDogdW5kZWZpbmVkO1xuICAgIHRoaXMubWVzc2FnZXMgPSBwYXlsb2FkLm1lc3NhZ2VzID8gcGF5bG9hZC5tZXNzYWdlcyA6IHVuZGVmaW5lZDtcbiAgICB0aGlzLnNlY1F1ZXMgPSBwYXlsb2FkLnNlY1F1ZXMgPyBwYXlsb2FkLnNlY1F1ZXMgOiB1bmRlZmluZWQ7XG4gICAgdGhpcy5kb2N1bWVudFR5cGUgPSBwYXlsb2FkLmRvY3VtZW50VHlwZSA/IHBheWxvYWQuZG9jdW1lbnRUeXBlIDogdW5kZWZpbmVkO1xuICAgIHRoaXMuc3lzUGFyYW0gPSBwYXlsb2FkLnN5c1BhcmFtID8gcGF5bG9hZC5zeXNQYXJhbSA6IHVuZGVmaW5lZDtcbiAgfVxufVxuXG4iXX0=