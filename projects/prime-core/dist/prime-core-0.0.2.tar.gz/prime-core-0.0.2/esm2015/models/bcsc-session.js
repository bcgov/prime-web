/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function BCSCSessionInterface() { }
if (false) {
    /** @type {?} */
    BCSCSessionInterface.prototype.authTrxId;
    /** @type {?} */
    BCSCSessionInterface.prototype.authPartyId;
    /** @type {?} */
    BCSCSessionInterface.prototype.authPartyName;
    /** @type {?} */
    BCSCSessionInterface.prototype.userIdType;
    /** @type {?} */
    BCSCSessionInterface.prototype.userType;
}
/**
 * Class to store the BCSC session information
 */
export class BcscSession {
    /**
     * Note: Once object type is know set the parameter to be as such
     * @param {?} obj
     * @return {?}
     */
    setSessionData(obj) {
        this.authTrxId = obj.authTrxId;
        this.authPartyId = obj.authPartyId;
        this.authPartyName = obj.authPartyName;
        this.userIdType = obj.userIdType;
        this.userType = obj.userType;
    }
    /**
     * @return {?}
     */
    isEmpty() {
        return !(this.authPartyId && this.authPartyName &&
            this.userIdType && this.userType && this.authTrxId);
    }
}
if (false) {
    /** @type {?} */
    BcscSession.prototype.authTrxId;
    /** @type {?} */
    BcscSession.prototype.authPartyId;
    /** @type {?} */
    BcscSession.prototype.authPartyName;
    /** @type {?} */
    BcscSession.prototype.userIdType;
    /** @type {?} */
    BcscSession.prototype.userType;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmNzYy1zZXNzaW9uLmpzIiwic291cmNlUm9vdCI6Im5nOi8vcHJpbWUtY29yZS8iLCJzb3VyY2VzIjpbIm1vZGVscy9iY3NjLXNlc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUVBLDBDQU1DOzs7SUFMQyx5Q0FBa0I7O0lBQ2xCLDJDQUFvQjs7SUFDcEIsNkNBQXNCOztJQUN0QiwwQ0FBbUI7O0lBQ25CLHdDQUFpQjs7Ozs7QUFNbkIsTUFBTSxPQUFPLFdBQVc7Ozs7OztJQVl0QixjQUFjLENBQUUsR0FBeUI7UUFFdkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQy9CLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQztJQUMvQixDQUFDOzs7O0lBRUQsT0FBTztRQUNMLE9BQU8sQ0FBQyxDQUFFLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLGFBQWE7WUFDdEMsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUUsQ0FBQztJQUNqRSxDQUFDO0NBQ0Y7OztJQXZCQyxnQ0FBeUI7O0lBQ3pCLGtDQUEyQjs7SUFDM0Isb0NBQTZCOztJQUM3QixpQ0FBMEI7O0lBQzFCLCtCQUF3QiIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5leHBvcnQgaW50ZXJmYWNlIEJDU0NTZXNzaW9uSW50ZXJmYWNlIHtcbiAgYXV0aFRyeElkOiBzdHJpbmc7ICAgICAgLy8gQkNTQyBBdXRoZW50aWNhdGlvbiBUcmFuc2FjdGlvbiBJZGVudGlmaWVyIHJlbGF0ZWQgdG8gbG9naW4gc2Vzc2lvbiBpZGVudGlmaWVyXG4gIGF1dGhQYXJ0eUlkOiBzdHJpbmc7ICAgIC8vIEJDU0MgQXV0aG9yaXRhdGl2ZSBQYXJ0eSBJZGVudGlmaWVyIHJlbGF0ZWQgdG8gbG9naW4gc2Vzc2lvblxuICBhdXRoUGFydHlOYW1lOiBzdHJpbmc7ICAvLyBCQ1NDIEF1dGhvcml0YXRpdmUgUGFydHkgTmFtZSByZWxhdGVkIHRvIGxvZ2luIHNlc3Npb25cbiAgdXNlcklkVHlwZTogc3RyaW5nOyAgICAgLy8gQkNTQyBVc2VyIElkZW50aWZpZXIgVHlwZSByZWxhdGVkIHRvIGxvZ2luIHNlc3Npb25cbiAgdXNlclR5cGU6IHN0cmluZzsgICAgICAgLy8gQkNTQyBVc2VyIElkZW50aWZpZXIgVHlwZSByZWxhdGVkIHRvIGxvZ2luIHNlc3Npb25cbn1cblxuLyoqXG4gKiBDbGFzcyB0byBzdG9yZSB0aGUgQkNTQyBzZXNzaW9uIGluZm9ybWF0aW9uXG4gKi9cbmV4cG9ydCBjbGFzcyBCY3NjU2Vzc2lvbiB7XG5cbiAgcHVibGljIGF1dGhUcnhJZDogc3RyaW5nO1xuICBwdWJsaWMgYXV0aFBhcnR5SWQ6IHN0cmluZztcbiAgcHVibGljIGF1dGhQYXJ0eU5hbWU6IHN0cmluZztcbiAgcHVibGljIHVzZXJJZFR5cGU6IHN0cmluZztcbiAgcHVibGljIHVzZXJUeXBlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE5vdGU6IE9uY2Ugb2JqZWN0IHR5cGUgaXMga25vdyBzZXQgdGhlIHBhcmFtZXRlciB0byBiZSBhcyBzdWNoXG4gICAqIEBwYXJhbSBvYmpcbiAgICovXG4gIHNldFNlc3Npb25EYXRhKCBvYmo6IEJDU0NTZXNzaW9uSW50ZXJmYWNlICkge1xuXG4gICAgdGhpcy5hdXRoVHJ4SWQgPSBvYmouYXV0aFRyeElkO1xuICAgIHRoaXMuYXV0aFBhcnR5SWQgPSBvYmouYXV0aFBhcnR5SWQ7XG4gICAgdGhpcy5hdXRoUGFydHlOYW1lID0gb2JqLmF1dGhQYXJ0eU5hbWU7XG4gICAgdGhpcy51c2VySWRUeXBlID0gb2JqLnVzZXJJZFR5cGU7XG4gICAgdGhpcy51c2VyVHlwZSA9IG9iai51c2VyVHlwZTtcbiAgfVxuXG4gIGlzRW1wdHkoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEoIHRoaXMuYXV0aFBhcnR5SWQgJiYgdGhpcy5hdXRoUGFydHlOYW1lICYmXG4gICAgICAgICAgICAgIHRoaXMudXNlcklkVHlwZSAmJiB0aGlzLnVzZXJUeXBlICYmIHRoaXMuYXV0aFRyeElkICk7XG4gIH1cbn1cbiJdfQ==