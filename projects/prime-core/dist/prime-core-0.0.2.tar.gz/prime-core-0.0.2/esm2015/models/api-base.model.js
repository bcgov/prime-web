/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @enum {string} */
const ApiStatusCodes = {
    SUCCESS: '0',
    ERROR: '1',
    WARNING: '2',
};
export { ApiStatusCodes };
/** @enum {string} */
const ScreenAreaID = {
    CONFIRMATION: 'CONFIRMATION',
    QRCODE: 'QR',
    NEXT_STEPS: 'NEXT STEPS',
    INTERIM: 'INTERIM',
    FINAL: 'FINAL',
};
export { ScreenAreaID };
/**
 *  Structure for confirmation page to display messages in correct
 *  screen area
 * @record
 */
export function StatusMsgInterface() { }
if (false) {
    /** @type {?} */
    StatusMsgInterface.prototype.msgID;
    /** @type {?} */
    StatusMsgInterface.prototype.msgText;
    /** @type {?} */
    StatusMsgInterface.prototype.msgType;
    /** @type {?} */
    StatusMsgInterface.prototype.scrArea;
    /** @type {?} */
    StatusMsgInterface.prototype.appLayer;
}
/**
 * @record
 */
export function PayloadInterface() { }
if (false) {
    /**
     * Default application name
     * @type {?}
     */
    PayloadInterface.prototype.clientName;
    /**
     * Date the JSON message was created. Date format dictated by value in DB System
     * Parameter table for DATE_FORMAT (i.e. YYYYMMDD) parameter
     * @type {?}
     */
    PayloadInterface.prototype.processDate;
    /**
     * Returned status code values: 0 = success, continue, 1 = error,
     * do not continue, 2 = warning.
     * @type {?}
     */
    PayloadInterface.prototype.statusCode;
    /**
     * Contains the list of Enhanced Message related to the process execution
     * @type {?}
     */
    PayloadInterface.prototype.statusMsgs;
}
export class ServerPayload {
    /**
     * @param {?} payload
     */
    constructor(payload) {
        this.clientName = payload.clientName;
        this.processDate = payload.processDate;
        this.statusCode = payload.statusCode;
        this.statusMsgs = payload.statusMsgs;
    }
    /**
     * @return {?}
     */
    get success() {
        return this.statusCode === ApiStatusCodes.SUCCESS;
    }
    /**
     * @return {?}
     */
    get error() {
        return this.statusCode === ApiStatusCodes.ERROR;
    }
    /**
     * @return {?}
     */
    get warning() {
        return this.statusCode === ApiStatusCodes.WARNING;
    }
}
if (false) {
    /** @type {?} */
    ServerPayload.prototype.clientName;
    /** @type {?} */
    ServerPayload.prototype.processDate;
    /** @type {?} */
    ServerPayload.prototype.statusCode;
    /** @type {?} */
    ServerPayload.prototype.statusMsgs;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLWJhc2UubW9kZWwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9wcmltZS1jb3JlLyIsInNvdXJjZXMiOlsibW9kZWxzL2FwaS1iYXNlLm1vZGVsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztJQUNFLFNBQVUsR0FBRztJQUNiLE9BQVEsR0FBRztJQUNYLFNBQVUsR0FBRzs7Ozs7SUFLYixjQUFlLGNBQWM7SUFDN0IsUUFBUyxJQUFJO0lBQ2IsWUFBYSxZQUFZO0lBQ3pCLFNBQVUsU0FBUztJQUNuQixPQUFRLE9BQU87Ozs7Ozs7O0FBT2pCLHdDQU1DOzs7SUFMQyxtQ0FBYzs7SUFDZCxxQ0FBZ0I7O0lBQ2hCLHFDQUFnQjs7SUFDaEIscUNBQXNCOztJQUN0QixzQ0FBaUI7Ozs7O0FBRW5CLHNDQXVCQzs7Ozs7O0lBbEJDLHNDQUFtQjs7Ozs7O0lBTW5CLHVDQUFvQjs7Ozs7O0lBTXBCLHNDQUFtQjs7Ozs7SUFLbkIsc0NBQXFEOztBQUd2RCxNQUFNLE9BQU8sYUFBYTs7OztJQU94QixZQUFZLE9BQXlCO1FBQ25DLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQztRQUNyQyxJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQztJQUN2QyxDQUFDOzs7O0lBRUQsSUFBSSxPQUFPO1FBQ1QsT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLGNBQWMsQ0FBQyxPQUFPLENBQUM7SUFDcEQsQ0FBQzs7OztJQUVELElBQUksS0FBSztRQUNQLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxjQUFjLENBQUMsS0FBSyxDQUFDO0lBQ2xELENBQUM7Ozs7SUFFRCxJQUFJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssY0FBYyxDQUFDLE9BQU8sQ0FBQztJQUNwRCxDQUFDO0NBQ0Y7OztJQXhCQyxtQ0FBbUI7O0lBQ25CLG9DQUFvQjs7SUFDcEIsbUNBQW1COztJQUNuQixtQ0FBcUQiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBBcGlTdGF0dXNDb2RlcyB7XG4gIFNVQ0NFU1MgPSAnMCcsXG4gIEVSUk9SID0gJzEnLFxuICBXQVJOSU5HID0gJzInXG59XG5cbi8qKiBTY3JlZW4gc2VjdGlvbiBpZGVudGlmaWVycyAqL1xuZXhwb3J0IGVudW0gU2NyZWVuQXJlYUlEIHtcbiAgQ09ORklSTUFUSU9OID0gJ0NPTkZJUk1BVElPTicsXG4gIFFSQ09ERSA9ICdRUicsXG4gIE5FWFRfU1RFUFMgPSAnTkVYVCBTVEVQUycsXG4gIElOVEVSSU0gPSAnSU5URVJJTScsXG4gIEZJTkFMID0gJ0ZJTkFMJ1xufVxuXG4vKipcbiAqICBTdHJ1Y3R1cmUgZm9yIGNvbmZpcm1hdGlvbiBwYWdlIHRvIGRpc3BsYXkgbWVzc2FnZXMgaW4gY29ycmVjdFxuICogIHNjcmVlbiBhcmVhXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3RhdHVzTXNnSW50ZXJmYWNlIHtcbiAgbXNnSUQ6IHN0cmluZztcbiAgbXNnVGV4dDogc3RyaW5nO1xuICBtc2dUeXBlOiBzdHJpbmc7XG4gIHNjckFyZWE6IFNjcmVlbkFyZWFJRDtcbiAgYXBwTGF5ZXI6IHN0cmluZztcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUGF5bG9hZEludGVyZmFjZSB7XG5cbiAgLyoqXG4gICAqIERlZmF1bHQgYXBwbGljYXRpb24gbmFtZVxuICAgKi9cbiAgY2xpZW50TmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBEYXRlIHRoZSBKU09OIG1lc3NhZ2Ugd2FzIGNyZWF0ZWQuIERhdGUgZm9ybWF0IGRpY3RhdGVkIGJ5IHZhbHVlIGluIERCIFN5c3RlbVxuICAgKiBQYXJhbWV0ZXIgdGFibGUgZm9yIERBVEVfRk9STUFUIChpLmUuIFlZWVlNTUREKSBwYXJhbWV0ZXJcbiAgICovXG4gIHByb2Nlc3NEYXRlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFJldHVybmVkIHN0YXR1cyBjb2RlIHZhbHVlczogMCA9IHN1Y2Nlc3MsIGNvbnRpbnVlLCAxID0gZXJyb3IsXG4gICAqIGRvIG5vdCBjb250aW51ZSwgMiA9IHdhcm5pbmcuXG4gICAqL1xuICBzdGF0dXNDb2RlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIENvbnRhaW5zIHRoZSBsaXN0IG9mIEVuaGFuY2VkIE1lc3NhZ2UgcmVsYXRlZCB0byB0aGUgcHJvY2VzcyBleGVjdXRpb25cbiAgICovXG4gIHN0YXR1c01zZ3M6IFN0YXR1c01zZ0ludGVyZmFjZVtdIHwgc3RyaW5nIHwgc3RyaW5nW107XG59XG5cbmV4cG9ydCBjbGFzcyBTZXJ2ZXJQYXlsb2FkIGltcGxlbWVudHMgUGF5bG9hZEludGVyZmFjZSB7XG4gIGNsaWVudE5hbWU6IHN0cmluZztcbiAgcHJvY2Vzc0RhdGU6IHN0cmluZztcbiAgc3RhdHVzQ29kZTogc3RyaW5nO1xuICBzdGF0dXNNc2dzOiBTdGF0dXNNc2dJbnRlcmZhY2VbXSB8IHN0cmluZyB8IHN0cmluZ1tdO1xuXG5cbiAgY29uc3RydWN0b3IocGF5bG9hZDogUGF5bG9hZEludGVyZmFjZSkge1xuICAgIHRoaXMuY2xpZW50TmFtZSA9IHBheWxvYWQuY2xpZW50TmFtZTtcbiAgICB0aGlzLnByb2Nlc3NEYXRlID0gcGF5bG9hZC5wcm9jZXNzRGF0ZTtcbiAgICB0aGlzLnN0YXR1c0NvZGUgPSBwYXlsb2FkLnN0YXR1c0NvZGU7XG4gICAgdGhpcy5zdGF0dXNNc2dzID0gcGF5bG9hZC5zdGF0dXNNc2dzO1xuICB9XG5cbiAgZ2V0IHN1Y2Nlc3MoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdHVzQ29kZSA9PT0gQXBpU3RhdHVzQ29kZXMuU1VDQ0VTUztcbiAgfVxuXG4gIGdldCBlcnJvcigpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0dXNDb2RlID09PSBBcGlTdGF0dXNDb2Rlcy5FUlJPUjtcbiAgfVxuXG4gIGdldCB3YXJuaW5nKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnN0YXR1c0NvZGUgPT09IEFwaVN0YXR1c0NvZGVzLldBUk5JTkc7XG4gIH1cbn1cblxuXG4iXX0=