/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Common to all PRIME applications
 */
export class PrimeConstants {
}
// Email length from database
PrimeConstants.EMAIL_MAXLEN = '256';
// Address Constants
PrimeConstants.CANADA = 'CAN';
PrimeConstants.BRITISH_COLUMBIA = 'BC';
if (false) {
    /** @type {?} */
    PrimeConstants.EMAIL_MAXLEN;
    /** @type {?} */
    PrimeConstants.CANADA;
    /** @type {?} */
    PrimeConstants.BRITISH_COLUMBIA;
}
/** @enum {string} */
const ProviderCode = {
    MOH: 'MOH',
    BCSC: 'BCSC',
};
export { ProviderCode };
/** @enum {string} */
const AssuranceLevel = {
    LEVEL_1: '1',
    LEVEL_2: '2',
    LEVEL_3: '3',
};
export { AssuranceLevel };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpbWUtY29uc3RhbnRzLmpzIiwic291cmNlUm9vdCI6Im5nOi8vcHJpbWUtY29yZS8iLCJzb3VyY2VzIjpbIm1vZGVscy9wcmltZS1jb25zdGFudHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUVBLE1BQU0sT0FBTyxjQUFjOzs7QUFHWCwyQkFBWSxHQUFHLEtBQUssQ0FBQzs7QUFHckIscUJBQU0sR0FBRyxLQUFLLENBQUM7QUFDZiwrQkFBZ0IsR0FBRyxJQUFJLENBQUM7OztJQUp0Qyw0QkFBbUM7O0lBR25DLHNCQUE2Qjs7SUFDN0IsZ0NBQXNDOzs7O0lBT3RDLEtBQU0sS0FBSztJQUNYLE1BQU8sTUFBTTs7Ozs7SUFPYixTQUFVLEdBQUc7SUFDYixTQUFVLEdBQUc7SUFDYixTQUFVLEdBQUciLCJzb3VyY2VzQ29udGVudCI6WyJcbi8qKiBDb21tb24gdG8gYWxsIFBSSU1FIGFwcGxpY2F0aW9ucyAqL1xuZXhwb3J0IGNsYXNzIFByaW1lQ29uc3RhbnRzIHtcblxuICAvLyBFbWFpbCBsZW5ndGggZnJvbSBkYXRhYmFzZVxuICBwdWJsaWMgc3RhdGljIEVNQUlMX01BWExFTiA9ICcyNTYnO1xuXG4gIC8vIEFkZHJlc3MgQ29uc3RhbnRzXG4gIHB1YmxpYyBzdGF0aWMgQ0FOQURBID0gJ0NBTic7XG4gIHB1YmxpYyBzdGF0aWMgQlJJVElTSF9DT0xVTUJJQSA9ICdCQyc7XG59XG5cbi8qKlxuICogSWRlbnRpdHkgcHJvdmlkZXJcbiAqL1xuZXhwb3J0IGVudW0gUHJvdmlkZXJDb2RlIHtcbiAgTU9IID0gJ01PSCcsXG4gIEJDU0MgPSAnQkNTQydcbn1cblxuLyoqXG4gKiBTZWN1cml0eSBhc3N1cmFuY2UgbGV2ZWwgZm9yIHRoZSBwZXJzb24uXG4gKi9cbmV4cG9ydCBlbnVtIEFzc3VyYW5jZUxldmVsIHtcbiAgTEVWRUxfMSA9ICcxJyxcbiAgTEVWRUxfMiA9ICcyJyxcbiAgTEVWRUxfMyA9ICczJ1xufVxuIl19