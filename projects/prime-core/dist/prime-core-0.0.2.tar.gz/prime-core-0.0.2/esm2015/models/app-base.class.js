/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Inject } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { filter, map, mergeMap } from 'rxjs/operators';
import { Base } from 'moh-common-lib/models';
import { CommonLogger } from 'moh-common-lib/services';
/**
 * PrimeAppBase is a class containing shared functionality for the
 * various "AppComponent"s for each individual prime application. The important
 * functionality is in the constructor and ngOnInit().  Unfortunately this does
 * not come bundled with a template and instead templates must be updated for
 * each project manually.
 *
 * **Note** - you MUST call super.ngOnInit() you have an ngOnInit() method in
 * your subclass. Otherwise, the title and accessability functions concerns
 * won't update.
 */
export class PrimeAppBase extends Base {
    /**
     * @param {?} pRouter
     * @param {?} pActivatedRoute
     * @param {?} pTitleService
     * @param {?} logger
     * @param {?} version
     */
    constructor(pRouter, pActivatedRoute, pTitleService, logger, version) {
        super();
        this.pRouter = pRouter;
        this.pActivatedRoute = pActivatedRoute;
        this.pTitleService = pTitleService;
        this.logger = logger;
        this.title = 'Prime';
        this.SKIP_CONTENT_HASH = '#content';
        version.success
            ? console.log('%c' + version.message, 'color: #036; font-size: 20px;')
            : console.error(version.message);
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.updateTitleOnRouteChange();
        this.pRouter.events.pipe(filter((/**
         * @param {?} ev
         * @return {?}
         */
        ev => ev instanceof NavigationEnd))).subscribe(this.updateSkipContentLink.bind(this));
        this.updateSkipContentLink();
    }
    /**
     * Listen to every route change, and update the page title based on the
     * 'title' property in the route's data.
     * @protected
     * @return {?}
     */
    updateTitleOnRouteChange() {
        this.pRouter.events
            .pipe(filter((/**
         * @param {?} event
         * @return {?}
         */
        event => event instanceof NavigationEnd)), map((/**
         * @return {?}
         */
        () => this.pActivatedRoute)), map((/**
         * @param {?} route
         * @return {?}
         */
        route => {
            while (route.firstChild) {
                route = route.firstChild;
            }
            return route;
        })), filter((/**
         * @param {?} route
         * @return {?}
         */
        route => route.outlet === 'primary')), mergeMap((/**
         * @param {?} route
         * @return {?}
         */
        route => route.data)))
            .subscribe((/**
         * @param {?} data
         * @return {?}
         */
        (data) => {
            this.setTitle(data.title);
            this.logger.log({
                event: 'navigation',
                title: data.title ? data.title : this.title,
                url: this.pRouter.url
            });
        }));
    }
    /**
     * Set the page title. Includes basic formatting and fallback
     * @protected
     * @param {?=} title
     * @return {?}
     */
    setTitle(title) {
        if (title) {
            this.pTitleService.setTitle(`Prime | ${title}`);
        }
        else {
            // Default title
            this.pTitleService.setTitle(this.title);
        }
    }
    /**
     * @param {?} url
     * @return {?}
     */
    routeIsActive(url) {
        return this.pRouter.url.includes(url);
    }
    /**
     * Updates the skipToContent link which is an a11y concern.  Importantly the
     * skipToContent link must include the relevant routes / subpages that the
     * user is currently on.
     * @return {?}
     */
    updateSkipContentLink() {
        this.skipLinkPath = this.generateSkipToContentLink();
    }
    // Slightly complicated because we have to include the deployUrl in manually.
    // If deployUrl changes this code must too.
    /**
     * @protected
     * @return {?}
     */
    generateSkipToContentLink() {
        // don't add duplicate #contents
        if (window.location.href.indexOf(this.SKIP_CONTENT_HASH) !== -1) {
            return window.location.href;
        }
        return `${window.location.origin}${this.pRouter.url}#content`;
    }
}
/** @nocollapse */
PrimeAppBase.ctorParameters = () => [
    { type: Router },
    { type: ActivatedRoute },
    { type: Title },
    { type: CommonLogger },
    { type: undefined, decorators: [{ type: Inject, args: ['APP_VERSION',] }] }
];
if (false) {
    /** @type {?} */
    PrimeAppBase.prototype.title;
    /** @type {?} */
    PrimeAppBase.prototype.skipLinkPath;
    /**
     * @type {?}
     * @private
     */
    PrimeAppBase.prototype.SKIP_CONTENT_HASH;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.pRouter;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.pActivatedRoute;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.pTitleService;
    /**
     * @type {?}
     * @protected
     */
    PrimeAppBase.prototype.logger;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLWJhc2UuY2xhc3MuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9wcmltZS1jb3JlLyIsInNvdXJjZXMiOlsibW9kZWxzL2FwcC1iYXNlLmNsYXNzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxPQUFPLEVBQVUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQy9DLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUNsRCxPQUFPLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN4RSxPQUFPLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxRQUFRLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDN0MsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHlCQUF5QixDQUFDOzs7Ozs7Ozs7Ozs7QUFhdkQsTUFBTSxPQUFPLFlBQWEsU0FBUSxJQUFJOzs7Ozs7OztJQUtwQyxZQUF1QixPQUFlLEVBQ2YsZUFBK0IsRUFDL0IsYUFBb0IsRUFDcEIsTUFBb0IsRUFDUCxPQUFPO1FBQ3pDLEtBQUssRUFBRSxDQUFDO1FBTGEsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtRQUMvQixrQkFBYSxHQUFiLGFBQWEsQ0FBTztRQUNwQixXQUFNLEdBQU4sTUFBTSxDQUFjO1FBUDNDLFVBQUssR0FBRyxPQUFPLENBQUM7UUFFUixzQkFBaUIsR0FBRyxVQUFVLENBQUM7UUFRckMsT0FBTyxDQUFDLE9BQU87WUFDYixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSwrQkFBK0IsQ0FBQztZQUN0RSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDckMsQ0FBQzs7OztJQUVELFFBQVE7UUFDTixJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQ3RCLE1BQU07Ozs7UUFBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsWUFBWSxhQUFhLEVBQUMsQ0FDMUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRW5ELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQy9CLENBQUM7Ozs7Ozs7SUFNUyx3QkFBd0I7UUFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNO2FBQ2hCLElBQUksQ0FDSCxNQUFNOzs7O1FBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLFlBQVksYUFBYSxFQUFDLEVBQy9DLEdBQUc7OztRQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUMsRUFDL0IsR0FBRzs7OztRQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ1YsT0FBTyxLQUFLLENBQUMsVUFBVSxFQUFFO2dCQUN2QixLQUFLLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQzthQUMxQjtZQUNELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQyxFQUFDLEVBQ0YsTUFBTTs7OztRQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUMsRUFDM0MsUUFBUTs7OztRQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksRUFBQyxDQUM5QjthQUNBLFNBQVM7Ozs7UUFBQyxDQUFDLElBQXdCLEVBQUUsRUFBRTtZQUN0QyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMxQixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxLQUFLLEVBQUUsWUFBWTtnQkFDbkIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLO2dCQUMzQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHO2FBQ3RCLENBQUMsQ0FBQztRQUNMLENBQUMsRUFBQyxDQUFDO0lBQ1AsQ0FBQzs7Ozs7OztJQUdTLFFBQVEsQ0FBQyxLQUFjO1FBQy9CLElBQUksS0FBSyxFQUFFO1lBQ1QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsV0FBVyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1NBQ2pEO2FBQU07WUFDTCxnQkFBZ0I7WUFDaEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3pDO0lBQ0gsQ0FBQzs7Ozs7SUFFRCxhQUFhLENBQUMsR0FBVztRQUN2QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN4QyxDQUFDOzs7Ozs7O0lBT0QscUJBQXFCO1FBQ25CLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUM7SUFDdkQsQ0FBQzs7Ozs7OztJQUtTLHlCQUF5QjtRQUNqQyxnQ0FBZ0M7UUFDaEMsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDL0QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztTQUM3QjtRQUNELE9BQU8sR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsVUFBVSxDQUFDO0lBQ2hFLENBQUM7Ozs7WUFyR00sTUFBTTtZQUFpQixjQUFjO1lBRHJDLEtBQUs7WUFJTCxZQUFZOzRDQXNCTCxNQUFNLFNBQUMsYUFBYTs7OztJQVJsQyw2QkFBZ0I7O0lBQ2hCLG9DQUFvQjs7Ozs7SUFDcEIseUNBQXVDOzs7OztJQUUxQiwrQkFBeUI7Ozs7O0lBQ3pCLHVDQUF5Qzs7Ozs7SUFDekMscUNBQThCOzs7OztJQUM5Qiw4QkFBOEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBPbkluaXQsIEluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVGl0bGUgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkVuZCwgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgZmlsdGVyLCBtYXAsIG1lcmdlTWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgQmFzZSB9IGZyb20gJ21vaC1jb21tb24tbGliL21vZGVscyc7XG5pbXBvcnQgeyBDb21tb25Mb2dnZXIgfSBmcm9tICdtb2gtY29tbW9uLWxpYi9zZXJ2aWNlcyc7XG5cbi8qKlxuICogUHJpbWVBcHBCYXNlIGlzIGEgY2xhc3MgY29udGFpbmluZyBzaGFyZWQgZnVuY3Rpb25hbGl0eSBmb3IgdGhlXG4gKiB2YXJpb3VzIFwiQXBwQ29tcG9uZW50XCJzIGZvciBlYWNoIGluZGl2aWR1YWwgcHJpbWUgYXBwbGljYXRpb24uIFRoZSBpbXBvcnRhbnRcbiAqIGZ1bmN0aW9uYWxpdHkgaXMgaW4gdGhlIGNvbnN0cnVjdG9yIGFuZCBuZ09uSW5pdCgpLiAgVW5mb3J0dW5hdGVseSB0aGlzIGRvZXNcbiAqIG5vdCBjb21lIGJ1bmRsZWQgd2l0aCBhIHRlbXBsYXRlIGFuZCBpbnN0ZWFkIHRlbXBsYXRlcyBtdXN0IGJlIHVwZGF0ZWQgZm9yXG4gKiBlYWNoIHByb2plY3QgbWFudWFsbHkuXG4gKlxuICogKipOb3RlKiogLSB5b3UgTVVTVCBjYWxsIHN1cGVyLm5nT25Jbml0KCkgeW91IGhhdmUgYW4gbmdPbkluaXQoKSBtZXRob2QgaW5cbiAqIHlvdXIgc3ViY2xhc3MuIE90aGVyd2lzZSwgdGhlIHRpdGxlIGFuZCBhY2Nlc3NhYmlsaXR5IGZ1bmN0aW9ucyBjb25jZXJuc1xuICogd29uJ3QgdXBkYXRlLlxuICovXG5leHBvcnQgY2xhc3MgUHJpbWVBcHBCYXNlIGV4dGVuZHMgQmFzZSBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gIHRpdGxlID0gJ1ByaW1lJztcbiAgcHVibGljIHNraXBMaW5rUGF0aDtcbiAgcHJpdmF0ZSBTS0lQX0NPTlRFTlRfSEFTSCA9ICcjY29udGVudCc7XG5cbiAgY29uc3RydWN0b3IoIHByb3RlY3RlZCBwUm91dGVyOiBSb3V0ZXIsXG4gICAgICAgICAgICAgICBwcm90ZWN0ZWQgcEFjdGl2YXRlZFJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICAgICAgICAgICAgIHByb3RlY3RlZCBwVGl0bGVTZXJ2aWNlOiBUaXRsZSxcbiAgICAgICAgICAgICAgIHByb3RlY3RlZCBsb2dnZXI6IENvbW1vbkxvZ2dlcixcbiAgICAgICAgICAgICAgIEBJbmplY3QoJ0FQUF9WRVJTSU9OJykgdmVyc2lvbiApIHtcbiAgICBzdXBlcigpO1xuICAgIHZlcnNpb24uc3VjY2Vzc1xuICAgICAgPyBjb25zb2xlLmxvZygnJWMnICsgdmVyc2lvbi5tZXNzYWdlLCAnY29sb3I6ICMwMzY7IGZvbnQtc2l6ZTogMjBweDsnKVxuICAgICAgOiBjb25zb2xlLmVycm9yKHZlcnNpb24ubWVzc2FnZSk7XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLnVwZGF0ZVRpdGxlT25Sb3V0ZUNoYW5nZSgpO1xuICAgIHRoaXMucFJvdXRlci5ldmVudHMucGlwZShcbiAgICAgIGZpbHRlcihldiA9PiBldiBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpLFxuICAgICkuc3Vic2NyaWJlKHRoaXMudXBkYXRlU2tpcENvbnRlbnRMaW5rLmJpbmQodGhpcykpO1xuXG4gICAgdGhpcy51cGRhdGVTa2lwQ29udGVudExpbmsoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBMaXN0ZW4gdG8gZXZlcnkgcm91dGUgY2hhbmdlLCBhbmQgdXBkYXRlIHRoZSBwYWdlIHRpdGxlIGJhc2VkIG9uIHRoZVxuICAgKiAndGl0bGUnIHByb3BlcnR5IGluIHRoZSByb3V0ZSdzIGRhdGEuXG4gICAqL1xuICBwcm90ZWN0ZWQgdXBkYXRlVGl0bGVPblJvdXRlQ2hhbmdlKCkge1xuICAgIHRoaXMucFJvdXRlci5ldmVudHNcbiAgICAgIC5waXBlKFxuICAgICAgICBmaWx0ZXIoZXZlbnQgPT4gZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSxcbiAgICAgICAgbWFwKCgpID0+IHRoaXMucEFjdGl2YXRlZFJvdXRlKSxcbiAgICAgICAgbWFwKHJvdXRlID0+IHtcbiAgICAgICAgICB3aGlsZSAocm91dGUuZmlyc3RDaGlsZCkge1xuICAgICAgICAgICAgcm91dGUgPSByb3V0ZS5maXJzdENoaWxkO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcm91dGU7XG4gICAgICAgIH0pLFxuICAgICAgICBmaWx0ZXIocm91dGUgPT4gcm91dGUub3V0bGV0ID09PSAncHJpbWFyeScpLFxuICAgICAgICBtZXJnZU1hcChyb3V0ZSA9PiByb3V0ZS5kYXRhKVxuICAgICAgKVxuICAgICAgLnN1YnNjcmliZSgoZGF0YTogeyB0aXRsZT86IHN0cmluZyB9KSA9PiB7XG4gICAgICAgIHRoaXMuc2V0VGl0bGUoZGF0YS50aXRsZSk7XG4gICAgICAgIHRoaXMubG9nZ2VyLmxvZyh7XG4gICAgICAgICAgZXZlbnQ6ICduYXZpZ2F0aW9uJyxcbiAgICAgICAgICB0aXRsZTogZGF0YS50aXRsZSA/IGRhdGEudGl0bGUgOiB0aGlzLnRpdGxlLFxuICAgICAgICAgIHVybDogdGhpcy5wUm91dGVyLnVybFxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICB9XG5cbiAgLyoqIFNldCB0aGUgcGFnZSB0aXRsZS4gSW5jbHVkZXMgYmFzaWMgZm9ybWF0dGluZyBhbmQgZmFsbGJhY2sgKi9cbiAgcHJvdGVjdGVkIHNldFRpdGxlKHRpdGxlPzogc3RyaW5nKSB7XG4gICAgaWYgKHRpdGxlKSB7XG4gICAgICB0aGlzLnBUaXRsZVNlcnZpY2Uuc2V0VGl0bGUoYFByaW1lIHwgJHt0aXRsZX1gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gRGVmYXVsdCB0aXRsZVxuICAgICAgdGhpcy5wVGl0bGVTZXJ2aWNlLnNldFRpdGxlKHRoaXMudGl0bGUpO1xuICAgIH1cbiAgfVxuXG4gIHJvdXRlSXNBY3RpdmUodXJsOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5wUm91dGVyLnVybC5pbmNsdWRlcyh1cmwpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIHNraXBUb0NvbnRlbnQgbGluayB3aGljaCBpcyBhbiBhMTF5IGNvbmNlcm4uICBJbXBvcnRhbnRseSB0aGVcbiAgICogc2tpcFRvQ29udGVudCBsaW5rIG11c3QgaW5jbHVkZSB0aGUgcmVsZXZhbnQgcm91dGVzIC8gc3VicGFnZXMgdGhhdCB0aGVcbiAgICogdXNlciBpcyBjdXJyZW50bHkgb24uXG4gICAqL1xuICB1cGRhdGVTa2lwQ29udGVudExpbmsoKSB7XG4gICAgdGhpcy5za2lwTGlua1BhdGggPSB0aGlzLmdlbmVyYXRlU2tpcFRvQ29udGVudExpbmsoKTtcbiAgfVxuXG4gIC8vIFNsaWdodGx5IGNvbXBsaWNhdGVkIGJlY2F1c2Ugd2UgaGF2ZSB0byBpbmNsdWRlIHRoZSBkZXBsb3lVcmwgaW4gbWFudWFsbHkuXG4gIC8vIElmIGRlcGxveVVybCBjaGFuZ2VzIHRoaXMgY29kZSBtdXN0IHRvby5cblxuICBwcm90ZWN0ZWQgZ2VuZXJhdGVTa2lwVG9Db250ZW50TGluaygpOiBzdHJpbmcge1xuICAgIC8vIGRvbid0IGFkZCBkdXBsaWNhdGUgI2NvbnRlbnRzXG4gICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluZGV4T2YodGhpcy5TS0lQX0NPTlRFTlRfSEFTSCkgIT09IC0xKSB7XG4gICAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uLmhyZWY7XG4gICAgfVxuICAgIHJldHVybiBgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufSR7dGhpcy5wUm91dGVyLnVybH0jY29udGVudGA7XG4gIH1cbn1cbiJdfQ==