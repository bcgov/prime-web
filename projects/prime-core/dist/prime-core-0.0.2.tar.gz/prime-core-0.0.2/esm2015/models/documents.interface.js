/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function DocumentType() { }
if (false) {
    /** @type {?} */
    DocumentType.prototype.docType;
    /** @type {?} */
    DocumentType.prototype.description;
}
export class Document {
    /**
     * @param {?} input
     */
    constructor(input) {
        this.type = input.type;
        this.registrantUUID = input.registrantUUID;
        this.expiry = input.expiry;
        this.images = [];
    }
    /**
     * @return {?}
     */
    isValid() {
        return this.expiry && this.images.length >= 1;
    }
}
if (false) {
    /** @type {?} */
    Document.prototype.type;
    /** @type {?} */
    Document.prototype.registrantUUID;
    /** @type {?} */
    Document.prototype.expiry;
    /** @type {?} */
    Document.prototype.images;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZG9jdW1lbnRzLmludGVyZmFjZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL3ByaW1lLWNvcmUvIiwic291cmNlcyI6WyJtb2RlbHMvZG9jdW1lbnRzLmludGVyZmFjZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBR0Esa0NBR0M7OztJQUZHLCtCQUFnQjs7SUFDaEIsbUNBQW9COztBQUl4QixNQUFNLE9BQU8sUUFBUTs7OztJQU1qQixZQUFZLEtBQUs7UUFDYixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1FBQzNDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUMzQixJQUFJLENBQUMsTUFBTSxHQUFJLEVBQUUsQ0FBQztJQUN0QixDQUFDOzs7O0lBRUQsT0FBTztRQUNILE9BQU8sSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7SUFDbEQsQ0FBQztDQUNKOzs7SUFmRyx3QkFBbUI7O0lBQ25CLGtDQUF1Qjs7SUFDdkIsMEJBQW9COztJQUNwQiwwQkFBc0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTaW1wbGVEYXRlIH0gZnJvbSAnbW9oLWNvbW1vbi1saWInO1xuaW1wb3J0IHsgQ29tbW9uSW1hZ2UgfSBmcm9tICdtb2gtY29tbW9uLWxpYi9pbWFnZXMvaW1hZ2VzJztcblxuZXhwb3J0IGludGVyZmFjZSBEb2N1bWVudFR5cGUge1xuICAgIGRvY1R5cGU6IHN0cmluZztcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nO1xufVxuXG5cbmV4cG9ydCBjbGFzcyBEb2N1bWVudCB7XG4gICAgdHlwZTogRG9jdW1lbnRUeXBlO1xuICAgIHJlZ2lzdHJhbnRVVUlEOiBzdHJpbmc7XG4gICAgZXhwaXJ5PzogU2ltcGxlRGF0ZTtcbiAgICBpbWFnZXM6IENvbW1vbkltYWdlW107XG5cbiAgICBjb25zdHJ1Y3RvcihpbnB1dCkge1xuICAgICAgICB0aGlzLnR5cGUgPSBpbnB1dC50eXBlO1xuICAgICAgICB0aGlzLnJlZ2lzdHJhbnRVVUlEID0gaW5wdXQucmVnaXN0cmFudFVVSUQ7XG4gICAgICAgIHRoaXMuZXhwaXJ5ID0gaW5wdXQuZXhwaXJ5O1xuICAgICAgICB0aGlzLmltYWdlcyAgPSBbXTtcbiAgICB9XG5cbiAgICBpc1ZhbGlkKCk6IGJvb2xlYW4ge1xuICAgICAgICByZXR1cm4gdGhpcy5leHBpcnkgJiYgdGhpcy5pbWFnZXMubGVuZ3RoID49IDE7XG4gICAgfVxufVxuXG4iXX0=