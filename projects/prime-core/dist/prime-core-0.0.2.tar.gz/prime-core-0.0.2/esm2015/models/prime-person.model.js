/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Person, Address } from 'moh-common-lib/models';
export class PrimePerson extends Person {
    constructor() {
        super(...arguments);
        /**
         * Identify and mailing addresses
         */
        this.address = new Address();
        this.mailAddress = new Address();
        this.identityIsMailingAddress = true;
    }
    /* Copy function */
    /**
     * @param {?} object
     * @return {?}
     */
    copy(object) {
        super.copy(object);
        this.preferredFirstName = object.preferredFirstName;
        this.preferredMiddleName = object.preferredMiddleName;
        this.preferredLastName = object.preferredLastName;
        this.address.copy(object.address);
        this.mailAddress.copy(object.mailAddress);
    }
}
if (false) {
    /**
     * Parts of a person's name
     * @type {?}
     */
    PrimePerson.prototype.preferredFirstName;
    /** @type {?} */
    PrimePerson.prototype.preferredMiddleName;
    /** @type {?} */
    PrimePerson.prototype.preferredLastName;
    /**
     * Identify and mailing addresses
     * @type {?}
     */
    PrimePerson.prototype.address;
    /** @type {?} */
    PrimePerson.prototype.mailAddress;
    /** @type {?} */
    PrimePerson.prototype.identityIsMailingAddress;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpbWUtcGVyc29uLm1vZGVsLmpzIiwic291cmNlUm9vdCI6Im5nOi8vcHJpbWUtY29yZS8iLCJzb3VyY2VzIjpbIm1vZGVscy9wcmltZS1wZXJzb24ubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFFeEQsTUFBTSxPQUFPLFdBQVksU0FBUSxNQUFNO0lBQXZDOzs7OztRQU9TLFlBQU8sR0FBWSxJQUFJLE9BQU8sRUFBRSxDQUFDO1FBQ2pDLGdCQUFXLEdBQVksSUFBSSxPQUFPLEVBQUUsQ0FBQztRQUNyQyw2QkFBd0IsR0FBRyxJQUFJLENBQUM7SUFhekMsQ0FBQzs7Ozs7O0lBVEMsSUFBSSxDQUFDLE1BQW1CO1FBQ3RCLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQztRQUNwRCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDLG1CQUFtQixDQUFDO1FBQ3RELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFFbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM1QyxDQUFDO0NBQ0Y7Ozs7OztJQXBCQyx5Q0FBa0M7O0lBQ2xDLDBDQUFtQzs7SUFDbkMsd0NBQWlDOzs7OztJQUdqQyw4QkFBd0M7O0lBQ3hDLGtDQUE0Qzs7SUFDNUMsK0NBQXVDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGVyc29uLCBBZGRyZXNzIH0gZnJvbSAnbW9oLWNvbW1vbi1saWIvbW9kZWxzJztcblxuZXhwb3J0IGNsYXNzIFByaW1lUGVyc29uIGV4dGVuZHMgUGVyc29uIHtcbiAgLyoqIFBhcnRzIG9mIGEgcGVyc29uJ3MgbmFtZSAqL1xuICBwdWJsaWMgcHJlZmVycmVkRmlyc3ROYW1lOiBzdHJpbmc7XG4gIHB1YmxpYyBwcmVmZXJyZWRNaWRkbGVOYW1lOiBzdHJpbmc7XG4gIHB1YmxpYyBwcmVmZXJyZWRMYXN0TmFtZTogc3RyaW5nO1xuXG4gIC8qKiBJZGVudGlmeSBhbmQgbWFpbGluZyBhZGRyZXNzZXMgKi9cbiAgcHVibGljIGFkZHJlc3M6IEFkZHJlc3MgPSBuZXcgQWRkcmVzcygpO1xuICBwdWJsaWMgbWFpbEFkZHJlc3M6IEFkZHJlc3MgPSBuZXcgQWRkcmVzcygpO1xuICBwdWJsaWMgaWRlbnRpdHlJc01haWxpbmdBZGRyZXNzID0gdHJ1ZTtcblxuXG4gIC8qIENvcHkgZnVuY3Rpb24gKi9cbiAgY29weShvYmplY3Q6IFByaW1lUGVyc29uKSB7XG4gICAgc3VwZXIuY29weShvYmplY3QpO1xuICAgIHRoaXMucHJlZmVycmVkRmlyc3ROYW1lID0gb2JqZWN0LnByZWZlcnJlZEZpcnN0TmFtZTtcbiAgICB0aGlzLnByZWZlcnJlZE1pZGRsZU5hbWUgPSBvYmplY3QucHJlZmVycmVkTWlkZGxlTmFtZTtcbiAgICB0aGlzLnByZWZlcnJlZExhc3ROYW1lID0gb2JqZWN0LnByZWZlcnJlZExhc3ROYW1lO1xuXG4gICAgdGhpcy5hZGRyZXNzLmNvcHkob2JqZWN0LmFkZHJlc3MpO1xuICAgIHRoaXMubWFpbEFkZHJlc3MuY29weShvYmplY3QubWFpbEFkZHJlc3MpO1xuICB9XG59XG4iXX0=