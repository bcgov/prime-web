/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable, Injector, InjectionToken } from '@angular/core';
import { HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';
import { throwError } from 'rxjs';
import { AbstractHttpService } from 'moh-common-lib/services';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
/**
 * BASE_URL: URL for REST requests
 * @type {?}
 */
export const BASE_URL = new InjectionToken('BaseUrl');
/**
 * BASE_URL: URL for REST requests
 */
export class CacheApiService extends AbstractHttpService {
    /**
     * @param {?} http
     * @param {?} injector
     */
    constructor(http, injector) {
        super(http);
        this.http = http;
        this.injector = injector;
        /**
         *  Default hardcoded header values.  Note: Authentication headers are added
         *  at runtime in the httpOptions() method.
         */
        this._headers = new HttpHeaders();
    }
    // Cache requests
    /**
     * @param {?} paramValue
     * @return {?}
     */
    getCache(paramValue) {
        /** @type {?} */
        const url = this.injector.get(BASE_URL) + '/getCache';
        /** @type {?} */
        const params = new HttpParams().set('param', paramValue);
        return this.get(url, params);
    }
    /**
     *
     * @protected
     * @param {?} error
     * @return {?}
     */
    handleError(error) {
        if (error.error instanceof ErrorEvent) {
            // Client-side / network error occured
            console.error('An error occured: ', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code
            console.error(`Backend returned error code: ${error.status}.  Error body: ${error.error}`);
        }
        // A user facing error message /could/ go here; we shouldn't log dev info through the throwError observable
        return throwError('Unable to process request!');
    }
}
CacheApiService.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */
CacheApiService.ctorParameters = () => [
    { type: HttpClient },
    { type: Injector }
];
/** @nocollapse */ CacheApiService.ngInjectableDef = i0.defineInjectable({ factory: function CacheApiService_Factory() { return new CacheApiService(i0.inject(i1.HttpClient), i0.inject(i0.INJECTOR)); }, token: CacheApiService, providedIn: "root" });
if (false) {
    /**
     *  Default hardcoded header values.  Note: Authentication headers are added
     *  at runtime in the httpOptions() method.
     * @type {?}
     * @protected
     */
    CacheApiService.prototype._headers;
    /**
     * @type {?}
     * @protected
     */
    CacheApiService.prototype.http;
    /**
     * @type {?}
     * @private
     */
    CacheApiService.prototype.injector;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUtYXBpLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9wcmltZS1jb3JlLyIsInNvdXJjZXMiOlsic2VydmljZXMvY2FjaGUtYXBpLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNyRSxPQUFPLEVBQ0wsV0FBVyxFQUVYLFVBQVUsRUFDVixVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUMzQyxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBRWxDLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLHlCQUF5QixDQUFDOzs7Ozs7O0FBRzlELE1BQU0sT0FBTyxRQUFRLEdBQUcsSUFBSSxjQUFjLENBQVUsU0FBUyxDQUFFOzs7O0FBSS9ELE1BQU0sT0FBTyxlQUFnQixTQUFRLG1CQUFtQjs7Ozs7SUFPdEQsWUFBdUIsSUFBZ0IsRUFBVSxRQUFrQjtRQUNqRSxLQUFLLENBQUUsSUFBSSxDQUFFLENBQUM7UUFETyxTQUFJLEdBQUosSUFBSSxDQUFZO1FBQVUsYUFBUSxHQUFSLFFBQVEsQ0FBVTs7Ozs7UUFGekQsYUFBUSxHQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0lBSXBELENBQUM7Ozs7OztJQUdELFFBQVEsQ0FBRSxVQUFrQjs7Y0FDcEIsR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFFLFFBQVEsQ0FBQyxHQUFHLFdBQVc7O2NBQ2hELE1BQU0sR0FBRyxJQUFJLFVBQVUsRUFBRSxDQUFDLEdBQUcsQ0FBRSxPQUFPLEVBQUUsVUFBVSxDQUFFO1FBQzFELE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBa0IsR0FBRyxFQUFFLE1BQU0sQ0FBRSxDQUFDO0lBQ2pELENBQUM7Ozs7Ozs7SUFNUyxXQUFXLENBQUMsS0FBd0I7UUFDNUMsSUFBSSxLQUFLLENBQUMsS0FBSyxZQUFZLFVBQVUsRUFBRTtZQUNyQyxzQ0FBc0M7WUFDdEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzFEO2FBQU07WUFDTCxxREFBcUQ7WUFDckQsT0FBTyxDQUFDLEtBQUssQ0FDWCxnQ0FBZ0MsS0FBSyxDQUFDLE1BQU0sa0JBQzFDLEtBQUssQ0FBQyxLQUNSLEVBQUUsQ0FDSCxDQUFDO1NBQ0g7UUFDRCwyR0FBMkc7UUFDM0csT0FBTyxVQUFVLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUNsRCxDQUFDOzs7WUFyQ0YsVUFBVSxTQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRTs7OztZQVRoQyxVQUFVO1lBTFMsUUFBUTs7Ozs7Ozs7OztJQW9CM0IsbUNBQW9EOzs7OztJQUV2QywrQkFBMEI7Ozs7O0lBQUUsbUNBQTBCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgSW5qZWN0b3IsIEluamVjdGlvblRva2VuIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1xuICBIdHRwSGVhZGVycyxcbiAgSHR0cEVycm9yUmVzcG9uc2UsXG4gIEh0dHBQYXJhbXMsXG4gIEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyB0aHJvd0Vycm9yIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBDYWNoZUludGVyZmFjZSB9IGZyb20gJy4uL21vZGVscy9jYWNoZS1hcGkubW9kZWwnO1xuaW1wb3J0IHsgQWJzdHJhY3RIdHRwU2VydmljZSB9IGZyb20gJ21vaC1jb21tb24tbGliL3NlcnZpY2VzJztcblxuLyoqIEJBU0VfVVJMOiBVUkwgZm9yIFJFU1QgcmVxdWVzdHMgKi9cbmV4cG9ydCBjb25zdCBCQVNFX1VSTCA9IG5ldyBJbmplY3Rpb25Ub2tlbjxzdHJpbmc+KCAnQmFzZVVybCcgKTtcblxuLyoqIEJBU0VfVVJMOiBVUkwgZm9yIFJFU1QgcmVxdWVzdHMgKi9cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQ2FjaGVBcGlTZXJ2aWNlIGV4dGVuZHMgQWJzdHJhY3RIdHRwU2VydmljZSB7XG4gIC8qKlxuICAgKiAgRGVmYXVsdCBoYXJkY29kZWQgaGVhZGVyIHZhbHVlcy4gIE5vdGU6IEF1dGhlbnRpY2F0aW9uIGhlYWRlcnMgYXJlIGFkZGVkXG4gICAqICBhdCBydW50aW1lIGluIHRoZSBodHRwT3B0aW9ucygpIG1ldGhvZC5cbiAgICovXG4gIHByb3RlY3RlZCBfaGVhZGVyczogSHR0cEhlYWRlcnMgPSBuZXcgSHR0cEhlYWRlcnMoKTtcblxuICBjb25zdHJ1Y3RvciggcHJvdGVjdGVkIGh0dHA6IEh0dHBDbGllbnQsIHByaXZhdGUgaW5qZWN0b3I6IEluamVjdG9yICkge1xuICAgIHN1cGVyKCBodHRwICk7XG4gIH1cblxuICAvLyBDYWNoZSByZXF1ZXN0c1xuICBnZXRDYWNoZSggcGFyYW1WYWx1ZTogc3RyaW5nICkge1xuICAgIGNvbnN0IHVybCA9IHRoaXMuaW5qZWN0b3IuZ2V0KCBCQVNFX1VSTCkgKyAnL2dldENhY2hlJztcbiAgICBjb25zdCBwYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpLnNldCggJ3BhcmFtJywgcGFyYW1WYWx1ZSApO1xuICAgIHJldHVybiB0aGlzLmdldDxDYWNoZUludGVyZmFjZT4oIHVybCwgcGFyYW1zICk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIGVycm9yXG4gICAqL1xuICBwcm90ZWN0ZWQgaGFuZGxlRXJyb3IoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSB7XG4gICAgaWYgKGVycm9yLmVycm9yIGluc3RhbmNlb2YgRXJyb3JFdmVudCkge1xuICAgICAgLy8gQ2xpZW50LXNpZGUgLyBuZXR3b3JrIGVycm9yIG9jY3VyZWRcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0FuIGVycm9yIG9jY3VyZWQ6ICcsIGVycm9yLmVycm9yLm1lc3NhZ2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBUaGUgYmFja2VuZCByZXR1cm5lZCBhbiB1bnN1Y2Nlc3NmdWwgcmVzcG9uc2UgY29kZVxuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgYEJhY2tlbmQgcmV0dXJuZWQgZXJyb3IgY29kZTogJHtlcnJvci5zdGF0dXN9LiAgRXJyb3IgYm9keTogJHtcbiAgICAgICAgICBlcnJvci5lcnJvclxuICAgICAgICB9YFxuICAgICAgKTtcbiAgICB9XG4gICAgLy8gQSB1c2VyIGZhY2luZyBlcnJvciBtZXNzYWdlIC9jb3VsZC8gZ28gaGVyZTsgd2Ugc2hvdWxkbid0IGxvZyBkZXYgaW5mbyB0aHJvdWdoIHRoZSB0aHJvd0Vycm9yIG9ic2VydmFibGVcbiAgICByZXR1cm4gdGhyb3dFcnJvcignVW5hYmxlIHRvIHByb2Nlc3MgcmVxdWVzdCEnKTtcbiAgfVxufVxuIl19