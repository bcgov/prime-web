/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CacheApiService } from './cache-api.service';
import { map } from 'rxjs/operators';
import * as i0 from "@angular/core";
import * as i1 from "./cache-api.service";
/**
 * TODO: Set up service to store data returned from the cache service once
 *       determined how it will be configured/setup
 */
export class CacheService {
    /**
     * @param {?} cacheApiService
     */
    constructor(cacheApiService) {
        this.cacheApiService = cacheApiService;
        // We use private BehaviorSubjects to cache results instead of having repeat
        // HTTP requests. This way the response is cached for the lifetime of the
        // session.
        this.$provinceListSubject = new BehaviorSubject([]);
        this.$countrylistSubject = new BehaviorSubject([]);
        this.$enhancedMessagesSubject = new BehaviorSubject([]);
        this.$sysParamListSubject = new BehaviorSubject([]);
        /**
         * Message List
         * Populated via call to reg/rest/getCache?param=messages
         */
        this.$enhancedMsgList = this.$enhancedMessagesSubject.asObservable();
        /**
         * Country List
         * Populated via call to reg/rest/getCache?param=countries
         */
        this.$countryList = this.$countrylistSubject.asObservable();
        /**
         * Province List
         * Populated via call to reg/rest/getCache?param=provinces
         */
        this.$provinceList = this.$provinceListSubject.asObservable();
        /**
         * System Parameter List
         * Populated via call to reg/rest/getCache?param=sysParam
         */
        this.$sysParamList = this.$sysParamListSubject.asObservable();
        this.setupBehaviorSubject('provinces', 'province', this.$provinceListSubject);
        this.setupBehaviorSubject('countries', 'country', this.$countrylistSubject);
        this.setupBehaviorSubject('messages', 'messages', this.$enhancedMessagesSubject);
        this.setupBehaviorSubject('sysParams', 'sysParam', this.$sysParamListSubject);
    }
    /**
     * A simple helper to setup BehaviorSubjects and Observables with API data.
     * HTTP requests will be sent out immediately at application load.
     *
     * We use BehaviorSubjects to cache values to stop repeat responses. This
     * requires that the properties are already setup on the class, including the
     * Observable and BehaviorSubject.
     *
     * @protected
     * @template T
     * @param {?} cacheName the name of the parameter to pass to getCache()
     * @param {?} propertyName the name of the property on the response we want
     * @param {?} $subject the BehaviorSubject to emit the value found at propertyName
     * @return {?}
     */
    setupBehaviorSubject(cacheName, propertyName, $subject) {
        this.cacheApiService
            .getCache(cacheName)
            .pipe(map((/**
         * @param {?} x
         * @return {?}
         */
        x => x[propertyName])))
            .subscribe((/**
         * @param {?} val
         * @return {?}
         */
        val => $subject.next(val)));
    }
}
CacheService.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */
CacheService.ctorParameters = () => [
    { type: CacheApiService }
];
/** @nocollapse */ CacheService.ngInjectableDef = i0.defineInjectable({ factory: function CacheService_Factory() { return new CacheService(i0.inject(i1.CacheApiService)); }, token: CacheService, providedIn: "root" });
if (false) {
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$provinceListSubject;
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$countrylistSubject;
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$enhancedMessagesSubject;
    /**
     * @type {?}
     * @private
     */
    CacheService.prototype.$sysParamListSubject;
    /**
     * Message List
     * Populated via call to reg/rest/getCache?param=messages
     * @type {?}
     */
    CacheService.prototype.$enhancedMsgList;
    /**
     * Country List
     * Populated via call to reg/rest/getCache?param=countries
     * @type {?}
     */
    CacheService.prototype.$countryList;
    /**
     * Province List
     * Populated via call to reg/rest/getCache?param=provinces
     * @type {?}
     */
    CacheService.prototype.$provinceList;
    /**
     * System Parameter List
     * Populated via call to reg/rest/getCache?param=sysParam
     * @type {?}
     */
    CacheService.prototype.$sysParamList;
    /**
     * @type {?}
     * @protected
     */
    CacheService.prototype.cacheApiService;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL3ByaW1lLWNvcmUvIiwic291cmNlcyI6WyJzZXJ2aWNlcy9jYWNoZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBYyxlQUFlLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDbkQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7Ozs7OztBQVNyQyxNQUFNLE9BQU8sWUFBWTs7OztJQWdEdkIsWUFBc0IsZUFBZ0M7UUFBaEMsb0JBQWUsR0FBZixlQUFlLENBQWlCOzs7O1FBNUM5Qyx5QkFBb0IsR0FFeEIsSUFBSSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEIsd0JBQW1CLEdBRXZCLElBQUksZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3BCLDZCQUF3QixHQUU1QixJQUFJLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwQix5QkFBb0IsR0FFeEIsSUFBSSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7Ozs7O1FBT3JCLHFCQUFnQixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFNaEUsaUJBQVksR0FFZixJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLENBQUM7Ozs7O1FBTXJDLGtCQUFhLEdBRWhCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQzs7Ozs7UUFNdEMsa0JBQWEsR0FFaEIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxDQUFDO1FBRzNDLElBQUksQ0FBQyxvQkFBb0IsQ0FDdkIsV0FBVyxFQUNYLFVBQVUsRUFDVixJQUFJLENBQUMsb0JBQW9CLENBQzFCLENBQUM7UUFDRixJQUFJLENBQUMsb0JBQW9CLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsb0JBQW9CLENBQ3ZCLFVBQVUsRUFDVixVQUFVLEVBQ1YsSUFBSSxDQUFDLHdCQUF3QixDQUM5QixDQUFDO1FBQ0YsSUFBSSxDQUFDLG9CQUFvQixDQUN2QixXQUFXLEVBQ1gsVUFBVSxFQUNWLElBQUksQ0FBQyxvQkFBb0IsQ0FDMUIsQ0FBQztJQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7SUFjUyxvQkFBb0IsQ0FDNUIsU0FBaUIsRUFDakIsWUFBb0IsRUFDcEIsUUFBNEI7UUFFNUIsSUFBSSxDQUFDLGVBQWU7YUFDakIsUUFBUSxDQUFDLFNBQVMsQ0FBQzthQUNuQixJQUFJLENBQUMsR0FBRzs7OztRQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFDLENBQUM7YUFDL0IsU0FBUzs7OztRQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDO0lBQzFDLENBQUM7OztZQXpGRixVQUFVLFNBQUMsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFOzs7O1lBVHpCLGVBQWU7Ozs7Ozs7O0lBY3RCLDRDQUU0Qjs7Ozs7SUFDNUIsMkNBRTRCOzs7OztJQUM1QixnREFFNEI7Ozs7O0lBQzVCLDRDQUU0Qjs7Ozs7O0lBTzVCLHdDQUF1RTs7Ozs7O0lBTXZFLG9DQUU0Qzs7Ozs7O0lBTTVDLHFDQUU2Qzs7Ozs7O0lBTTdDLHFDQUU2Qzs7Ozs7SUFFakMsdUNBQTBDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgQmVoYXZpb3JTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBDYWNoZUFwaVNlcnZpY2UgfSBmcm9tICcuL2NhY2hlLWFwaS5zZXJ2aWNlJztcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IFN0YXR1c01zZ0ludGVyZmFjZSB9IGZyb20gJy4uL21vZGVscy9hcGktYmFzZS5tb2RlbCc7XG5pbXBvcnQgeyBTeXNQYXJhbUludGVyZmFjZSB9IGZyb20gJy4uL21vZGVscy9jYWNoZS1hcGkubW9kZWwnO1xuaW1wb3J0IHsgUHJvdmluY2VMaXN0LCBDb3VudHJ5TGlzdCB9IGZyb20gJy4uL2xpYi9jb21wb25lbnRzL2FkZHJlc3MvYWRkcmVzcy5jb21wb25lbnQnO1xuLyoqXG4gKiBUT0RPOiBTZXQgdXAgc2VydmljZSB0byBzdG9yZSBkYXRhIHJldHVybmVkIGZyb20gdGhlIGNhY2hlIHNlcnZpY2Ugb25jZVxuICogICAgICAgZGV0ZXJtaW5lZCBob3cgaXQgd2lsbCBiZSBjb25maWd1cmVkL3NldHVwXG4gKi9cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQ2FjaGVTZXJ2aWNlIHtcbiAgLy8gV2UgdXNlIHByaXZhdGUgQmVoYXZpb3JTdWJqZWN0cyB0byBjYWNoZSByZXN1bHRzIGluc3RlYWQgb2YgaGF2aW5nIHJlcGVhdFxuICAvLyBIVFRQIHJlcXVlc3RzLiBUaGlzIHdheSB0aGUgcmVzcG9uc2UgaXMgY2FjaGVkIGZvciB0aGUgbGlmZXRpbWUgb2YgdGhlXG4gIC8vIHNlc3Npb24uXG4gIHByaXZhdGUgJHByb3ZpbmNlTGlzdFN1YmplY3Q6IEJlaGF2aW9yU3ViamVjdDxcbiAgICBQcm92aW5jZUxpc3RbXVxuICA+ID0gbmV3IEJlaGF2aW9yU3ViamVjdChbXSk7XG4gIHByaXZhdGUgJGNvdW50cnlsaXN0U3ViamVjdDogQmVoYXZpb3JTdWJqZWN0PFxuICAgIENvdW50cnlMaXN0W11cbiAgPiA9IG5ldyBCZWhhdmlvclN1YmplY3QoW10pO1xuICBwcml2YXRlICRlbmhhbmNlZE1lc3NhZ2VzU3ViamVjdDogQmVoYXZpb3JTdWJqZWN0PFxuICAgIFN0YXR1c01zZ0ludGVyZmFjZVtdXG4gID4gPSBuZXcgQmVoYXZpb3JTdWJqZWN0KFtdKTtcbiAgcHJpdmF0ZSAkc3lzUGFyYW1MaXN0U3ViamVjdDogQmVoYXZpb3JTdWJqZWN0PFxuICAgIFN5c1BhcmFtSW50ZXJmYWNlW11cbiAgPiA9IG5ldyBCZWhhdmlvclN1YmplY3QoW10pO1xuXG5cbiAgLyoqXG4gICAqIE1lc3NhZ2UgTGlzdFxuICAgKiBQb3B1bGF0ZWQgdmlhIGNhbGwgdG8gcmVnL3Jlc3QvZ2V0Q2FjaGU/cGFyYW09bWVzc2FnZXNcbiAgICovXG4gIHB1YmxpYyAkZW5oYW5jZWRNc2dMaXN0ID0gdGhpcy4kZW5oYW5jZWRNZXNzYWdlc1N1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG5cbiAgLyoqXG4gICAqIENvdW50cnkgTGlzdFxuICAgKiBQb3B1bGF0ZWQgdmlhIGNhbGwgdG8gcmVnL3Jlc3QvZ2V0Q2FjaGU/cGFyYW09Y291bnRyaWVzXG4gICAqL1xuICBwdWJsaWMgJGNvdW50cnlMaXN0OiBPYnNlcnZhYmxlPFxuICAgIENvdW50cnlMaXN0W11cbiAgPiA9IHRoaXMuJGNvdW50cnlsaXN0U3ViamVjdC5hc09ic2VydmFibGUoKTtcblxuICAvKipcbiAgICogUHJvdmluY2UgTGlzdFxuICAgKiBQb3B1bGF0ZWQgdmlhIGNhbGwgdG8gcmVnL3Jlc3QvZ2V0Q2FjaGU/cGFyYW09cHJvdmluY2VzXG4gICAqL1xuICBwdWJsaWMgJHByb3ZpbmNlTGlzdDogT2JzZXJ2YWJsZTxcbiAgICBQcm92aW5jZUxpc3RbXVxuICA+ID0gdGhpcy4kcHJvdmluY2VMaXN0U3ViamVjdC5hc09ic2VydmFibGUoKTtcblxuICAvKipcbiAgICogU3lzdGVtIFBhcmFtZXRlciBMaXN0XG4gICAqIFBvcHVsYXRlZCB2aWEgY2FsbCB0byByZWcvcmVzdC9nZXRDYWNoZT9wYXJhbT1zeXNQYXJhbVxuICAgKi9cbiAgcHVibGljICRzeXNQYXJhbUxpc3Q6IE9ic2VydmFibGU8XG4gICAgU3lzUGFyYW1JbnRlcmZhY2VbXVxuICA+ID0gdGhpcy4kc3lzUGFyYW1MaXN0U3ViamVjdC5hc09ic2VydmFibGUoKTtcblxuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgY2FjaGVBcGlTZXJ2aWNlOiBDYWNoZUFwaVNlcnZpY2UpIHtcbiAgICB0aGlzLnNldHVwQmVoYXZpb3JTdWJqZWN0KFxuICAgICAgJ3Byb3ZpbmNlcycsXG4gICAgICAncHJvdmluY2UnLFxuICAgICAgdGhpcy4kcHJvdmluY2VMaXN0U3ViamVjdFxuICAgICk7XG4gICAgdGhpcy5zZXR1cEJlaGF2aW9yU3ViamVjdCgnY291bnRyaWVzJywgJ2NvdW50cnknLCB0aGlzLiRjb3VudHJ5bGlzdFN1YmplY3QpO1xuICAgIHRoaXMuc2V0dXBCZWhhdmlvclN1YmplY3QoXG4gICAgICAnbWVzc2FnZXMnLFxuICAgICAgJ21lc3NhZ2VzJyxcbiAgICAgIHRoaXMuJGVuaGFuY2VkTWVzc2FnZXNTdWJqZWN0XG4gICAgKTtcbiAgICB0aGlzLnNldHVwQmVoYXZpb3JTdWJqZWN0KFxuICAgICAgJ3N5c1BhcmFtcycsXG4gICAgICAnc3lzUGFyYW0nLFxuICAgICAgdGhpcy4kc3lzUGFyYW1MaXN0U3ViamVjdFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogQSBzaW1wbGUgaGVscGVyIHRvIHNldHVwIEJlaGF2aW9yU3ViamVjdHMgYW5kIE9ic2VydmFibGVzIHdpdGggQVBJIGRhdGEuXG4gICAqIEhUVFAgcmVxdWVzdHMgd2lsbCBiZSBzZW50IG91dCBpbW1lZGlhdGVseSBhdCBhcHBsaWNhdGlvbiBsb2FkLlxuICAgKlxuICAgKiBXZSB1c2UgQmVoYXZpb3JTdWJqZWN0cyB0byBjYWNoZSB2YWx1ZXMgdG8gc3RvcCByZXBlYXQgcmVzcG9uc2VzLiBUaGlzXG4gICAqIHJlcXVpcmVzIHRoYXQgdGhlIHByb3BlcnRpZXMgYXJlIGFscmVhZHkgc2V0dXAgb24gdGhlIGNsYXNzLCBpbmNsdWRpbmcgdGhlXG4gICAqIE9ic2VydmFibGUgYW5kIEJlaGF2aW9yU3ViamVjdC5cbiAgICpcbiAgICogQHBhcmFtIGNhY2hlTmFtZSB0aGUgbmFtZSBvZiB0aGUgcGFyYW1ldGVyIHRvIHBhc3MgdG8gZ2V0Q2FjaGUoKVxuICAgKiBAcGFyYW0gcHJvcGVydHlOYW1lIHRoZSBuYW1lIG9mIHRoZSBwcm9wZXJ0eSBvbiB0aGUgcmVzcG9uc2Ugd2Ugd2FudFxuICAgKiBAcGFyYW0gJHN1YmplY3QgdGhlIEJlaGF2aW9yU3ViamVjdCB0byBlbWl0IHRoZSB2YWx1ZSBmb3VuZCBhdCBwcm9wZXJ0eU5hbWVcbiAgICovXG4gIHByb3RlY3RlZCBzZXR1cEJlaGF2aW9yU3ViamVjdDxUPihcbiAgICBjYWNoZU5hbWU6IHN0cmluZyxcbiAgICBwcm9wZXJ0eU5hbWU6IHN0cmluZyxcbiAgICAkc3ViamVjdDogQmVoYXZpb3JTdWJqZWN0PFQ+XG4gICkge1xuICAgIHRoaXMuY2FjaGVBcGlTZXJ2aWNlXG4gICAgICAuZ2V0Q2FjaGUoY2FjaGVOYW1lKVxuICAgICAgLnBpcGUobWFwKHggPT4geFtwcm9wZXJ0eU5hbWVdKSlcbiAgICAgIC5zdWJzY3JpYmUodmFsID0+ICRzdWJqZWN0Lm5leHQodmFsKSk7XG4gIH1cbn1cbiJdfQ==