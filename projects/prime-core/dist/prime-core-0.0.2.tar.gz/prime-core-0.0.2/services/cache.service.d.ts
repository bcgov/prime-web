import { Observable, BehaviorSubject } from 'rxjs';
import { CacheApiService } from './cache-api.service';
import { StatusMsgInterface } from '../models/api-base.model';
import { SysParamInterface } from '../models/cache-api.model';
import { ProvinceList, CountryList } from '../lib/components/address/address.component';
/**
 * TODO: Set up service to store data returned from the cache service once
 *       determined how it will be configured/setup
 */
export declare class CacheService {
    protected cacheApiService: CacheApiService;
    private $provinceListSubject;
    private $countrylistSubject;
    private $enhancedMessagesSubject;
    private $sysParamListSubject;
    /**
     * Message List
     * Populated via call to reg/rest/getCache?param=messages
     */
    $enhancedMsgList: Observable<StatusMsgInterface[]>;
    /**
     * Country List
     * Populated via call to reg/rest/getCache?param=countries
     */
    $countryList: Observable<CountryList[]>;
    /**
     * Province List
     * Populated via call to reg/rest/getCache?param=provinces
     */
    $provinceList: Observable<ProvinceList[]>;
    /**
     * System Parameter List
     * Populated via call to reg/rest/getCache?param=sysParam
     */
    $sysParamList: Observable<SysParamInterface[]>;
    constructor(cacheApiService: CacheApiService);
    /**
     * A simple helper to setup BehaviorSubjects and Observables with API data.
     * HTTP requests will be sent out immediately at application load.
     *
     * We use BehaviorSubjects to cache values to stop repeat responses. This
     * requires that the properties are already setup on the class, including the
     * Observable and BehaviorSubject.
     *
     * @param cacheName the name of the parameter to pass to getCache()
     * @param propertyName the name of the property on the response we want
     * @param $subject the BehaviorSubject to emit the value found at propertyName
     */
    protected setupBehaviorSubject<T>(cacheName: string, propertyName: string, $subject: BehaviorSubject<T>): void;
}
