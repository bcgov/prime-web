import { Injector, InjectionToken } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient } from '@angular/common/http';
import { CacheInterface } from '../models/cache-api.model';
import { AbstractHttpService } from 'moh-common-lib/services';
/** BASE_URL: URL for REST requests */
export declare const BASE_URL: InjectionToken<string>;
/** BASE_URL: URL for REST requests */
export declare class CacheApiService extends AbstractHttpService {
    protected http: HttpClient;
    private injector;
    /**
     *  Default hardcoded header values.  Note: Authentication headers are added
     *  at runtime in the httpOptions() method.
     */
    protected _headers: HttpHeaders;
    constructor(http: HttpClient, injector: Injector);
    getCache(paramValue: string): import("rxjs").Observable<CacheInterface>;
    /**
     *
     * @param error
     */
    protected handleError(error: HttpErrorResponse): import("rxjs").Observable<never>;
}
