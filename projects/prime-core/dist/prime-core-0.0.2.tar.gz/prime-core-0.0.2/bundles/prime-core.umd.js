(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('moh-common-lib'), require('@angular/common'), require('@ng-select/ng-select'), require('angular2-text-mask'), require('ngx-bootstrap'), require('@angular/forms'), require('@angular/platform-browser'), require('@angular/router'), require('moh-common-lib/models'), require('@angular/common/http'), require('moh-common-lib/services'), require('@angular/core'), require('rxjs'), require('rxjs/operators')) :
    typeof define === 'function' && define.amd ? define('prime-core', ['exports', 'moh-common-lib', '@angular/common', '@ng-select/ng-select', 'angular2-text-mask', 'ngx-bootstrap', '@angular/forms', '@angular/platform-browser', '@angular/router', 'moh-common-lib/models', '@angular/common/http', 'moh-common-lib/services', '@angular/core', 'rxjs', 'rxjs/operators'], factory) :
    (factory((global['prime-core'] = {}),global.mohCommonLib,global.ng.common,global.ngSelect,global.angular2TextMask,global.ngxBootstrap,global.ng.forms,global.ng.platformBrowser,global.ng.router,global.models,global.ng.common.http,global.services,global.ng.core,global.rxjs,global.rxjs.operators));
}(this, (function (exports,mohCommonLib,common,ngSelect,angular2TextMask,ngxBootstrap,forms,platformBrowser,router,models,i1,services,i0,rxjs,operators) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (b.hasOwnProperty(p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var PrimePerson = /** @class */ (function (_super) {
        __extends(PrimePerson, _super);
        function PrimePerson() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            /**
             * Identify and mailing addresses
             */
            _this.address = new models.Address();
            _this.mailAddress = new models.Address();
            _this.identityIsMailingAddress = true;
            return _this;
        }
        /* Copy function */
        /* Copy function */
        /**
         * @param {?} object
         * @return {?}
         */
        PrimePerson.prototype.copy = /* Copy function */
            /**
             * @param {?} object
             * @return {?}
             */
            function (object) {
                _super.prototype.copy.call(this, object);
                this.preferredFirstName = object.preferredFirstName;
                this.preferredMiddleName = object.preferredMiddleName;
                this.preferredLastName = object.preferredLastName;
                this.address.copy(object.address);
                this.mailAddress.copy(object.mailAddress);
            };
        return PrimePerson;
    }(models.Person));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Common to all PRIME applications
     */
    var PrimeConstants = /** @class */ (function () {
        function PrimeConstants() {
        }
        // Email length from database
        PrimeConstants.EMAIL_MAXLEN = '256';
        // Address Constants
        PrimeConstants.CANADA = 'CAN';
        PrimeConstants.BRITISH_COLUMBIA = 'BC';
        return PrimeConstants;
    }());
    /** @enum {string} */
    var ProviderCode = {
        MOH: 'MOH',
        BCSC: 'BCSC',
    };
    /** @enum {string} */
    var AssuranceLevel = {
        LEVEL_1: '1',
        LEVEL_2: '2',
        LEVEL_3: '3',
    };

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ProfileComponent = /** @class */ (function (_super) {
        __extends(ProfileComponent, _super);
        function ProfileComponent(cntrlContainer) {
            var _this = _super.call(this) || this;
            _this.cntrlContainer = cntrlContainer;
            _this.data = new PrimePerson();
            _this.countryList = [];
            _this.provinceList = [];
            _this.editIdentityInfo = true;
            _this.pageTitle = 'Profile Information';
            _this.dataChange = new i0.EventEmitter();
            _this.defaultCountry = PrimeConstants.CANADA;
            _this.defaultProvince = PrimeConstants.BRITISH_COLUMBIA;
            /**
             * Date of birth error messages
             */
            _this.dateLabel = 'Birthdate';
            _this._firstNameCtrl = 'first_name';
            _this._preferredFirstNameCtrl = 'preferred_first_name';
            _this._preferredLastNameCtrl = 'preferred_last_name';
            _this._requiredError = { required: true };
            _this.form = ( /** @type {?} */(cntrlContainer));
            return _this;
        }
        /**
         * @param {?} itm
         * @return {?}
         */
        ProfileComponent.prototype.emitChanges = /**
         * @param {?} itm
         * @return {?}
         */
            function (itm) {
                this.dataChange.emit(itm);
            };
        /**
         * @return {?}
         */
        ProfileComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                // Listen for submission of form
                /** @type {?} */
                var newObs = new rxjs.Observable();
                newObs = rxjs.of(this.data);
                newObs.subscribe(( /**
                 * @param {?} obs
                 * @return {?}
                 */function (obs) { return console.log(obs); }));
                this.subscriptions = [
                    this.cntrlContainer.valueChanges.subscribe(( /**
                     * @param {?} obs
                     * @return {?}
                     */function (obs) { return _this.emitChanges(obs); }))
                ];
            };
        /**
         * @return {?}
         */
        ProfileComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                this.subscriptions.forEach(( /**
                 * @param {?} itm
                 * @return {?}
                 */function (itm) { return itm.unsubscribe(); }));
            };
        /**
         * @return {?}
         */
        ProfileComponent.prototype.toggleCheckBox = /**
         * @return {?}
         */
            function () {
                this.data.identityIsMailingAddress = !this.data.identityIsMailingAddress;
            };
        /**
         * @param {?} event
         * @return {?}
         */
        ProfileComponent.prototype.onBlur = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                if (event.srcElement.id === this._preferredFirstNameCtrl ||
                    event.srcElement.id === this._preferredLastNameCtrl ||
                    event.srcElement.id === this._firstNameCtrl) {
                    /** @type {?} */
                    var hasPreferFirstName = !!this.form.controls[this._preferredFirstNameCtrl].value;
                    /** @type {?} */
                    var hasPreferLastName = !!this.form.controls[this._preferredLastNameCtrl].value;
                    /** @type {?} */
                    var hasFirstName = !!this.form.controls[this._firstNameCtrl].value;
                    // If either preferred name is entered and user has firstname, both must be entered.
                    if (hasFirstName) {
                        if (hasPreferFirstName && !hasPreferLastName) {
                            this.setCntrolError(this._preferredLastNameCtrl, this._requiredError);
                        }
                        else if (!hasPreferFirstName && hasPreferLastName) {
                            this.setCntrolError(this._preferredFirstNameCtrl, this._requiredError);
                        }
                        else {
                            this.setCntrolError(this._preferredLastNameCtrl, null);
                            this.setCntrolError(this._preferredFirstNameCtrl, null);
                        }
                    }
                }
            };
        /**
         * @private
         * @param {?} ctrlName
         * @param {?} error
         * @return {?}
         */
        ProfileComponent.prototype.setCntrolError = /**
         * @private
         * @param {?} ctrlName
         * @param {?} error
         * @return {?}
         */
            function (ctrlName, error) {
                this.form.controls[ctrlName].setErrors(error);
                this.form.controls[ctrlName].markAsTouched();
            };
        ProfileComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-profile',
                        template: "<h2>{{pageTitle}}</h2>\n\n<div>\n  <p class=\"border-bottom\">Your Information</p>\n\n  <ng-content select=\"[identityInstruct]\"></ng-content>\n\n  <common-page-section layout='tips'>\n    <div class=\"form-group col-sm-6 p-sm-0\">\n      <lib-prime-name label=\"First Name\" [disabled]=\"!editIdentityInfo\" [(nameStr)]=\"data.firstName\"\n        (blurEvent)=\"onBlur($event)\" objectID=\"first_name\"></lib-prime-name>\n    </div>\n\n    <div class=\"form-group col-sm-6 p-sm-0\">\n      <lib-prime-name label=\"Middle Name\" [disabled]=\"!editIdentityInfo\" [(nameStr)]=\"data.middleName\"\n        objectID=\"middle_name\"></lib-prime-name>\n    </div>\n\n    <div class=\"form-group col-sm-6 p-sm-0\">\n      <lib-prime-name label=\"Last Name\" [required]=\"true\" [disabled]=\"!editIdentityInfo\" [(nameStr)]=\"data.lastName\"\n        objectID=\"last_name\"></lib-prime-name>\n    </div>\n\n    <div class=\"col-sm-6 p-sm-0\">\n      <common-date [disabled]=\"!editIdentityInfo\" [label]=\"dateLabel\" [restrictDate]=\"'past'\"\n        [(date)]=\"data.dateOfBirth\"></common-date>\n    </div>\n\n    <aside>TIPS</aside>\n  </common-page-section>\n</div>\n\n<div>\n  <h2 class=\"border-bottom\">Preferred Name (Optional)</h2>\n\n  <p>\n    If you have a name that is different than your legal name that people know you by,\n    enter your full preferred name.\n  </p>\n\n  <common-page-section layout='tips'>\n    <div class=\"form-group col-sm-6 p-sm-0\">\n      <lib-prime-name label=\"Preferred First Name\" [(nameStr)]=\"data.preferredFirstName\" objectID=\"preferred_first_name\"\n        (blurEvent)=\"onBlur($event)\"></lib-prime-name>\n    </div>\n\n    <div class=\"form-group col-sm-6 p-sm-0\">\n      <lib-prime-name label=\"Preferred Middle Name\" [(nameStr)]=\"data.preferredMiddleName\" objectID=\"preferred_middle_name\">\n      </lib-prime-name>\n    </div>\n\n    <div class=\"form-group col-sm-6 p-sm-0\">\n      <lib-prime-name label=\"Preferred Last Name\" [(nameStr)]=\"data.preferredLastName\" objectID=\"preferred_last_name\"\n        (blurEvent)=\"onBlur($event)\"></lib-prime-name>\n    </div>\n    <aside>TIPS</aside>\n  </common-page-section>\n</div>\n\n<common-page-section layout='double'>\n  <h2 class=\"border-bottom\">Address</h2>\n  <lib-prime-address [disabled]=\"!editIdentityInfo\" [(address)]=\"data.address\" [defaultCountry]=\"defaultCountry\"\n    [countryList]=\"countryList\" [defaultProvince]=\"defaultProvince\" [provinceList]=\"provinceList\" [isRequired]=\"true\">\n  </lib-prime-address>\n  <div class=\"custom-control custom-checkbox\">\n    <input type=\"checkbox\" class=\"custom-control-input\" id=\"isMailingAddress\" [checked]=\"data.identityIsMailingAddress\"\n      (click)=\"toggleCheckBox()\" />\n    <label class=\"custom-control-label\" for=\"isMailingAddress\">\n      This is my mailing address.\n    </label>\n  </div>\n  <aside>\n    <h2 class=\"border-bottom\">Mailing Address</h2>\n    <div *ngIf=\"!data.identityIsMailingAddress; else NoMailingAddress\">\n      <lib-prime-address [(address)]=\"data.mailAddress\" [defaultCountry]=\"defaultCountry\" [countryList]=\"countryList\"\n        [defaultProvince]=\"defaultProvince\" [provinceList]=\"provinceList\" [isRequired]=\"true\"></lib-prime-address>\n    </div>\n  </aside>\n</common-page-section>\n\n<ng-template #NoMailingAddress>\n  <div class=\"mail-address-container\">\n    <button type=\"button\" class=\"btn btn-lg btn-warning mx-auto d-block\" (click)=\"toggleCheckBox()\">My mailing address\n      is different.</button>\n  </div>\n</ng-template>\n",
                        /* Re-use the same ngForm that it's parent is using. The component will show
                           * up in its parents `this.form`, and will auto-update `this.form.valid`
                           */
                        viewProviders: [
                            { provide: forms.ControlContainer, useExisting: i0.forwardRef(( /**
                                     * @return {?}
                                     */function () { return forms.NgForm; })) }
                        ],
                        styles: [""]
                    }] }
        ];
        /** @nocollapse */
        ProfileComponent.ctorParameters = function () {
            return [
                { type: forms.ControlContainer }
            ];
        };
        ProfileComponent.propDecorators = {
            data: [{ type: i0.Input }],
            countryList: [{ type: i0.Input }],
            provinceList: [{ type: i0.Input }],
            editIdentityInfo: [{ type: i0.Input }],
            pageTitle: [{ type: i0.Input }],
            dataChange: [{ type: i0.Output }]
        };
        return ProfileComponent;
    }(models.Base));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var AddressComponent = /** @class */ (function (_super) {
        __extends(AddressComponent, _super);
        function AddressComponent(geocoderService) {
            var _this = _super.call(this) || this;
            _this.geocoderService = geocoderService;
            // Field lengths
            _this.CITY_MAXLEN = '100';
            _this.PROV_MAXLEN = '250';
            _this.STREET_RURAL_MAXLEN = '1000';
            _this.disabled = false;
            _this.isRequired = false;
            _this.address = new models.Address();
            _this.addressChange = new i0.EventEmitter();
            /**
             * The subject that triggers on user text input and gets typeaheadList$ to update.
             */
            _this.searchText$ = new rxjs.Subject();
            return _this;
        }
        /**
         * @return {?}
         */
        AddressComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                // Set up for using GeoCoder
                this.typeaheadList$ = this.searchText$.pipe(operators.debounceTime(500), operators.distinctUntilChanged(), 
                // Trigger the network request, get results
                operators.switchMap(( /**
                 * @param {?} searchPhrase
                 * @return {?}
                 */function (searchPhrase) {
                    return _this.geocoderService.lookup(searchPhrase);
                })), 
                // tap(log => console.log('taplog', log)),
                operators.catchError(( /**
                 * @param {?} err
                 * @return {?}
                 */function (err) { return _this.onError(err); })));
            };
        /**
         * Set country province blank
         * @param value
         */
        /**
         * Set country province blank
         * @param {?} value
         * @return {?}
         */
        AddressComponent.prototype.setCountry = /**
         * Set country province blank
         * @param {?} value
         * @return {?}
         */
            function (value) {
                this.address.province = this.setDefaultProvinceAsOption(value);
                this.address.country = value;
                this.updateProvList();
                this.addressChange.emit(this.address);
            };
        /**
         * @param {?} value
         * @return {?}
         */
        AddressComponent.prototype.setProvince = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                this.address.province = value;
                this.addressChange.emit(this.address);
            };
        /**
         * @param {?} value
         * @return {?}
         */
        AddressComponent.prototype.setStreetAddress = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                this.address.street = value;
                this.addressChange.emit(this.address);
            };
        /**
         * @param {?} value
         * @return {?}
         */
        AddressComponent.prototype.setCity = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                this.address.city = value;
                this.addressChange.emit(this.address);
            };
        Object.defineProperty(AddressComponent.prototype, "postalCode", {
            get: /**
             * @return {?}
             */ function () {
                return this.address.postal;
            },
            /**
             * Sets string after converted upper case
             * @param text
             */
            set: /**
             * Sets string after converted upper case
             * @param {?} value
             * @return {?}
             */ function (value) {
                this.address.postal = value.toUpperCase();
                this.addressChange.emit(this.address);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        AddressComponent.prototype.isCanada = /**
         * @return {?}
         */
            function () {
                return this.address && 'CAN' === this.address.country;
            };
        /**
         * @return {?}
         */
        AddressComponent.prototype.isCanadaUSA = /**
         * @return {?}
         */
            function () {
                return (this.address && 'USA' === this.address.country) || this.isCanada();
            };
        /**
         * @param {?} changes
         * @return {?}
         */
        AddressComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
            function (changes) {
                if (changes['countryList'] && changes['countryList'].currentValue) {
                    if (!this.address.country) {
                        // Set defaults
                        this.address.country = this.setDefaultCountryAsOption();
                    }
                    // Set defaults
                    this.address.province = this.setDefaultProvinceAsOption(this.address.country);
                    this.updateProvList();
                }
                if (changes['provinceList'] && changes['provinceList'].currentValue) {
                    if (!this.address.province) {
                        // Set defaults
                        this.address.province = this.setDefaultProvinceAsOption(this.address.country);
                    }
                    this.updateProvList();
                }
            };
        /**
         * Updates the provList variable. Values must be stored in a variable and not
         * accessed via function invocation for performance.
         */
        /**
         * Updates the provList variable. Values must be stored in a variable and not
         * accessed via function invocation for performance.
         * @private
         * @return {?}
         */
        AddressComponent.prototype.updateProvList = /**
         * Updates the provList variable. Values must be stored in a variable and not
         * accessed via function invocation for performance.
         * @private
         * @return {?}
         */
            function () {
                var _this = this;
                if (!this.provinceList) {
                    return;
                } // When data is async and hasn't loaded
                this.provList = this.provinceList
                    .map(( /**
             * @param {?} prov
             * @return {?}
             */function (prov) {
                    if (prov.country === _this.address.country) {
                        return prov;
                    }
                }))
                    .filter(( /**
             * @param {?} x
             * @return {?}
             */function (x) { return x; }));
            };
        /**
         * Sets the default province option value
         */
        /**
         * Sets the default province option value
         * @private
         * @param {?} country
         * @return {?}
         */
        AddressComponent.prototype.setDefaultProvinceAsOption = /**
         * Sets the default province option value
         * @private
         * @param {?} country
         * @return {?}
         */
            function (country) {
                var _this = this;
                /** @type {?} */
                var provObj = !this.provinceList ? null : this.provinceList.find(( /**
                 * @param {?} val
                 * @return {?}
                 */function (val) {
                    return (val.provinceCode === _this.defaultProvince ||
                        val.description === _this.defaultProvince) &&
                        val.country === country;
                }));
                return (provObj ? provObj.provinceCode : null);
            };
        /**
         * Set country to default
         * Search uses country code or country name to find item is list.
         */
        /**
         * Set country to default
         * Search uses country code or country name to find item is list.
         * @private
         * @return {?}
         */
        AddressComponent.prototype.setDefaultCountryAsOption = /**
         * Set country to default
         * Search uses country code or country name to find item is list.
         * @private
         * @return {?}
         */
            function () {
                var _this = this;
                /** @type {?} */
                var countryObj = !this.countryList
                    ? null
                    : this.countryList.find(( /**
                     * @param {?} val
                     * @return {?}
                     */function (val) {
                        return val.countryCode === _this.defaultCountry ||
                            val.description === _this.defaultCountry;
                    }));
                return countryObj ? countryObj.countryCode : null;
            };
        // GeoCoder
        /**
         * GeoCoder only is applicable when address is BC, Canada.
         */
        // GeoCoder
        /**
         * GeoCoder only is applicable when address is BC, Canada.
         * @return {?}
         */
        AddressComponent.prototype.useGeoCoder =
            // GeoCoder
            /**
             * GeoCoder only is applicable when address is BC, Canada.
             * @return {?}
             */
            function () {
                return this.isCanada() && 'BC' === this.address.province;
            };
        /**
         * @param {?} event
         * @return {?}
         */
        AddressComponent.prototype.onKeyUp = /**
         * @param {?} event
         * @return {?}
         */
            function (event) {
                /**
                 * Filter out 'enter' and other similar keyboard events that can trigger
                 * when user is selecting a typeahead option instead of entering new text.
                 * Without this filter, we do another HTTP request + force disiplay the UI
                 * for now reason
                 */
                if (event.keyCode === 13 || event.keyCode === 9) {
                    // enter & tab
                    return;
                }
                this.searchText$.next(this.search);
            };
        /**
         * @param {?} err
         * @return {?}
         */
        AddressComponent.prototype.onError = /**
         * @param {?} err
         * @return {?}
         */
            function (err) {
                // Empty array simulates no result response, nothing for typeahead to iterate over
                return rxjs.of([]);
            };
        // Only BC addresses therefore no need to copy province into structure.
        // Only BC addresses therefore no need to copy province into structure.
        /**
         * @param {?} event
         * @return {?}
         */
        AddressComponent.prototype.onSelect =
            // Only BC addresses therefore no need to copy province into structure.
            /**
             * @param {?} event
             * @return {?}
             */
            function (event) {
                /** @type {?} */
                var data = event.item;
                this.search = data.street;
                this.address.street = data.street;
                this.address.city = data.city;
                this.address.province = 'BC';
                this.address.country = 'CAN';
                this.addressChange.emit(this.address);
            };
        AddressComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-address',
                        template: "<div class=\"form-group col-sm-8 p-sm-0\">\n  <label for=\"country_{{objectId}}\">Country</label>\n\n  <ng-select [items]='countryList'\n             [ngModel]='address?.country'\n             (ngModelChange)='setCountry($event)'\n             [required]='isRequired'\n             [disabled]='disabled'\n             name='country_{{objectId}}'\n             labelForId='country_{{objectId}}'\n             bindValue='countryCode'\n             [clearable]='false'\n             bindLabel='description'></ng-select>\n\n</div>\n\n<div class=\"form-group col-sm-8 p-sm-0\">\n  <label for=\"province_{{objectId}}\">Province/State</label>\n  <div *ngIf=\"isCanadaUSA(); else NotCanadaUSA\">\n\n    <ng-select #provRef='ngModel'\n               name='province_{{objectId}}'\n               labelForId='province_{{objectId}}'\n               [ngModel]=\"address?.province\"\n               (ngModelChange)=\"setProvince($event)\"\n               [items]='provList'\n               [required]='isRequired'\n               [disabled]='disabled'\n               bindValue='provinceCode'\n               placeholder='Select a state'\n               [clearable]='false'\n               bindLabel='description'></ng-select>\n\n\n    <!-- Error messages for select -->\n    <div *ngIf=\"!disabled && provRef.touched\"\n        role=\"alert\"\n        class=\"error-container\"\n        aria-live=\"assertive\">\n      <div class=\"text-danger\" *ngIf=\"provRef?.errors?.required\">\n          {{isCanada() ? 'Province' : 'State' }} is required.\n      </div>\n    </div>\n  </div>\n</div>\n\n<div class=\"form-group col-sm-8 p-sm-0\">\n  <label for=\"street_{{objectId}}\">Full street address or rural route</label>\n  <div *ngIf=\"useGeoCoder() && !disabled; else noGeoCoder;\">\n    <input class=\"form-control\"\n           #streetRef=\"ngModel\"\n           spellcheck=\"false\"\n           type=\"text\"\n           id=\"street_{{objectId}}\"\n           name=\"street_{{objectId}}\"\n           [(ngModel)]=\"search\"\n           (keyup)='onKeyUp($event)'\n           [typeahead]='typeaheadList$'\n           (typeaheadOnSelect)=\"onSelect($event)\"\n           typeaheadOptionField='fullAddress'\n           typeaheadMinLength='3'\n           autocomplete=\"nope\"\n           [required]=\"isRequired\"\n           maxlength=\"{{STREET_RURAL_MAXLEN}}\">\n\n    <!-- Error messages for input -->\n    <div *ngIf=\"!disabled && streetRef.touched\"\n         role=\"alert\"\n         class=\"error-container\"\n         aria-live=\"assertive\">\n      <div class=\"text-danger\" *ngIf=\"streetRef?.errors?.required\">\n        Full street address or rural route is required.\n      </div>\n    </div>\n  </div>\n</div>\n\n<div class=\"form-group col-sm-8 p-sm-0\">\n  <label for=\"city_{{objectId}}\">City</label>\n  <input class=\"form-control\"\n          #cityRef=\"ngModel\"\n          spellcheck=\"false\"\n          type=\"text\"\n          id=\"city_{{objectId}}\"\n          name=\"city_{{objectId}}\"\n          [ngModel]=\"address?.city\"\n          (ngModelChange)=\"setCity($event)\"\n          [required]=\"isRequired\"\n          [disabled]=\"disabled\"\n          maxlength=\"{{CITY_MAXLEN}}\"/>\n\n   <!-- Error messages for input -->\n  <div *ngIf=\"!disabled && cityRef.touched\"\n       role=\"alert\"\n       class=\"error-container\"\n       aria-live=\"assertive\">\n    <div class=\"text-danger\" *ngIf=\"cityRef?.errors?.required\">\n      City is required.\n    </div>\n  </div>\n</div>\n\n<div class=\"form-group col-sm-4 p-sm-0\">\n  <common-postal-code [label]=\"'Postal Code'\"\n                      [displayMask]=\"isCanada()\"\n                      [disabled]=\"disabled\"\n                      [(value)]=\"postalCode\"></common-postal-code>\n</div>\n\n<ng-template #NotCanadaUSA>\n  <input #provRef=\"ngModel\"\n         class=\"form-control\"\n         spellcheck=\"false\"\n         type=\"text\"\n         id=\"province_{{objectId}}\"\n         name=\"province_{{objectId}}\"\n         [ngModel]=\"address?.province\"\n         (ngModelChange)=\"setProvince($event)\"\n         [required]=\"isRequired\"\n         [disabled]=\"disabled\"\n         maxlength=\"{{PROV_MAXLEN}}\"/>\n\n  <!-- Error messages for select -->\n  <div *ngIf=\"!disabled && provRef.touched\"\n      role=\"alert\"\n      class=\"error-container\"\n      aria-live=\"assertive\">\n    <div class=\"text-danger\" *ngIf=\"provRef?.errors?.required\">\n      Province is required.\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #noGeoCoder>\n  <input class=\"form-control\"\n         #streetRef=\"ngModel\"\n         spellcheck=\"false\"\n         type=\"text\"\n         id=\"street_{{objectId}}\"\n         name=\"street_{{objectId}}\"\n         [ngModel]=\"address?.street\"\n         (ngModelChange)=\"setStreetAddress($event)\"\n         [required]=\"isRequired\"\n         [disabled]=\"disabled\"\n         maxlength=\"{{STREET_RURAL_MAXLEN}}\"/>\n\n  <!-- Error messages for input -->\n  <div *ngIf=\"!disabled && streetRef.touched\"\n       role=\"alert\"\n       class=\"error-container\"\n       aria-live=\"assertive\">\n    <div class=\"text-danger\" *ngIf=\"streetRef?.errors?.required\">\n      Full street address or rural route is required.\n    </div>\n  </div>\n</ng-template>\n",
                        /* Re-use the same ngForm that it's parent is using. The component will show
                           * up in its parents `this.form`, and will auto-update `this.form.valid`
                           */
                        viewProviders: [
                            { provide: forms.ControlContainer, useExisting: i0.forwardRef(( /**
                                     * @return {?}
                                     */function () { return forms.NgForm; })) }
                        ],
                        styles: [""]
                    }] }
        ];
        /** @nocollapse */
        AddressComponent.ctorParameters = function () {
            return [
                { type: services.GeocoderService }
            ];
        };
        AddressComponent.propDecorators = {
            provRef: [{ type: i0.ViewChild, args: ['provRef',] }],
            streetRef: [{ type: i0.ViewChild, args: ['streetRef',] }],
            cityRef: [{ type: i0.ViewChild, args: ['cityRef',] }],
            postalRef: [{ type: i0.ViewChild, args: ['postalRef',] }],
            disabled: [{ type: i0.Input }],
            isRequired: [{ type: i0.Input }],
            address: [{ type: i0.Input }],
            countryList: [{ type: i0.Input }],
            defaultCountry: [{ type: i0.Input }],
            provinceList: [{ type: i0.Input }],
            defaultProvince: [{ type: i0.Input }],
            addressChange: [{ type: i0.Output }]
        };
        return AddressComponent;
    }(models.Base));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * TODO: Determine whether this component should be in the moh-common-lib
     */
    var NameComponent = /** @class */ (function (_super) {
        __extends(NameComponent, _super);
        function NameComponent() {
            var _this = _super.call(this) || this;
            _this.disabled = false;
            _this.required = false;
            _this.label = 'Name';
            _this.maxLen = '255';
            _this.objectID = 'name_' + _this.objectId;
            _this.nameStrChange = new i0.EventEmitter();
            _this.blurEvent = new i0.EventEmitter();
            /**
             * Valid characters for name
             */
            _this.nameCriteria = RegExp('^[a-zA-Z][a-zA-Z\-.\' ]*$');
            return _this;
        }
        /**
         * @return {?}
         */
        NameComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * Passes the value entered back to the calling component
         * @param name value the was entered by
         */
        /**
         * Passes the value entered back to the calling component
         * @param {?} value
         * @return {?}
         */
        NameComponent.prototype.setName = /**
         * Passes the value entered back to the calling component
         * @param {?} value
         * @return {?}
         */
            function (value) {
                this.nameStrChange.emit(value);
            };
        /**
         * @param {?} $event
         * @return {?}
         */
        NameComponent.prototype.onInputBlur = /**
         * @param {?} $event
         * @return {?}
         */
            function ($event) {
                console.log('onBlur: ', event);
                this.blurEvent.emit(event);
            };
        NameComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-name',
                        template: "\n<label for='{{objectID}}' class=\"control-label\">{{label}}</label>\n<input #nameRef=\"ngModel\"\n        type=\"text\"\n        class=\"form-control\"\n        name=\"{{objectID}}\"\n        id=\"{{objectID}}\"\n        [ngModel]=\"nameStr\"\n        (ngModelChange)=\"setName($event)\"\n        (blur)=\"onInputBlur($event)\"\n        [pattern]=\"nameCriteria\"\n        [maxlength]=\"maxLen\"\n        [required]=\"required\"\n        [disabled]=\"disabled\" />\n<!-- Error messages for component -->\n<div *ngIf=\"!nameRef.disabled && nameRef.touched\"\n    role=\"alert\"\n    class=\"error-container\"\n    aria-live=\"assertive\">\n  <div class=\"text-danger\" *ngIf=\"nameRef?.errors?.required\">\n    {{label}} is required.\n  </div>\n  <div class=\"text-danger\" *ngIf=\"nameRef?.errors?.pattern\">\n      {{label}} must begin with a letter and cannot include special characters except hyphens,\n      periods, apostrophes and blank characters.\n  </div>\n</div>\n\n",
                        /* Re-use the same ngForm that it's parent is using. The component will show
                           * up in its parents `this.form`, and will auto-update `this.form.valid`
                           */
                        viewProviders: [{ provide: forms.ControlContainer, useExisting: i0.forwardRef(( /**
                                         * @return {?}
                                         */function () { return forms.NgForm; })) }],
                        styles: [""]
                    }] }
        ];
        /** @nocollapse */
        NameComponent.ctorParameters = function () { return []; };
        NameComponent.propDecorators = {
            disabled: [{ type: i0.Input }],
            required: [{ type: i0.Input }],
            nameStr: [{ type: i0.Input }],
            label: [{ type: i0.Input }],
            maxLen: [{ type: i0.Input }],
            objectID: [{ type: i0.Input }],
            nameStrChange: [{ type: i0.Output }],
            blurEvent: [{ type: i0.Output }]
        };
        return NameComponent;
    }(models.Base));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var PhoneNumberComponent = /** @class */ (function (_super) {
        __extends(PhoneNumberComponent, _super);
        function PhoneNumberComponent() {
            var _this = _super.call(this) || this;
            _this.displayMask = true;
            _this.label = 'Mobile/SMS';
            _this.objectID = 'phone_' + _this.objectId;
            _this.maxlen = '30';
            _this.mask = [
                '+',
                '1',
                models.SPACE,
                '(',
                models.NUMBER,
                models.NUMBER,
                models.NUMBER,
                ')',
                models.SPACE,
                models.NUMBER,
                models.NUMBER,
                models.NUMBER,
                '-',
                models.NUMBER,
                models.NUMBER,
                models.NUMBER,
                models.NUMBER
            ];
            _this.placeholder = '+1 (555) 555-5555';
            return _this;
        }
        /**
         * @return {?}
         */
        PhoneNumberComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () { };
        PhoneNumberComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-phone-number',
                        template: "\n<label for=\"phone_{{objectId}}\" class=\"control-label\">{{label}}</label>\n<div *ngIf=\"displayMask; else NoMask\">\n  <input #phoneRef=\"ngModel\"\n          class=\"form-control\"\n          type=\"text\"\n          name=\"{{objectID}}\"\n          id=\"{{objectID}}\"\n          [ngModel]=\"value\"\n          (ngModelChange)=\"onUpdate($event)\"\n          [placeholder]=\"placeholder \"\n          [textMask]=\"{mask: mask}\"\n          [required]=\"required\"\n          [disabled]=\"disabled\"/>\n  <!-- Error messages for component -->\n  <div *ngIf=\"!disabled && phoneRef.touched\"\n      role=\"alert\"\n      class=\"error-container\"\n      aria-live=\"assertive\">\n    <div class=\"text-danger\" *ngIf=\"phoneRef?.errors?.required\">\n      {{label}} is required.\n    </div>\n  </div>\n</div>\n\n<ng-template #NoMask>\n  <input #phoneRef=\"ngModel\"\n          class=\"form-control\"\n          type=\"text\"\n          name=\"{{objectID}}\"\n          id=\"{{objectID}}\"\n          [ngModel]=\"value\"\n          (ngModelChange)=\"onUpdate($event)\"\n          [required]=\"required\"\n          [disabled]=\"disabled\"\n          maxlength=\"{{maxlen}}\"/>\n          <!-- Error messages for component -->\n  <div *ngIf=\"!disabled && phoneRef.touched\"\n        role=\"alert\"\n        class=\"error-container\"\n        aria-live=\"assertive\">\n    <div class=\"text-danger\" *ngIf=\"phoneRef?.errors?.required\">\n      {{label}} is required.\n     </div>\n  </div>\n</ng-template>\n\n",
                        /* Re-use the same ngForm that it's parent is using. The component will show
                           * up in its parents `this.form`, and will auto-update `this.form.valid`
                           */
                        viewProviders: [
                            { provide: forms.ControlContainer, useExisting: i0.forwardRef(( /**
                                     * @return {?}
                                     */function () { return forms.NgForm; })) }
                        ],
                        styles: [""]
                    }] }
        ];
        /** @nocollapse */
        PhoneNumberComponent.ctorParameters = function () { return []; };
        PhoneNumberComponent.propDecorators = {
            displayMask: [{ type: i0.Input }],
            label: [{ type: i0.Input }],
            objectID: [{ type: i0.Input }],
            maxlen: [{ type: i0.Input }]
        };
        return PhoneNumberComponent;
    }(models.MaskModel));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @enum {string} */
    var ApiStatusCodes = {
        SUCCESS: '0',
        ERROR: '1',
        WARNING: '2',
    };
    /** @enum {string} */
    var ScreenAreaID = {
        CONFIRMATION: 'CONFIRMATION',
        QRCODE: 'QR',
        NEXT_STEPS: 'NEXT STEPS',
        INTERIM: 'INTERIM',
        FINAL: 'FINAL',
    };
    var ServerPayload = /** @class */ (function () {
        function ServerPayload(payload) {
            this.clientName = payload.clientName;
            this.processDate = payload.processDate;
            this.statusCode = payload.statusCode;
            this.statusMsgs = payload.statusMsgs;
        }
        Object.defineProperty(ServerPayload.prototype, "success", {
            get: /**
             * @return {?}
             */ function () {
                return this.statusCode === ApiStatusCodes.SUCCESS;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ServerPayload.prototype, "error", {
            get: /**
             * @return {?}
             */ function () {
                return this.statusCode === ApiStatusCodes.ERROR;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ServerPayload.prototype, "warning", {
            get: /**
             * @return {?}
             */ function () {
                return this.statusCode === ApiStatusCodes.WARNING;
            },
            enumerable: true,
            configurable: true
        });
        return ServerPayload;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ConfirmationComponent = /** @class */ (function () {
        function ConfirmationComponent() {
            this.displayIcon = ApiStatusCodes.SUCCESS;
            this.hasQrCode = false;
            this.btnLabel = 'Login';
            this.btnClick = new i0.EventEmitter();
        }
        /**
         * @return {?}
         */
        ConfirmationComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () { };
        Object.defineProperty(ConfirmationComponent.prototype, "successCode", {
            // Status codes
            get: 
            // Status codes
            /**
             * @return {?}
             */
            function () {
                return ApiStatusCodes.SUCCESS;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ConfirmationComponent.prototype, "errorCode", {
            get: /**
             * @return {?}
             */ function () {
                return ApiStatusCodes.ERROR;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ConfirmationComponent.prototype, "warningCode", {
            get: /**
             * @return {?}
             */ function () {
                return ApiStatusCodes.WARNING;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} $event
         * @return {?}
         */
        ConfirmationComponent.prototype.onClick = /**
         * @param {?} $event
         * @return {?}
         */
            function ($event) {
                this.btnClick.emit($event);
                $event.stopPropagation();
                return false;
            };
        ConfirmationComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-confirmation',
                        template: "<h2 class=\"border-bottom\">Confirmation Message</h2>\n\n<common-page-section layout='noTips'>\n\n  <!-- Icons and confirmation messages -->\n  <div [ngSwitch]=\"displayIcon\">\n    <ng-container *ngSwitchCase=\"successCode\">\n      <div class=\"message-container border border-success\">\n        <p class=\"prime-icon--success\">\n          <i class=\"fa fa-2x fa-check-circle text-success\" aria-label=\"success\"></i>\n        </p>\n        <ng-container *ngTemplateOutlet=\"message\"></ng-container>\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"errorCode\">\n      <div class=\"message-container border border-danger\">\n        <p class=\"prime-icon--error\">\n          <i class=\"fa fa-2x fa-exclamation-triangle text-danger\" aria-label=\"error\"></i>\n        </p>\n        <ng-container *ngTemplateOutlet=\"message\"></ng-container>\n      </div>\n    </ng-container>\n\n    <ng-container *ngSwitchCase=\"warningCode\">\n      <div class=\"message-container border border-warning\">\n        <p class=\"prime-icon--warning\">\n          <i class=\"fa fa-2x fa-exclamation-circle text-warning\" aria-label=\"warning\"></i>\n        </p>\n        <ng-container *ngTemplateOutlet=\"message\"></ng-container>\n      </div>\n    </ng-container>\n  </div>\n</common-page-section>\n\n<div *ngIf=\"hasQrCode\">\n  <h2 class=\"border-bottom\">QR Code</h2>\n  <common-page-section layout='tips'>\n    <ng-content select=\"[qrcode]\"></ng-content>\n\n    <aside>TIPS</aside>\n  </common-page-section>\n</div>\n\n<div>\n  <h3 class=\"border-bottom\">Next Steps</h3>\n  <common-page-section layout='noTips'>\n    <ng-content select=\"[nextSteps]\"></ng-content>\n\n    <div class=\"p-3\">\n      <button class=\"btn btn-md btn-primary\" (click)=\"onClick($event)\">{{btnLabel}}</button>\n    </div>\n  </common-page-section>\n</div>\n\n<ng-template #message>\n  <ng-content></ng-content>\n</ng-template>\n",
                        styles: [".message-container{display:flexbox;padding:1rem;min-height:50px;border-radius:5px;border-style:solid;border-width:2px!important}@media (max-width:767.98px){.message-container{height:auto;margin:initial}}.prime-icon--error,.prime-icon--success,.prime-icon--warning{display:flex}.prime-icon--error::after,.prime-icon--success::after,.prime-icon--warning::after{font-size:1.5rem;margin-left:.5rem}.prime-icon--success::after{content:'Success'}.prime-icon--error::after{content:'Error'}.prime-icon--warning::after{content:'Warning'}"]
                    }] }
        ];
        /** @nocollapse */
        ConfirmationComponent.ctorParameters = function () { return []; };
        ConfirmationComponent.propDecorators = {
            displayIcon: [{ type: i0.Input }],
            hasQrCode: [{ type: i0.Input }],
            btnLabel: [{ type: i0.Input }],
            btnClick: [{ type: i0.Output }]
        };
        return ConfirmationComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ProfileBlockComponent = /** @class */ (function () {
        function ProfileBlockComponent() {
            this.name = 'Melissa Anderson';
            this.preferredName = 'Mel Anderson';
        }
        Object.defineProperty(ProfileBlockComponent.prototype, "dob", {
            get: /**
             * @return {?}
             */ function () {
                return this._dob;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        ProfileBlockComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                /** @type {?} */
                var dob = this.dateOfBirth;
                this._dob = dob.month + "/" + dob.day + "/" + dob.year;
            };
        ProfileBlockComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-profile-block',
                        template: "  <label class=\"font-weight-lighter\">Name</label>\n  <span class=\"font-weight-bolder\">{{name}}</span>\n  <ng-container *ngIf=\"preferredName\">\n    <label class=\"font-weight-lighter\">Preferred Name</label>\n    <span class=\"font-weight-bolder\">{{preferredName}}</span>\n  </ng-container>\n  <label class=\"font-weight-lighter\">Birthdate</label>\n  <span class=\"font-weight-bolder\">{{dob}}</span>\n",
                        changeDetection: i0.ChangeDetectionStrategy.OnPush,
                        styles: [":host(){display:-ms-grid;display:grid;-ms-grid-columns:50% 50%;grid-template-columns:50% 50%;background-color:#f5f6f8;padding:12px}"]
                    }] }
        ];
        /** @nocollapse */
        ProfileBlockComponent.ctorParameters = function () { return []; };
        ProfileBlockComponent.propDecorators = {
            name: [{ type: i0.Input }],
            preferredName: [{ type: i0.Input }],
            dateOfBirth: [{ type: i0.Input }]
        };
        return ProfileBlockComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ContactBlockComponent = /** @class */ (function () {
        // @Input() contactMethod: string = 'Email';
        function ContactBlockComponent() {
            this.phone = '-';
            this.email = '-';
            this.voicePhone = '-';
            this.preferredContact = '-';
            this.ext = '-';
        }
        /**
         * @return {?}
         */
        ContactBlockComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () { };
        ContactBlockComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-contact-block',
                        template: "<!-- <ng-container *ngIf=\"phone\"> -->\n<label class=\"font-weight-lighter\">Phone</label>\n<span class=\"font-weight-bolder\" *ngIf=\"phone; else dash\">{{ phone }}</span>\n<!-- </ng-container> -->\n\n<!-- <ng-container *ngIf=\"email\"> -->\n<label class=\"font-weight-lighter\">Email</label>\n<span class=\"font-weight-bolder\" *ngIf=\"email; else dash\">{{ email }}</span>\n<!-- </ng-container> -->\n<!-- <ng-container *ngIf=\"voicePhone\"> -->\n<label class=\"font-weight-lighter\">Preferred Contact Method</label>\n<span class=\"font-weight-bolder\" *ngIf=\"preferredContact; else dash\">{{ preferredContact }}</span>\n<label class=\"font-weight-lighter\">Voice Phone</label>\n<span class=\"font-weight-bolder\" *ngIf=\"voicePhone; else dash\">{{ voicePhone }}</span>\n<!-- </ng-container> -->\n<label class=\"font-weight-lighter\">Extension</label>\n<span class=\"font-weight-bolder\" *ngIf=\"ext; else dash\">{{ ext }}</span>\n<ng-template #dash>-</ng-template>\n",
                        changeDetection: i0.ChangeDetectionStrategy.OnPush,
                        styles: [":host(){display:-ms-grid;display:grid;-ms-grid-columns:50% 50%;grid-template-columns:50% 50%;background-color:#f5f6f8;padding:12px}"]
                    }] }
        ];
        /** @nocollapse */
        ContactBlockComponent.ctorParameters = function () { return []; };
        ContactBlockComponent.propDecorators = {
            phone: [{ type: i0.Input }],
            email: [{ type: i0.Input }],
            voicePhone: [{ type: i0.Input }],
            preferredContact: [{ type: i0.Input }],
            ext: [{ type: i0.Input }]
        };
        return ContactBlockComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var SelfDeclarationQuestionBlockComponent = /** @class */ (function () {
        function SelfDeclarationQuestionBlockComponent() {
        }
        /**
         * @return {?}
         */
        SelfDeclarationQuestionBlockComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                if (this.answer)
                    this.yesNo = 'Yes';
                else
                    this.yesNo = 'No';
                if (this.documents) {
                    /** @type {?} */
                    var res = this.documents
                        .map(( /**
                 * @param {?} obj
                 * @return {?}
                 */function (obj) { return obj.name; }))
                        .reduce(( /**
                 * @param {?} a
                 * @param {?} b
                 * @param {?} i
                 * @param {?} arr
                 * @return {?}
                 */function (a, b, i, arr) { return a + ', ' + b; }));
                    this.documents$ = rxjs.of(res);
                }
            };
        SelfDeclarationQuestionBlockComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-prime-self-declaration-question-block',
                        template: "<label class=\"font-weight-lighter\">{{ question }}</label>\n<span class=\"font-weight-bolder\">{{ yesNo }}</span>\n<ng-container *ngIf=\"answer\">\n  <label class=\"font-weight-lighter\">Details</label>\n  <span class=\"font-weight-bolder\">{{ details }}</span>\n  <label class=\"font-weight-lighter\">Documents</label>\n  <span class=\"font-weight-bolder\">{{ documents$ | async }}</span>\n</ng-container>\n",
                        changeDetection: i0.ChangeDetectionStrategy.OnPush,
                        styles: [":host(){display:-ms-grid;display:grid;-ms-grid-columns:50% 50%;grid-template-columns:50% 50%;background-color:#f5f6f8;padding:12px}"]
                    }] }
        ];
        /** @nocollapse */
        SelfDeclarationQuestionBlockComponent.ctorParameters = function () { return []; };
        SelfDeclarationQuestionBlockComponent.propDecorators = {
            question: [{ type: i0.Input }],
            answer: [{ type: i0.Input }],
            details: [{ type: i0.Input }],
            documents: [{ type: i0.Input }]
        };
        return SelfDeclarationQuestionBlockComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ReviewListItemComponent = /** @class */ (function () {
        function ReviewListItemComponent() {
        }
        /**
         * @return {?}
         */
        ReviewListItemComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () { };
        ReviewListItemComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'lib-review-list-item',
                        template: "<div class=\"row\">\n  <div *ngIf=\"label\" class=\"col-sm-6\"><label class=\"font-weight-lighter\">{{ label }}</label></div>\n  <div *ngIf=\"value\" class=\"col-sm-6\"><span class=\"font-weight-bolders\">{{ value }}</span></div>\n</div>\n",
                        changeDetection: i0.ChangeDetectionStrategy.OnPush,
                        styles: [":host(){background-color:#f5f6f8;padding:12px}"]
                    }] }
        ];
        /** @nocollapse */
        ReviewListItemComponent.ctorParameters = function () { return []; };
        ReviewListItemComponent.propDecorators = {
            label: [{ type: i0.Input }],
            value: [{ type: i0.Input }]
        };
        return ReviewListItemComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var componentList = [
        AddressComponent,
        NameComponent,
        ProfileComponent,
        PhoneNumberComponent,
        ConfirmationComponent,
        ProfileBlockComponent,
        ContactBlockComponent,
        SelfDeclarationQuestionBlockComponent,
        ReviewListItemComponent
    ];
    var PrimeCoreModule = /** @class */ (function () {
        function PrimeCoreModule() {
        }
        PrimeCoreModule.decorators = [
            { type: i0.NgModule, args: [{
                        declarations: [componentList, ReviewListItemComponent],
                        imports: [
                            common.CommonModule,
                            forms.FormsModule,
                            ngSelect.NgSelectModule,
                            angular2TextMask.TextMaskModule,
                            ngxBootstrap.TypeaheadModule.forRoot(),
                            mohCommonLib.SharedCoreModule
                        ],
                        exports: [componentList, ReviewListItemComponent, ReviewListItemComponent]
                    },] }
        ];
        return PrimeCoreModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var CachePayLoad = /** @class */ (function (_super) {
        __extends(CachePayLoad, _super);
        function CachePayLoad(payload) {
            var _this = _super.call(this, payload) || this;
            _this.country = payload.country ? payload.country : undefined;
            _this.province = payload.province ? payload.province : undefined;
            _this.messages = payload.messages ? payload.messages : undefined;
            _this.secQues = payload.secQues ? payload.secQues : undefined;
            _this.documentType = payload.documentType ? payload.documentType : undefined;
            _this.sysParam = payload.sysParam ? payload.sysParam : undefined;
            return _this;
        }
        return CachePayLoad;
    }(ServerPayload));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var Document = /** @class */ (function () {
        function Document(input) {
            this.type = input.type;
            this.registrantUUID = input.registrantUUID;
            this.expiry = input.expiry;
            this.images = [];
        }
        /**
         * @return {?}
         */
        Document.prototype.isValid = /**
         * @return {?}
         */
            function () {
                return this.expiry && this.images.length >= 1;
            };
        return Document;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Class to store the BCSC session information
     */
    var /**
     * Class to store the BCSC session information
     */ BcscSession = /** @class */ (function () {
        function BcscSession() {
        }
        /**
         * Note: Once object type is know set the parameter to be as such
         * @param obj
         */
        /**
         * Note: Once object type is know set the parameter to be as such
         * @param {?} obj
         * @return {?}
         */
        BcscSession.prototype.setSessionData = /**
         * Note: Once object type is know set the parameter to be as such
         * @param {?} obj
         * @return {?}
         */
            function (obj) {
                this.authTrxId = obj.authTrxId;
                this.authPartyId = obj.authPartyId;
                this.authPartyName = obj.authPartyName;
                this.userIdType = obj.userIdType;
                this.userType = obj.userType;
            };
        /**
         * @return {?}
         */
        BcscSession.prototype.isEmpty = /**
         * @return {?}
         */
            function () {
                return !(this.authPartyId && this.authPartyName &&
                    this.userIdType && this.userType && this.authTrxId);
            };
        return BcscSession;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * PrimeAppBase is a class containing shared functionality for the
     * various "AppComponent"s for each individual prime application. The important
     * functionality is in the constructor and ngOnInit().  Unfortunately this does
     * not come bundled with a template and instead templates must be updated for
     * each project manually.
     *
     * **Note** - you MUST call super.ngOnInit() you have an ngOnInit() method in
     * your subclass. Otherwise, the title and accessability functions concerns
     * won't update.
     */
    var PrimeAppBase = /** @class */ (function (_super) {
        __extends(PrimeAppBase, _super);
        function PrimeAppBase(pRouter, pActivatedRoute, pTitleService, logger, version) {
            var _this = _super.call(this) || this;
            _this.pRouter = pRouter;
            _this.pActivatedRoute = pActivatedRoute;
            _this.pTitleService = pTitleService;
            _this.logger = logger;
            _this.title = 'Prime';
            _this.SKIP_CONTENT_HASH = '#content';
            version.success
                ? console.log('%c' + version.message, 'color: #036; font-size: 20px;')
                : console.error(version.message);
            return _this;
        }
        /**
         * @return {?}
         */
        PrimeAppBase.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                this.updateTitleOnRouteChange();
                this.pRouter.events.pipe(operators.filter(( /**
                 * @param {?} ev
                 * @return {?}
                 */function (ev) { return ev instanceof router.NavigationEnd; }))).subscribe(this.updateSkipContentLink.bind(this));
                this.updateSkipContentLink();
            };
        /**
         * Listen to every route change, and update the page title based on the
         * 'title' property in the route's data.
         */
        /**
         * Listen to every route change, and update the page title based on the
         * 'title' property in the route's data.
         * @protected
         * @return {?}
         */
        PrimeAppBase.prototype.updateTitleOnRouteChange = /**
         * Listen to every route change, and update the page title based on the
         * 'title' property in the route's data.
         * @protected
         * @return {?}
         */
            function () {
                var _this = this;
                this.pRouter.events
                    .pipe(operators.filter(( /**
             * @param {?} event
             * @return {?}
             */function (event) { return event instanceof router.NavigationEnd; })), operators.map(( /**
                 * @return {?}
                 */function () { return _this.pActivatedRoute; })), operators.map(( /**
                 * @param {?} route
                 * @return {?}
                 */function (route) {
                    while (route.firstChild) {
                        route = route.firstChild;
                    }
                    return route;
                })), operators.filter(( /**
                 * @param {?} route
                 * @return {?}
                 */function (route) { return route.outlet === 'primary'; })), operators.mergeMap(( /**
                 * @param {?} route
                 * @return {?}
                 */function (route) { return route.data; })))
                    .subscribe(( /**
             * @param {?} data
             * @return {?}
             */function (data) {
                    _this.setTitle(data.title);
                    _this.logger.log({
                        event: 'navigation',
                        title: data.title ? data.title : _this.title,
                        url: _this.pRouter.url
                    });
                }));
            };
        /** Set the page title. Includes basic formatting and fallback */
        /**
         * Set the page title. Includes basic formatting and fallback
         * @protected
         * @param {?=} title
         * @return {?}
         */
        PrimeAppBase.prototype.setTitle = /**
         * Set the page title. Includes basic formatting and fallback
         * @protected
         * @param {?=} title
         * @return {?}
         */
            function (title) {
                if (title) {
                    this.pTitleService.setTitle("Prime | " + title);
                }
                else {
                    // Default title
                    this.pTitleService.setTitle(this.title);
                }
            };
        /**
         * @param {?} url
         * @return {?}
         */
        PrimeAppBase.prototype.routeIsActive = /**
         * @param {?} url
         * @return {?}
         */
            function (url) {
                return this.pRouter.url.includes(url);
            };
        /**
         * Updates the skipToContent link which is an a11y concern.  Importantly the
         * skipToContent link must include the relevant routes / subpages that the
         * user is currently on.
         */
        /**
         * Updates the skipToContent link which is an a11y concern.  Importantly the
         * skipToContent link must include the relevant routes / subpages that the
         * user is currently on.
         * @return {?}
         */
        PrimeAppBase.prototype.updateSkipContentLink = /**
         * Updates the skipToContent link which is an a11y concern.  Importantly the
         * skipToContent link must include the relevant routes / subpages that the
         * user is currently on.
         * @return {?}
         */
            function () {
                this.skipLinkPath = this.generateSkipToContentLink();
            };
        // Slightly complicated because we have to include the deployUrl in manually.
        // If deployUrl changes this code must too.
        // Slightly complicated because we have to include the deployUrl in manually.
        // If deployUrl changes this code must too.
        /**
         * @protected
         * @return {?}
         */
        PrimeAppBase.prototype.generateSkipToContentLink =
            // Slightly complicated because we have to include the deployUrl in manually.
            // If deployUrl changes this code must too.
            /**
             * @protected
             * @return {?}
             */
            function () {
                // don't add duplicate #contents
                if (window.location.href.indexOf(this.SKIP_CONTENT_HASH) !== -1) {
                    return window.location.href;
                }
                return "" + window.location.origin + this.pRouter.url + "#content";
            };
        /** @nocollapse */
        PrimeAppBase.ctorParameters = function () {
            return [
                { type: router.Router },
                { type: router.ActivatedRoute },
                { type: platformBrowser.Title },
                { type: services.CommonLogger },
                { type: undefined, decorators: [{ type: i0.Inject, args: ['APP_VERSION',] }] }
            ];
        };
        return PrimeAppBase;
    }(models.Base));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * BASE_URL: URL for REST requests
     * @type {?}
     */
    var BASE_URL = new i0.InjectionToken('BaseUrl');
    /**
     * BASE_URL: URL for REST requests
     */
    var CacheApiService = /** @class */ (function (_super) {
        __extends(CacheApiService, _super);
        function CacheApiService(http, injector) {
            var _this = _super.call(this, http) || this;
            _this.http = http;
            _this.injector = injector;
            /**
             *  Default hardcoded header values.  Note: Authentication headers are added
             *  at runtime in the httpOptions() method.
             */
            _this._headers = new i1.HttpHeaders();
            return _this;
        }
        // Cache requests
        // Cache requests
        /**
         * @param {?} paramValue
         * @return {?}
         */
        CacheApiService.prototype.getCache =
            // Cache requests
            /**
             * @param {?} paramValue
             * @return {?}
             */
            function (paramValue) {
                /** @type {?} */
                var url = this.injector.get(BASE_URL) + '/getCache';
                /** @type {?} */
                var params = new i1.HttpParams().set('param', paramValue);
                return this.get(url, params);
            };
        /**
         *
         * @param error
         */
        /**
         *
         * @protected
         * @param {?} error
         * @return {?}
         */
        CacheApiService.prototype.handleError = /**
         *
         * @protected
         * @param {?} error
         * @return {?}
         */
            function (error) {
                if (error.error instanceof ErrorEvent) {
                    // Client-side / network error occured
                    console.error('An error occured: ', error.error.message);
                }
                else {
                    // The backend returned an unsuccessful response code
                    console.error("Backend returned error code: " + error.status + ".  Error body: " + error.error);
                }
                // A user facing error message /could/ go here; we shouldn't log dev info through the throwError observable
                return rxjs.throwError('Unable to process request!');
            };
        CacheApiService.decorators = [
            { type: i0.Injectable, args: [{ providedIn: 'root' },] }
        ];
        /** @nocollapse */
        CacheApiService.ctorParameters = function () {
            return [
                { type: i1.HttpClient },
                { type: i0.Injector }
            ];
        };
        /** @nocollapse */ CacheApiService.ngInjectableDef = i0.defineInjectable({ factory: function CacheApiService_Factory() { return new CacheApiService(i0.inject(i1.HttpClient), i0.inject(i0.INJECTOR)); }, token: CacheApiService, providedIn: "root" });
        return CacheApiService;
    }(services.AbstractHttpService));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * TODO: Set up service to store data returned from the cache service once
     *       determined how it will be configured/setup
     */
    var CacheService = /** @class */ (function () {
        function CacheService(cacheApiService) {
            this.cacheApiService = cacheApiService;
            // We use private BehaviorSubjects to cache results instead of having repeat
            // HTTP requests. This way the response is cached for the lifetime of the
            // session.
            this.$provinceListSubject = new rxjs.BehaviorSubject([]);
            this.$countrylistSubject = new rxjs.BehaviorSubject([]);
            this.$enhancedMessagesSubject = new rxjs.BehaviorSubject([]);
            this.$sysParamListSubject = new rxjs.BehaviorSubject([]);
            /**
             * Message List
             * Populated via call to reg/rest/getCache?param=messages
             */
            this.$enhancedMsgList = this.$enhancedMessagesSubject.asObservable();
            /**
             * Country List
             * Populated via call to reg/rest/getCache?param=countries
             */
            this.$countryList = this.$countrylistSubject.asObservable();
            /**
             * Province List
             * Populated via call to reg/rest/getCache?param=provinces
             */
            this.$provinceList = this.$provinceListSubject.asObservable();
            /**
             * System Parameter List
             * Populated via call to reg/rest/getCache?param=sysParam
             */
            this.$sysParamList = this.$sysParamListSubject.asObservable();
            this.setupBehaviorSubject('provinces', 'province', this.$provinceListSubject);
            this.setupBehaviorSubject('countries', 'country', this.$countrylistSubject);
            this.setupBehaviorSubject('messages', 'messages', this.$enhancedMessagesSubject);
            this.setupBehaviorSubject('sysParams', 'sysParam', this.$sysParamListSubject);
        }
        /**
         * A simple helper to setup BehaviorSubjects and Observables with API data.
         * HTTP requests will be sent out immediately at application load.
         *
         * We use BehaviorSubjects to cache values to stop repeat responses. This
         * requires that the properties are already setup on the class, including the
         * Observable and BehaviorSubject.
         *
         * @param cacheName the name of the parameter to pass to getCache()
         * @param propertyName the name of the property on the response we want
         * @param $subject the BehaviorSubject to emit the value found at propertyName
         */
        /**
         * A simple helper to setup BehaviorSubjects and Observables with API data.
         * HTTP requests will be sent out immediately at application load.
         *
         * We use BehaviorSubjects to cache values to stop repeat responses. This
         * requires that the properties are already setup on the class, including the
         * Observable and BehaviorSubject.
         *
         * @protected
         * @template T
         * @param {?} cacheName the name of the parameter to pass to getCache()
         * @param {?} propertyName the name of the property on the response we want
         * @param {?} $subject the BehaviorSubject to emit the value found at propertyName
         * @return {?}
         */
        CacheService.prototype.setupBehaviorSubject = /**
         * A simple helper to setup BehaviorSubjects and Observables with API data.
         * HTTP requests will be sent out immediately at application load.
         *
         * We use BehaviorSubjects to cache values to stop repeat responses. This
         * requires that the properties are already setup on the class, including the
         * Observable and BehaviorSubject.
         *
         * @protected
         * @template T
         * @param {?} cacheName the name of the parameter to pass to getCache()
         * @param {?} propertyName the name of the property on the response we want
         * @param {?} $subject the BehaviorSubject to emit the value found at propertyName
         * @return {?}
         */
            function (cacheName, propertyName, $subject) {
                this.cacheApiService
                    .getCache(cacheName)
                    .pipe(operators.map(( /**
             * @param {?} x
             * @return {?}
             */function (x) { return x[propertyName]; })))
                    .subscribe(( /**
             * @param {?} val
             * @return {?}
             */function (val) { return $subject.next(val); }));
            };
        CacheService.decorators = [
            { type: i0.Injectable, args: [{ providedIn: 'root' },] }
        ];
        /** @nocollapse */
        CacheService.ctorParameters = function () {
            return [
                { type: CacheApiService }
            ];
        };
        /** @nocollapse */ CacheService.ngInjectableDef = i0.defineInjectable({ factory: function CacheService_Factory() { return new CacheService(i0.inject(CacheApiService)); }, token: CacheService, providedIn: "root" });
        return CacheService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    exports.PrimeCoreModule = PrimeCoreModule;
    exports.PrimeConstants = PrimeConstants;
    exports.ProviderCode = ProviderCode;
    exports.AssuranceLevel = AssuranceLevel;
    exports.PrimePerson = PrimePerson;
    exports.ApiStatusCodes = ApiStatusCodes;
    exports.ScreenAreaID = ScreenAreaID;
    exports.ServerPayload = ServerPayload;
    exports.CachePayLoad = CachePayLoad;
    exports.Document = Document;
    exports.BcscSession = BcscSession;
    exports.PrimeAppBase = PrimeAppBase;
    exports.BASE_URL = BASE_URL;
    exports.CacheApiService = CacheApiService;
    exports.CacheService = CacheService;
    exports.ɵa = AddressComponent;
    exports.ɵe = ConfirmationComponent;
    exports.ɵg = ContactBlockComponent;
    exports.ɵb = NameComponent;
    exports.ɵd = PhoneNumberComponent;
    exports.ɵf = ProfileBlockComponent;
    exports.ɵc = ProfileComponent;
    exports.ɵi = ReviewListItemComponent;
    exports.ɵh = SelfDeclarationQuestionBlockComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=prime-core.umd.js.map